@extends('layouts.web')
@section('title', 'Pricing – Affordable MBA Assignmentshelp UK')
@section('description', 'Check transparent pricing at MBA Assignmentshelp UK. We offer affordable assignment writing
    help without compromising on quality, originality, or deadlines.')
@section('canonical', config('app.app_url') . Request::path())

@section('content')

    <section class="container py-6 px-4 mx-auto">
        <h1 class="text-4xl font-semibold py-8 text-center">Transparent Rates – No Hidden Charges</h1>

        <div class=" bg-white border border-primary-one shadow-lg relative   overflow-x-auto">
            <table class="border-collapse table-auto w-full whitespace-no-wrap table-striped relative">
                <thead>
                    <tr class="pricing-tr text-center">
                        <th
                            class="text-white bg-radial border border-primary-one sticky top-0 px-2 md:px-6 py-4 font-bold tracking-wider  uppercase text-base whitespace-nowrap overflow-hidden ">
                            Deadline / Academic Level
                        </th>
                        @foreach ($academicLevels as $level)
                            <th
                                class="text-white bg-radial border border-primary-one sticky top-0 px-2 md:px-6 py-4 font-bold tracking-wider uppercase text-base whitespace-nowrap overflow-hidden">
                                {{ $level->name }}
                            </th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach ($deadlines as $deadline)
                        <tr class="hover:bg-primary-one hover:text-white">
                            <td class="border border-t border-primary-one days">
                                <span
                                    class="py-3 flex justify-center items-center text-xs sm:text:sm md:text-lg">{{ $deadline->name }}</span>
                            </td>
                            @foreach ($academicLevels as $level)
                                @php
                                    $price = $fares
                                        ->where('academic_level_id', $level->id)
                                        ->where('deadline_id', $deadline->id)
                                        ->first();
                                @endphp
                                <td class="border border-t border-primary-one days">
                                    <span class="py-3 flex justify-center items-center text-xs sm:text:sm md:text-lg">
                                        {{ $price ? $price->per_page_price . ' GBP' : 'N/A' }}
                                    </span>
                                </td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>


        </div>
        <div class=" flex flex-col sm:flex-row justify-center items-center gap-4 mt-5 pt-3">
            <a href="{{ route('order') }}" class="btn-order bg-primary">
                <div class="icon flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 640 640">
                        <path
                            d="M197.8 100.3C208.7 107.9 211.3 122.9 203.7 133.7L147.7 213.7C143.6 219.5 137.2 223.2 130.1 223.8C123 224.4 116 222 111 217L71 177C61.7 167.6 61.7 152.4 71 143C80.3 133.6 95.6 133.7 105 143L124.8 162.8L164.4 106.2C172 95.3 187 92.7 197.8 100.3zM197.8 260.3C208.7 267.9 211.3 282.9 203.7 293.7L147.7 373.7C143.6 379.5 137.2 383.2 130.1 383.8C123 384.4 116 382 111 377L71 337C61.6 327.6 61.6 312.4 71 303.1C80.4 293.8 95.6 293.7 104.9 303.1L124.7 322.9L164.3 266.3C171.9 255.4 186.9 252.8 197.7 260.4zM288 160C288 142.3 302.3 128 320 128L544 128C561.7 128 576 142.3 576 160C576 177.7 561.7 192 544 192L320 192C302.3 192 288 177.7 288 160zM288 320C288 302.3 302.3 288 320 288L544 288C561.7 288 576 302.3 576 320C576 337.7 561.7 352 544 352L320 352C302.3 352 288 337.7 288 320zM224 480C224 462.3 238.3 448 256 448L544 448C561.7 448 576 462.3 576 480C576 497.7 561.7 512 544 512L256 512C238.3 512 224 497.7 224 480zM128 440C150.1 440 168 457.9 168 480C168 502.1 150.1 520 128 520C105.9 520 88 502.1 88 480C88 457.9 105.9 440 128 440z" />
                    </svg>
                </div>
                <span>Order Now</span>
            </a>
            <a href="javascript:void(Tawk_API.toggle())" class="btn-chat bg-secondary-one">
                <span>Chat Now</span>
                <div class="icon icon-round flex items-center justify-center">
                    <img class="chat-img" src="{{ asset('img/headphones-icon.webp') }}" alt="Headphones" title="Headphones" />
                </div>
            </a>
        </div>
    </section>

@endsection
