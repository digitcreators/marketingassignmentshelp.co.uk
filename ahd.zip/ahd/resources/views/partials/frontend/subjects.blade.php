<div class="swiper subject-slider pt-5">
    <div class="swiper-wrapper pt-5">
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Economics" title="Economics" src="{{ asset('img/Economics.svg') }}" />
                <p>Economics</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Accounting" title="Accounting" src="{{ asset('img/Accounting.svg') }}" />
                <p>Accounting</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Finance" title="Finance" src="{{ asset('img/Finance.svg') }}" />
                <p>Finance</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Marketing" title="Marketing" src="{{ asset('img/Marketing.svg') }}" />
                <p>Marketing</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Law" title="Business Law" src="{{ asset('img/BusinessLaw.svg') }}" />
                <p>Business Law</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Analytics" title="Business Analytics" src="{{ asset('img/BusinessAnalytics.svg') }}" />
                <p>Business Analytics</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Ethics" title="Business Ethics" src="{{ asset('img/BusinessEthics.svg') }}" />
                <p>Business Ethics</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Capital Budgeting" title="Capital Budgeting" src="{{ asset('img/CapitalBudgeting.svg') }}" />
                <p>Capital Budgeting</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Guerrilla Marketing" title="Guerrilla Marketing" src="{{ asset('img/GuerrillaMarketing.svg') }}" />
                <p>Guerrilla Marketing</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Change Management" title="Change Management" src="{{ asset('img/ChangeManagement.svg') }}" />
                <p>Change Management</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Administration" title="Business Administration" src="{{ asset('img/BusinessAdministration.svg') }}" />
                <p>Business Administration</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Management" title="Business Management" src="{{ asset('img/BusinessManagement.svg') }}" />
                <p>Business Management</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Information Technology" title="Information Technology" src="{{ asset('img/InformationTechnology.svg') }}" />
                <p>Information Technology</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="International Business" title="International Business" src="{{ asset('img/InternationalBusiness.svg') }}" />
                <p>International Business</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Environment" title="Business Environment" src="{{ asset('img/BusinessEnvironment.svg') }}" />
                <p>Business Environment</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Human Resource Management" title="Human Resource Management" src="{{ asset('img/HumanResourceManagement.svg') }}" />
                <p>Human Resource Management</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Intelligence" title="Business Intelligence" src="{{ asset('img/BusinessIntelligence.svg') }}" />
                <p>Business Intelligence</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Customer Satisfaction" title="Customer Satisfaction" src="{{ asset('img/CustomerSatisfaction.svg') }}" />
                <p>Customer Satisfaction</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Managing change MBA assignment" title="Managing change MBA assignment" src="{{ asset('img/managingchangeMBAassignment.svg') }}" />
                <p>Managing change MBA assignment</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Business Communication" title="Business Communication" src="{{ asset('img/BusinessCommunication.svg') }}" />
                <p>Business Communication</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Marketing Plan Assignment" title="Marketing Plan Assignment" src="{{ asset('img/marketingplanassignmentforMBA.svg') }}" />
                <p>Marketing Plan Assignment</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Content Management System" title="Content Management System" src="{{ asset('img/ContentManagementSystem.svg') }}" />
                <p>Content Management System</p>
            </div>
        </div>
        <div class="swiper-slide">
            <div class="subject-box p-4 shadow">
                <img class="mx-auto pb-3" alt="Customer Relationship Management" title="Customer Relationship Management" src="{{ asset('img/CustomerRelationshipManagement.svg') }}" />
                <p>Customer Relationship Management</p>
            </div>
        </div>
    </div>
    <div class="demos flex items-center justify-center gap-2 pb-4 mt-8">
        <div id="prev" class="left-argrid"><i class="fa fa-arrow-left"></i></div>
        <div id="next" class="right-argrid"><i class="fa fa-arrow-right"></i></div>
    </div>
</div>
