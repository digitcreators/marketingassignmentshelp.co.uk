return [
    'site_title' => 'cheap-cv-writing-laravel-daily',
];
