 <div class="mt-10 pt-5">
     <!-- Process 1 - Bootstrap Brain Component -->
     <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-center py-5">
         <div class="bg-white review-styling shadow-lg rounded-lg">
             <img class=" mx-auto text-center" src="<?php echo e(asset('img/dissertation.webp')); ?>" width="90" height="90"
                 alt="Lukas" title="Lukas">
             <div class="services-para flex items-center p-4 ">
                 <div class="ml-4 leading-5">
                     <h3 class="font-bold text-lg">MBA Dissertation</h3>
                     <p class="text-sm pt-2">
                         Our experts perform extensive research and gather data from credible sources, ensuring
                         proper referencing and formatting.
                     </p>
                 </div>
             </div>
         </div>
         <div class="bg-white review-styling shadow-lg rounded-lg">
             <img class=" mx-auto text-center" src="<?php echo e(asset('img/essay.webp')); ?>" width="90" height="90"
                 alt="Lukas" title="Lukas">
             <div class="services-para flex items-center p-4 ">
                 <div class="ml-4 leading-5">
                     <h3 class="font-bold text-lg">MBA Essay</h3>
                     <p class="text-sm pt-2">
                         We strive to produce commendable essays that always adhere to the requirements of your
                         institution.
                     </p>
                 </div>
             </div>
         </div>
         <div class="bg-white review-styling shadow-lg rounded-lg">
             <img class=" mx-auto text-center" src="<?php echo e(asset('img/personal.webp')); ?>" width="90" height="90"
                 alt="Lukas" title="Lukas">
             <div class="services-para flex items-center p-4 ">
                 <div class="ml-4 leading-5">
                     <h3 class="font-bold text-lg">MBA Personal Statement </h3>
                     <p class="text-sm pt-2">
                         We write powerful personal statements that showcase your personality and skills to
                         impress leading business schools.
                     </p>
                 </div>
             </div>
         </div>
         <div class="bg-white review-styling shadow-lg rounded-lg">
             <img class=" mx-auto text-center" src="<?php echo e(asset('img/write-assignment.webp')); ?>" width="90"
                 height="90" alt="Lukas" title="Lukas">
             <div class="services-para flex items-center p-4 ">
                 <div class="ml-4 leading-5">
                     <h3 class="font-bold text-lg">Write My MBA Assignment </h3>
                     <p class="text-sm pt-2">
                         You receive original and accurate content for your MBA assignments, done according to
                         your specifications.
                     </p>
                 </div>
             </div>
         </div>
     </div>
 </div>
<?php /**PATH C:\laragon\www\ahd\resources\views/partials/frontend/services.blade.php ENDPATH**/ ?>