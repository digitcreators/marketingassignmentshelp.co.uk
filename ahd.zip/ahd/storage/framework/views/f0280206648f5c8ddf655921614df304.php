<?php $__env->startSection('content'); ?>

   <?php echo $__env->make('partials.backend.admin-breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex p-0">
                            <ul class="nav nav-pills p-2">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query('status') == null && request()->routeIs('admin.customers.index')  ? 'active' : ''); ?>" href="<?php echo e(route('admin.customers.index')); ?>">
                                        All Customers
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-striped table-hover datatable">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Country</th>
                                        <th>Verified</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($customers)): ?>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class=" select-checkbox"></td>
                                                <td><?php echo e(Str::ucfirst($customer->name)); ?></td>
                                                <td><?php echo e($customer->email); ?></td>
                                                <td><?php echo e($customer->phone); ?></td>
                                                <td><?php echo e($customer->country ?? '--'); ?></td>
                                                <td>
                                                    <?php if($customer->email_verified_at): ?>
                                                        <span class="badge badge-info">Verified</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-warning">Not Verified</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    
                                                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.customers.show', $customer->id)); ?>">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function() {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

        $.extend(true, $.fn.dataTable.defaults, {
            customerCellsTop: true,
            customer: [
                [1, 'desc']
            ],
            pageLength: 100,

        });
        let table = $('.datatable:not(.ajaxTable)').DataTable({
            buttons: dtButtons
        })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>