<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-4">
                    <h4 class="m-0 text-dark">Profile</h4>
                </div>
                <div class="col-sm-8">
                    <ol class="breadcrumb float-sm-right">

                        <li class="breadcrumb-item"><a href="<?php echo e(route('customer.home')); ?>">Dashboard</a></li>


                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">

        <form action="<?php echo e(route('profile.password.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-md-4 col-form-label" for="current_password">Current Password</label>
                                <div class="col-md-8">
                                    <input type="password" name="current_password" id="current_password"
                                        class="form-control ">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-4 col-form-label" for="new_password">New Password</label>
                                <div class="col-md-8">
                                    <input type="password" name="new_password" id="new_password" class="form-control ">

                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-4 col-form-label" for="new_password_confirmation">Confirm
                                    Password</label>
                                <div class="col-md-8">
                                    <input type="password" name="new_password_confirmation" id="new_password_confirmation"
                                        class="form-control ">

                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary float-sm-right">Change Password</button>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/customer/profile/change-password.blade.php ENDPATH**/ ?>