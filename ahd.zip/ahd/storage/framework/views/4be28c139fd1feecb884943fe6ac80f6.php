<?php $__env->startSection('title', 'Woops! 404 Not Found'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.app_url') . Request::path()); ?>

<?php $__env->startSection('content'); ?>


    <section class="container mx-auto my-4 px-4 py-5">
        <div class="container mx-auto ">

            <img class="mx-auto img-fluid" src="<?php echo e(asset('imgs/404.webp')); ?>" alt="Not Found" width="700" height="319">

            <div class="text-center  space-y-2 text-xl md:text-3xl">
                <div class="py-2"><strong>This page got lost in conversation</strong></div>
            </div>
            <div class="text-center py-5 mt-2">
                <a href="<?php echo e(route('home')); ?>" class="order-link mb-4">Back To Home</a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/errors/404.blade.php ENDPATH**/ ?>