<div>
    <table align="center"
        style="font-weight:normal;border-collapse:collapse;border:0;margin-left:auto;margin-right:auto;padding:0;font-family:Arial,sans-serif;color:#2e2f3b;background-color:white;font-size:16px;line-height:26px;width:600px">
        <tbody>
            <tr>
                <td
                    style="border-collapse:collapse;border:1px solid #eeeff0;margin:0;padding:0;color:#2e2f3b;font-family:Arial,sans-serif;font-size:16px;line-height:26px">
                    <table
                        style="font-weight:normal;border-collapse:collapse;border:0;margin:0;padding:0;font-family:Arial,sans-serif">
                        <tbody>
                            <tr>
                                <td colspan="4" valign="top"
                                    style="border-collapse:collapse;border:0;margin:0;padding:0;color:#2e2f3b;font-family:Arial,sans-serif;font-size:16px;line-height:26px;background-color:#0c1f4c26;border-bottom:4px solid #c8102e;text-align:center">
                                    <a href="<?php echo e(url('/')); ?>" target="_blank">
                                        <img src="<?php echo e(asset('imgs/logo-email.webp')); ?>"
                                            alt="<?php echo e(env('APP_NAME', config('app.app_name'))); ?>" style=" width:180px;">
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td valign="top"
                                    style="border-collapse:collapse;border:0;margin:0;padding:20px;color:#2e2f3b;font-family:Arial,sans-serif;font-size:16px;line-height:26px;vertical-align:top;background-color:white;border-top:none">
                                    <table
                                        style="font-weight:normal;border-collapse:collapse;border:0;margin:0;padding:0;font-family:Arial,sans-serif">
                                        <tbody>
                                            <tr>
                                                <td
                                                    style="border-collapse:collapse;border:0;margin:0;padding:0;color:#2e2f3b;font-family:Arial,sans-serif;font-size:16px;line-height:26px">
                                                    <div>
                                                        <table border="1" cellpadding="6" cellspacing="0"
                                                            width="100%"
                                                            style="border-collapse:collapse;font-family:Arial, Helvetica, sans-serif;font-size:14px;">
                                                            <tr>
                                                                <td colspan="2"
                                                                    style="background:#f4f4f4;font-weight:bold;padding:10px;text-align:left;">
                                                                    # Order -
                                                                    <?php echo e(env('APP_NAME', config('app.app_name'))); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;width:30%;">Name</td>
                                                                <td><?php echo e($order->name); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Email</td>
                                                                <td><?php echo e($order->email); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Country</td>
                                                                <td><?php echo e($order->country); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Phone</td>
                                                                <td><?php echo e($order->phone); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Paper Type</td>
                                                                <td><?php echo e($order->paper_type); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Paper Topic</td>
                                                                <td><?php echo e($order->paper_topic); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Academic Level</td>
                                                                <td><?php echo e($order->academic_level); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">No Of Pages</td>
                                                                <td><?php echo e($order->number_of_pages); ?></td>
                                                            </tr>
                                                            <?php if(!empty($order->no_of_posters)): ?>
                                                                <tr>
                                                                    <td style="font-weight:bold;">No Of Posters</td>
                                                                    <td><?php echo e($order->no_of_posters); ?></td>
                                                                </tr>
                                                            <?php endif; ?>
                                                            <?php if(!empty($order->no_of_slides)): ?>
                                                                <tr>
                                                                    <td style="font-weight:bold;">No Of Slides</td>
                                                                    <td><?php echo e($order->no_of_slides); ?></td>
                                                                </tr>
                                                            <?php endif; ?>
                                                            <tr>
                                                                <td style="font-weight:bold;">Detail</td>
                                                                <td><?php echo e($order->detail); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Reference Style</td>
                                                                <td><?php echo e($order->reference_style); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">References</td>
                                                                <td><?php echo e($order->no_of_references); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Deadline</td>
                                                                <td><?php echo e($order->deadline); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Subject</td>
                                                                <td><?php echo e($order->subject); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Price Per Page</td>
                                                                <td><?php echo e($order->cost_per_page . ' GBP'); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;">Total Price</td>
                                                                <td><?php echo e($order->total_price . ' GBP'); ?></td>
                                                            </tr>
                                                        </table>


                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr bgcolor="#fff" style="border-top:4px solid #c8102e">
                                <td align="top"
                                    style="border-collapse:collapse;border:0;margin:0;padding:0;color:#2e2f3b;font-family:Arial,sans-serif;font-size:16px;line-height:26px;background:#0c1f4c26;text-align:center">
                                    <table
                                        style="font-weight:normal;border-collapse:collapse;border:0;margin:0;padding:0;font-family:Arial,sans-serif">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="middle"
                                                    style="border-collapse:collapse;border:0;margin:0;padding:20px;color:#2e2f3b;font-family:Arial,sans-serif;font-size:12px;line-height:16px;vertical-align:middle;text-align:center;width:580px">
                                                    <div>
                                                        <b><?php echo e(config('app.app_name')); ?></b>
                                                        <br> © <?php echo e(now()->year); ?>

                                                        <br>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\ahd\resources\views/email/order-admin.blade.php ENDPATH**/ ?>