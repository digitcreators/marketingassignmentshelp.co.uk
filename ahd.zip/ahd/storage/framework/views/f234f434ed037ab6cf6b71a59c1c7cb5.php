<img id="image-1" class="img-fluid rounded mx-auto" src="<?php echo e(asset('webp/order.webp')); ?>" alt="Place your order"
    title="Place your order" width="554" height="313" loading="eager">
<img id="image-2" class="img-fluid rounded mx-auto" src="<?php echo e(asset('webp/procedure-p3.webp')); ?>" alt="Pay for the essay"
    title="Pay for the essay" width="554" height="235" loading="lazy" style="display:none;">
<img id="image-3" class="img-fluid rounded mx-auto" src="<?php echo e(asset('webp/procedure-p2.webp')); ?>"
    alt="Keep in the loop with the Essay Help Expert" width="554" height="490"
    title="Keep in the loop with the Essay Help Expert" loading="lazy" style="display:none;">
<img id="image-4" class="img-fluid rounded mx-auto" src="<?php echo e(asset('webp/track.webp')); ?>"
    alt="Track your order progress" width="554" height="256" title="Track your order progress" loading="lazy"
    style="display:none;">
<img id="image-5" class="img-fluid rounded mx-auto" src="<?php echo e(asset('webp/whatsapp-uk.webp')); ?>"
    alt="Get your essay by Email/WhatsApp" width="554" height="381" title="Get your essay by Email/WhatsApp"
    loading="lazy" style="display:none;">
<?php /**PATH C:\laragon\www\ahd\resources\views/partials/frontend/procedure.blade.php ENDPATH**/ ?>