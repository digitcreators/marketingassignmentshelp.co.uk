<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <div class="d-flex justify-content-between">
                                <h5 class="card-title"><?php echo e(trans('cruds.setting.title')); ?></h5>
                                    <a href="<?php echo e(route('admin.setting.edit', $setting->id)); ?>" class="btn btn-sm btn-info my-auto"> <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.setting.title_singular')); ?> </a>
                            </div>
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.name')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->name ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.email')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->email ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.contact')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->contact ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.address')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->address ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.facebook_link')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->facebook_link ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.instagram_link')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->instagram_link ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.linkedin_link')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->linkedin_link ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('Whatsapp')); ?>

                                        </th>
                                        <td>
                                            <?php echo e($setting->whatsapp_link ?? '-'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.is_blogs_offers')); ?>

                                        </th>
                                        <td>
                                            <?php if($setting->is_blogs_offers): ?>
                                                <span class="badge bg-success p-2 ms-2"><?php echo e('Offers'); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-danger p-2 ms-2"><?php echo e('Not Offer'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <?php echo e(trans('cruds.setting.fields.is_services_offers')); ?>

                                        </th>
                                        <td>
                                            <?php if($setting->is_services_offers): ?>
                                                <span class="badge bg-success p-2 ms-2"><?php echo e('Offers'); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-danger p-2 ms-2"><?php echo e('Not Offer'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/admin/web-setting/index.blade.php ENDPATH**/ ?>