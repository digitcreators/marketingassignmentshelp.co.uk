<div class="swiper professional-writer-slider">
    <div class="swiper-wrapper">
        <!-- Charlotte -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid " src="<?php echo e(asset('imgs/writers/charlotte.webp')); ?>" alt="Charlotte"
                            title="Charlotte" loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Charlotte </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 13 <span class="c-text"> years of
                                                    experience</span></span>
                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Master’s <span class="c-text"> Degree</span></span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 12,320 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 11,985 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Finance </li>
                                        <li class="list-inline-item"> Marketing </li>
                                        <li class="list-inline-item"> Management </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"Charlotte is a great academic writer with 13 years of experience on our
                                            platform. With a Master's in Business Administration, she focuses on
                                            dissertations and theses in the areas of finance, marketing and management.
                                            Having 12,320 successful papers completed, Charlotte has received 11,985
                                            favourable reviews from students who admire her writing style and friendly
                                            attitude."
                                        </p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sebastian -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid" src="<?php echo e(asset('imgs/writers/sebastian.webp')); ?>" alt="Sebastian"
                            title="Sebastian" loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Sebastian </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 10 <span class="c-text"> years of
                                                    experience</span></span>

                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Bachelor’s <span class="c-text">Degree</span> </span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 9,754 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 8,940 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Engineering </li>
                                        <li class="list-inline-item"> Thesis </li>
                                        <li class="list-inline-item"> Dissertations </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"One of our skilled thesis writers, Sebastian, has over 10 years of
                                            experience in academic writing, working with us. He has an Engineering
                                            background and excels in both theses and dissertations. Sebastian has so far
                                            finished 9,754 academic tasks and gotten 8,940 positive reviews from German
                                            university students."</p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Isabella -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid" src="<?php echo e(asset('imgs/writers/isabella.webp')); ?>" alt="Isabella"
                            title="Isabella" loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Isabella </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 12 <span class="c-text"> years of
                                                    experience</span></span>

                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Master’s <span class="c-text"> Degree</span></span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 11,456 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 10,678 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Psychology </li>
                                        <li class="list-inline-item"> Public Health </li>
                                        <li class="list-inline-item"> English </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"With 12 years of experience under her belt, Isabella is a seasoned expert in
                                            dissertation and thesis writing. With a Master's in Sociology, she has
                                            guided students in writing brilliant papers on various subjects, including
                                            psychology, public health, and English. Being a reliable choice for
                                            students, Isabella has delivered 11,456 projects and gotten 10,678 superb
                                            reviews. "
                                        </p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daniel -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid" src="<?php echo e(asset('imgs/writers/daniel.webp')); ?>" alt="Daniel"
                            title="Daniel" loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Daniel </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 14 <span class="c-text"> years of
                                                    experience</span></span>

                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Ph.D. <span class="c-text"> Degree</span></span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 13,786 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 12,875 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Business Administration </li>
                                    </ul>

                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"With 14 years of expertise in dissertation and thesis writing assistance,
                                            Daniel is yet another skilled academic writer in our team. With a PhD in
                                            Business Administration, Daniel has worked on 13,786 papers and received
                                            12,875 fantastic reviews from students of leading German universities."</p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="demos mt-2">
        <div id="next-cv" class="left-argrid"><i class="fas fa-argrid-left"></i></div>
        <div id="prev-cv" class="right-argrid"><i class="fas fa-argrid-right"></i></div>
        <div class="swiper-pagination"></div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ahd\resources\views/partials/frontend/writers-3.blade.php ENDPATH**/ ?>