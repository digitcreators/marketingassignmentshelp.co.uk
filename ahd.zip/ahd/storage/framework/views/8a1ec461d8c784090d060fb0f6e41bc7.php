
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.backend.admin-breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main content -->
    <div id="orders" class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between p-0 ">
                            <ul class="nav nav-pills p-2">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query('status') == null && request()->routeIs('admin.orders.index') ? 'active' : ''); ?>"
                                        href="<?php echo e(request()->fullUrlWithQuery(['status' => null])); ?>">
                                        All <?php echo e(ucfirst(request()->segment(2))); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body table-responsive">
                            <table id="order-data-table" class="table table-striped table-hover datatable">
                                <thead class="text-center">
                                    <tr>
                                        <th></th>
                                        <th>Order ID</th>
                                        <th>Paper Type</th>
                                        <th>Academic Level</th>
                                        <th>Customer</th>
                                        <th>Total Cost</th>
                                        <th>Date</th>
                                        <th>Order Status</th>
                                    </tr>
                                </thead>
                                <tbody id="tbody" class="text-center"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(document).ready(function() {

            const url = ('<?php echo e(route('admin.orders.get', ['status' => request()->query('status') ?? ''])); ?>')
                .replace('&amp;', '&');

            $('#order-data-table').DataTable({
                "serverSide": false,
                "processing": false,
                'language': {
                    'loadingRecords': '&nbsp;',
                    'processing': 'Loading...'
                },
                // "order": [[ 1, 'asc' ]],
                "pageLength": 10,
                "ajax": {
                    "headers": {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    },
                    'url': url,
                    'dataSrc': "data"
                },
                "columns": [{
                        data: null,
                        defaultContent: '',
                        orderable: false,
                        className: 'select-checkbox'
                    },
                    {
                        "data": "id",
                        "render": function(data, type, row) {
                            var html = '<a href="' + ('<?php echo e(route('admin.orders.show', ':id')); ?>')
                                .replace(':id', data) + '">';
                            html += '<strong>#' + data + '</strong>';
                            html += '</a>';
                            return html;
                        }
                    },
                    {
                        "data": "detail",
                        "class": "text-left",
                        "render": function(data, type, row) {
                            return data;
                        }
                    },
                    {
                        "data": "academic_level",
                        "class": "text-left",
                        "render": function(data, type, row) {
                            return data;
                        }
                    },
                    {
                        "data": "user",
                        "render": function(data, type, row) {
                            return data.name;
                        }
                    },
                    {
                        "data": "amount_pretty",
                        "render": function(data, type, row) {
                            return '<div class="d-flex justify-content-between px-3 bg-light py-2"><span class="font-weight-bold">' +
                                data + '</span><span class="badge ' + row.invoice.status.css_class +
                                ' mt-1">' + row.invoice.status.name + '</span></div>';
                        }
                    },
                    {
                        "data": 'created_at_pretty'
                    },
                    {
                        "data": "status",
                        "render": function(data, type, row) {
                            return '<span class="badge ' + data.css_class + '">' + data.name +
                                '</span>';
                        }
                    },
                ],
                "columnDefs": [{
                    "width": "20%",
                    "targets": 1
                }]
            });


            $(function() {
                let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

                $.extend(true, $.fn.dataTable.defaults, {
                    orderCellsTop: true,
                });

                $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                    $($.fn.dataTable.tables(true)).DataTable()
                        .columns.adjust();
                });
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>