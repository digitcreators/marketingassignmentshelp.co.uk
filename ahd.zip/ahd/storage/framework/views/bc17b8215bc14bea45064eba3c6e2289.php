<?php $__env->startSection('content'); ?>

    <main id="main" class="main">

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <?php echo $__env->make('partials.backend.addAndBackBtns', [
                                "page_name" => trans('cruds.setting.title_singular'),
                                'back_link' => route('admin.setting.index')
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <form method="POST" action="<?php echo e(route("admin.setting.update", [$setting->id])); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="mb-3">
                                    <label class="required" for="name"><?php echo e(trans('cruds.setting.fields.name')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $setting->name)); ?>" required>
                                    <?php if($errors->has('name')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('name')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="email"><?php echo e(trans('cruds.setting.fields.email')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email', $setting->email)); ?>" required>
                                    <?php if($errors->has('email')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('email')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="contact"><?php echo e(trans('cruds.setting.fields.contact')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('contact') ? 'is-invalid' : ''); ?>" type="text" name="contact" id="contact" value="<?php echo e(old('contact', $setting->contact)); ?>" required>
                                    <?php if($errors->has('contact')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('contact')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="address"><?php echo e(trans('cruds.setting.fields.address')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text" name="address" id="address" value="<?php echo e(old('address', $setting->address)); ?>" required>
                                    <?php if($errors->has('address')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('address')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="facebook_link"><?php echo e(trans('cruds.setting.fields.facebook_link')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('facebook_link') ? 'is-invalid' : ''); ?>" type="text" name="facebook_link" id="facebook_link" value="<?php echo e(old('facebook_link', $setting->facebook_link)); ?>" required>
                                    <?php if($errors->has('facebook_link')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('facebook_link')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="instagram_link"><?php echo e(trans('cruds.setting.fields.instagram_link')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('instagram_link') ? 'is-invalid' : ''); ?>" type="text" name="instagram_link" id="instagram_link" value="<?php echo e(old('instagram_link', $setting->instagram_link)); ?>" required>
                                    <?php if($errors->has('instagram_link')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('instagram_link')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="instagram_link"><?php echo e(trans('cruds.setting.fields.instagram_link')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('instagram_link') ? 'is-invalid' : ''); ?>" type="text" name="instagram_link" id="instagram_link" value="<?php echo e(old('instagram_link', $setting->instagram_link)); ?>" required>
                                    <?php if($errors->has('instagram_link')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('instagram_link')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="linkedin_link"><?php echo e(trans('cruds.setting.fields.linkedin_link')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('linkedin_link') ? 'is-invalid' : ''); ?>" type="text" name="linkedin_link" id="linkedin_link" value="<?php echo e(old('linkedin_link', $setting->linkedin_link)); ?>" required>
                                    <?php if($errors->has('linkedin_link')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('linkedin_link')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="whatsapp_link"><?php echo e(trans('cruds.setting.fields.whatsapp_link')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('whatsapp_link') ? 'is-invalid' : ''); ?>" type="text" name="whatsapp_link" id="whatsapp_link" value="<?php echo e(old('whatsapp_link', $setting->whatsapp_link)); ?>" required>
                                    <?php if($errors->has('whatsapp_link')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('whatsapp_link')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="is_blogs_offers" id="is_blogs_offers" <?php echo e(old('is_blogs_offers', $setting->is_blogs_offers) ? 'checked' : ''); ?> />
                                    <label class="form-check-label" for="is_blogs_offers">Is Blogs Offer ?</label>
                                </div>

                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="is_services_offers" id="is_services_offers" <?php echo e(old('is_services_offers', $setting->is_services_offers) ? 'checked' : ''); ?>/>
                                    <label class="form-check-label" for="is_services_offers">Is Services Offer ?</label>
                                </div>

                                <div class="mb-3">
                                    <button class="btn btn-danger" type="submit">
                                        <?php echo e(trans('global.save')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/admin/web-setting/edit.blade.php ENDPATH**/ ?>