<?php $__env->startSection('title', 'Invoice'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url') . Request::path()); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="lg:mx-12 py-5">
            <div class="container mx-auto px-4 pb-4">
                <?php if(session('userData')): ?>
                    <div class="md:w-1/2 my-4 mx-auto bg-red-100 border-t-4 border-red-500 rounded-b text-teal-900 px-4 py-3 shadow-md"
                        role="alert">
                        <div class="flex">
                            <div class="py-1">
                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50"
                                    style="enable-background:new 0 0 50 50;" xml:space="preserve">
                                    <circle style="fill:#25AE88;" cx="25" cy="25" r="25" />
                                    <polyline
                                        style="fill:none;stroke:#FFFFFF;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;"
                                        points="
                38,15 22,33 12,25 " />
                                </svg>
                            </div>
                            <div>
                                <p class="text-center font-bold"><?php echo e(session('userData.userEmail')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <h1 class="text-4xl text-center font-bold mt-4">
                    Check Order Details Proceed With Payment
                </h1>
                <hr class="border border-primary-one bg-pri w-full h-[0.35rem] my-3 mx-auto" style="background:#dd0000;">
            </div>
            <div class="mx-auto">
                <div class=" px-4 space-y-4 ">
                    <div class="border rounded-2xl max-w-sm mx-auto bg-white"
                        style="box-shadow: 0 0 15px 0px rgb(255 183 0)">
                        <h4
                            class="py-2 text-xl text-center px-6 text-white bg-gradient-flip rounded-t-2xl font-bold">
                            Order Summary</h4>
                        <hr class="border-[2px]">
                        <ul class="my-2 space-y-1 ">
                            <li class="space-x-3 px-6">
                                <span>Name:</span> 
                                <strong class="float-right"> <?php echo e($order->name ?? '-'); ?> </strong>
                            </li>
                            <li class="space-x-3 px-6">
                                <span>Email:</span> 
                                <strong class="float-right"><?php echo e($order->email ?? '-'); ?> </strong>
                            </li>
                            <li class="space-x-3 px-6">
                                <span>Paper Type:</span> 
                                <strong class="float-right"> <?php echo e($order->paper_type ?? '-'); ?> </strong>
                            </li>
                            <li class="space-x-3 px-6">
                                <span>Paper Topic:</span> 
                                <strong class="float-right"><?php echo e($order->paper_topic ?? '-'); ?> </strong>
                            </li>
                            <li class="space-x-3 px-6">
                                <span>Subject:</span> 
                                <strong class="float-right"><?php echo e($order->subject ?? '-'); ?> </strong>
                            </li>
                            <li class="space-x-3 px-6">
                                <span> Academic Level:</span> 
                                <strong class="float-right"><?php echo e($order->academic_level ?? '-'); ?></strong>
                            </li>
                            <li class="space-x-3 px-6">
                                <span>deadline:</span> 
                                <strong class="float-right"><?php echo e($order->deadline ?? '-'); ?></strong>
                            </li>
                            <hr class="border-[2px]">
                            <li class="space-x-3 text-xl text-primary-two py-3 px-6">
                                <strong>Total Amount:</strong>
                                <strong class="float-right "><?php echo e(addCurrency($invoice->amount)); ?></strong>
                            </li>
                        </ul>

                        <hr class="border-[2px]">

                        <div class="w-full px-6 py-4">
                            <a href="<?php echo e(url('https://checkout.cheapresumewriter.com/payment?reference=' . $invoice->ref_no . '&gateway=stripe&source=ash-uk')); ?>"
                                class="btn-primary block text-white">
                                <?php echo e('Pay ' . addCurrency($invoice->amount)); ?>

                            </a>
                        </div>

                        <div class="flex flex-row justify-center space-x-6">
                            <img src="<?php echo e(asset('imgs/payments/professional-cv.png')); ?>" class="h-14 w-14">
                            <img src="<?php echo e(asset('imgs/payments/clutch.png')); ?>" class="h-14 w-14">
                            <img src="<?php echo e(asset('imgs/payments/top-rated.png')); ?>" class="h-14 w-14">
                        </div>

                        <p class="text-lg text-center my-4">We Accept</p>
                        <img src="<?php echo e(asset('imgs/payments/transactions.png')); ?>" class="mx-auto my-4">

                        <p class="text-lg text-center my-2 px-2">By proceeding to checkout you accept our</p>
                        <div class="text-blue-500 text-lg text-center mb-6">
                            <a href="<?php echo e(route('terms')); ?>">
                                Terms & Conditions
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/invoice.blade.php ENDPATH**/ ?>