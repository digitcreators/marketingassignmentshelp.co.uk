<div class="swiper professional-writer-slider">
    <div class="swiper-wrapper">
        <!-- David -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid " src="<?php echo e(asset('imgs/writers/david.webp')); ?>" alt="David" title="David"
                            loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> David </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 13 <span class="c-text"> years of
                                                    experience</span></span>
                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Ph.D. <span class="c-text"> Degree</span></span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 12,200 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 11,897 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Engineering </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"For over 13 years, David has been a skilled writer on our platform. He holds
                                            a Ph.D. in Engineering and has written over 12,200 essays. Students have
                                            admired his skill at producing strong, convincing arguments and have given
                                            him 11,897 excellent reviews. David excels in both persuasive and
                                            argumentative essays."
                                        </p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Anna -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid" src="<?php echo e(asset('imgs/writers/anna.webp')); ?>" alt="Anna" title="Anna"
                            loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Anna </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 11 <span class="c-text"> years of
                                                    experience</span></span>

                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Bachelor’s <span class="c-text">Degree</span> </span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 12,200 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 9,200 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> History </li>
                                        <li class="list-inline-item"> Storytelling </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"Anna has been working with us for almost 11 years. She has completed 10,480
                                            projects with over 9,200 stellar reviews. With a graduate degree in history,
                                            she possesses a keen ability to blend facts with storytelling. Her writing
                                            is highly regarded for being original, creative, and fresh."</p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Jonas -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid" src="<?php echo e(asset('imgs/writers/jonass.webp')); ?>" alt="Jonas"
                            title="Jonas" loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Jonas </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 10 <span class="c-text"> years of
                                                    experience</span></span>

                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> MBA <span class="c-text"> Degree</span></span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 9,890 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 8,640 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Business Management </li>
                                        <li class="list-inline-item"> Analytical Essays </li>
                                        <li class="list-inline-item"> Reflective Essays </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"Having worked on our platform for over 10 years, Jonas has completed 9,890
                                            projects for clients and earned 8,640 great reviews. He holds an MBA in
                                            Business Management and is well-known for his critical thinking skills,
                                            sharp insights, and compelling writing. His specialties include analytical
                                            and reflective essays."
                                        </p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Katharina -->
        <div class="swiper-slide lg:pt-0 pt-8">
            <div class="professional-box lg:px-10">
                <div class="grid lg:grid-cols-12 gap-4 items-end">
                    <div class="lg:col-span-3 mx-auto image-circle">
                        <img class="img-fluid" src="<?php echo e(asset('imgs/writers/katharina.webp')); ?>" alt="Katharina"
                            title="Katharina" loading="lazy" width="220" height="220">
                    </div>
                    <div class="lg:col-span-9">
                        <div class="team-box box1">
                            <div class="grid lg:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="py-2"> Katharina </h4>
                                    <span class="e-text"> 5 Rating
                                        <div class="rate py-2">
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i><i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </span>
                                    <div class="grid grid-cols-2 py-3 info">
                                        <div class="border-b border-r-2">
                                            <span class="red"> 12 <span class="c-text"> years of
                                                    experience</span></span>

                                        </div>
                                        <div class="border-b even">
                                            <span class="red"> Master’s <span class="c-text"> Degree</span></span>
                                        </div>
                                        <div class="border-r-2">
                                            <span class="red"> 11,896 <span class="c-text"> Finished
                                                    Orders</span></span>
                                        </div>
                                        <div class="even">
                                            <span class="red"> 10,600 <span class="c-text"> Reviews</span></span>
                                        </div>
                                    </div>
                                    <ul class="flex topics-covered mt-5">
                                        <li class="list-inline-item"> Narrative Essays </li>
                                        <li class="list-inline-item"> Descriptive Essays </li>
                                        <li class="list-inline-item"> Expository Essays </li>
                                    </ul>
                                </div>
                                <div>
                                    <div class="paragraph-box">
                                        <p>"Katharina has worked on 11896 essays, received 10600 outstanding reviews,
                                            and has been with us for over 12 years. She earned her Master's degree in
                                            Psychology and is recognized for her practical approach and friendly
                                            demeanor. Katharina specialises in writing narrative, descriptive, and
                                            expository essays."</p>
                                    </div>
                                    <div class="mt-5 pt-3 text-end">
                                        <a href="<?php echo e(route('order')); ?>" class="order-link"> I Pick This Helper </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="demos mt-2">
        <div id="next-cv" class="left-argrid"><i class="fas fa-argrid-left"></i></div>
        <div id="prev-cv" class="right-argrid"><i class="fas fa-argrid-right"></i></div>
        <div class="swiper-pagination"></div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ahd\resources\views/partials/frontend/writers-2.blade.php ENDPATH**/ ?>