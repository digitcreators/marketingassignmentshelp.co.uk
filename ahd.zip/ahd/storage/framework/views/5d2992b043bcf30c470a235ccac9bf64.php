
<?php $__env->startSection('title', 'Assignment Writer PK Blogs - Expert Guidance for Academics'); ?>
<?php $__env->startSection('description', 'Our Assignment Writer PK is best resource to stay up to date with insightful academic stories. Here you will get the valuable tips for your career growth.'); ?>
<?php $__env->startSection('canonical', config('app.app_url') . Request::path()); ?>
<?php $__env->startSection('noindex'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>

    
</style>
<div class="blogs-section py-14">
    <section class="contentSection">
        <?php if(isset($query)): ?>
                <div class="shadow-lg border p-3 mb-5">
                    <h2 class="text-xl font-bold">Search Results for: "<?php echo e($query); ?>"</h2>
                </div>
            <?php endif; ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:px-20 mx-4">
            <div class="lg:col-span-8 recent bg-white">
                <div class="container mx-auto grid md:grid-cols-2 xl:grid-cols-2 gap-y-10">
                    <?php if(count($blogs) > 0): ?>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="blogs-div">
                                <div>
                                    <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>">
                                        <img src="<?php echo e(url('storage/app/public/'.$blog->image_path)); ?>"  alt="<?php echo e(env('APP_NAME',config('app.name'))); ?>" class=" w-full hover:scale-105 hover:opacity-70 transition ease-in-out delay-150 cursor-pointer"></a>
                                </div>
                                <hr>
                                <div class="mt-3" >
                                    <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>"><p class="bg-white text-2xl  w-full text-center md:text-left h-20"><?php echo e($blog->title); ?></p></a>
                                </div>
                                <p class="bg-white leading-normal py-4 text-center md:text-left">
                                   <?php echo e(Str::limit(strip_tags($blog->description), 120 , '[...]')); ?>

                                </p>    
                                <hr>
                                <div class="w-full px-2 pt-4 pb-10">
                                    <div class="block float-left "> 
                                         <p class="bg-white mx-auto md:mx-0"> <i class="fa fa-user px-1"></i> Admin<i class="fa fa-clock-o px-1"></i><?php echo e($blog->created_at->format('j F Y')); ?></p>
                                    </div>                                        
                                    <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>" class="text-primary-one font-semibold float-right border-l border-gray-400 pl-2 hover:underline">
                                        <i class="fa fa-file-text-o pl-2 text-black"></i> Read more</a>
                                </div>                    
                            </div>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                    <?php else: ?>
                        <div class="bg-white">
                            <p class="text-center py-4 mx-auto md:mx-0 heading-secondary text-dark-lite dark:text-white">
                                No Blogs found
                            </p>
                        </div>
                    <?php endif; ?>
                </div>  
                <div class="flex space-x-2 justify-center mt-8">
                    <a href="<?php echo e(route('blog')); ?>"><button type="button" class="bg-primary-one px-4 py-2 text-white  rounded-lg font-bold">1</button></a>
                    <a href="/blogs?page=2"><button type="button" class="bg-primary-one px-4 py-2 text-white rounded-lg font-bold">2</button></a>
                </div>          
            </div>
            <div class="lg:col-span-4 ">
                <div class="mb-4 recent bg-white">
                    <form role="search" method="get" action="<?php echo e(route('blogs.search')); ?>" class="">
                        <div class="flex gap-4">
                            <input class="" type="search" name="search" value="" placeholder="Search blog title..." required>
                            <button aria-label="Search" class="text-white p-2 text-base" type="submit" style="background: #63668f">Search</button>
                        </div>
                    </form>
                </div>
                <div class="recent bg-white mb-5">
                    <div class="Block">
                        <div class="side-panel relative mb-8">
                            <h3 class="text-lg font-semibold mb-3  bg-primary text-white py-2 px-5"><i class="fa fa-file-text mr-2"></i>Recent Posts</h3>
                            <?php if(count($blogs) > 0): ?>
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="recent-blogs">
                                    <ul class="list-unstyled m-0 blog-listing">
                                        <li class="py-2"><a href="<?php echo e($blog->slug); ?>"> <?php echo e($blog->title); ?></a></li>
                                    </ul>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div class="recent-blogs">
                                <p>No blogs found</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="recent bg-white">
                    <div class="Block">
                        <div class="side-panel relative mb-8">
                            <h3 class="text-lg font-semibold mb-3  bg-primary text-white py-2 px-5"><i class="fa fa-file-text mr-2"></i>Categories</h3>
                            <?php if(count($categories) > 0): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="recent-blogs">
                                    <ul class="list-unstyled m-0 blog-listing">
                                        <li class="py-2"><a href="<?php echo e(route('blogs.category', $category->slug)); ?>"> <?php echo e($category->name); ?></a></li>
                                    </ul>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div class="recent-blogs">
                                <p>No Categories found</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/blogs/index.blade.php ENDPATH**/ ?>