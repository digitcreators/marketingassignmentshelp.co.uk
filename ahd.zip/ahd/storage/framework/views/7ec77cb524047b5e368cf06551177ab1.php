<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('partials.backend.admin-breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-9">

                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title"> <?php echo e(\Illuminate\Support\Str::limit(strip_tags($order->paper_type), 35) ?? '-'); ?> </h3>
                            <span class="float-sm-right">
                                <strong>Status:</strong>

                                <?php switch($order->status_id):
                                    case (1): ?>
                                        <span class="badge <?php echo e($order->status->css_class); ?>"><?php echo e($order->status->name); ?></span>
                                        <?php break; ?>
                                    <?php case (2): ?>
                                        <span class="badge <?php echo e($order->status->css_class); ?>"><?php echo e($order->status->name); ?></span>
                                        <?php break; ?>
                                    <?php case (3): ?>
                                        <span class="badge <?php echo e($order->status->css_class); ?>"><?php echo e($order->status->name); ?></span>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <span class="badge badge-default"> Default </span>
                                <?php endswitch; ?>

                            </span>
                        </div>
                        <div class="card-body">

                            <dl class="row  mb-0">
                                <dt class="col-sm-3 text-right mb-0">Paper Type:</dt>
                                <dd class="col-sm-9 mb-0"><?php echo e($order->paper_type ?? '-'); ?></dd>
                                <dt class="col-sm-3 text-right mb-0">Deadline:</dt>
                                <dd class="col-sm-9 mb-0"><?php echo e($order->deadline ?? '-'); ?></dd>
                                <dt class="col-sm-3 text-right mb-0">Academic Level:</dt>
                                <dd class="col-sm-9 mb-0"><?php echo e($order->academic_level ?? ''); ?></dd>
                                <dt class="col-sm-3 text-right mb-0">Date:</dt>
                                <dd class="col-sm-9 mb-0"><?php echo e(showDate($order->created_at)); ?></dd>
                            </dl>

                            <hr>

                            <dl class="row  mb-0">
                                <dt class="col-sm-3 text-right mb-0">Details:</dt>
                                <dd class="col-sm-9 mb-0"><?php echo $order->detail; ?></dd>
                            </dl>

                        </div>
                    </div>

                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title">Invoices</h3>
                        </div>
                        <div class="card-body table-responsive p-0">

                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Reference No.</th>
                                        <th>Gateway</th>
                                        <th>Amount</th>
                                        <th>Currency</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('customer.invoices.show', $order->invoice->ref_no)); ?>">
                                                <strong><?php echo e(\Illuminate\Support\Str::limit(strip_tags($order->invoice->ref_no), 15)); ?></strong>
                                            </a>
                                        </td>
                                        <td><?php echo e($order->invoice->gateway); ?></td>
                                        <td><?php echo e(addCurrency($order->invoice->amount)); ?></td>
                                        <td><?php echo e($order->invoice->currency ?? '--'); ?></td>
                                        <td><?php echo e(showDate($order->invoice->created_at)); ?></td>
                                        <td>

                                            <?php if($order->invoice->status_id == 4): ?>
                                                <a href="<?php echo e(route('invoice', ['reference' => $order->invoice->ref_no] )); ?>"
                                                    class="btn btn-primary btn-sm" target="_blank">
                                                    Pay with Debit / Credit Card
                                                </a>
                                            <?php else: ?>
                                                <?php switch($order->invoice->status_id):
                                                    case (4): ?>
                                                        <span class="badge <?php echo e($order->invoice->status->css_class); ?>"><?php echo e($order->invoice->status->name); ?></span>
                                                        <?php break; ?>
                                                    <?php case (5): ?>
                                                        <span class="badge <?php echo e($order->invoice->status->css_class); ?>"><?php echo e($order->invoice->status->name); ?></span>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <span class="badge badge-default"> Default </span>
                                                <?php endswitch; ?>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">

                    <div class="card card-dark">
                        <div class="card-header">
                            <h3 class="card-title">Profile</h3>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <strong>
                                        <a href="<?php echo e(route('customer.profile.index')); ?>">
                                            Edit Profile
                                        </a>
                                    </strong>
                                </li>
                                <li><?php echo e(auth()->user()->name); ?></li>
                                <li><?php echo e(auth()->user()->email); ?></li>
                                
                                <li></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card card-dark">
                        <div class="card-header">
                            <h3 class="card-title">Attachments</h3>
                        </div>
                        <div class="card-body">
                            <div style="margin-left: 10px">
                                <div><strong>files</strong>
                                    <br>
                                <?php if($files): ?>

                                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(url('storage/app/public/'.$file->file_path)); ?>"  target="_blank"><?php echo e(trim($file->file_path,'uploads/')); ?></a>
                                    <br>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>
                                    <p>No files Attached</p>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/customer/orders/show.blade.php ENDPATH**/ ?>