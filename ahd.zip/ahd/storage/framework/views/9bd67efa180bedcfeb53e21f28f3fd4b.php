
<?php $__env->startSection('keyword', 'University Assignment Help in Germany'); ?>
<?php $__env->startSection('title', 'Get Premium University Assignment Help in Germany'); ?>
<?php $__env->startSection('description',
    'Achieve better grades by choosing our university assignment help in Germany. We have a pool of
    qualified experts who are familiar with the academic expectations.'); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('heroImage', ''); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="homepage-background bg-gray-800 py-12">
        <div class="container mx-auto">
            <div class="grid lg:grid-cols-12 lg:px-0 px-5 py-10 lg:gap-4 items-center">
                <!-- Left Column -->
                <div class="lg:col-span-7">
                    <h1 class="text-4xl font-bold">
                        <span class="text-primary">Top-Notch University Assignment Help in Germany </span>Backed By Skilled
                        Writers
                    </h1>
                    <p class="py-5">
                        Assignmenthelperdeutsch.de is a well-established platform offering trusted University Assignment
                        Help in Germany, supporting thousands of students in achieving academic success over the last 15
                        years. With over 400 committed assignment writers, 200+ thesis specialists and 100+ essay experts,
                        our team produces customised work across every academic discipline.
                    </p>
                    <?php echo $__env->make('partials.frontend.calculator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-span-12 lg:col-span-5 mt-4 lg:mt-0">
                    <img class="ml-auto" src=" <?php echo e(asset('imgs/hero-girl.png')); ?> " width="412" height="466" alt="Hero Girl"
                        title="Hero Girl" />
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <?php echo $__env->make('partials.frontend.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Feature End -->

    <section class="relative z-0 bg-theme procedure-sec py-10 px-5">
        <div class="container mx-auto">
            <!-- text div -->
            <div class="space-y-5 text-center">
                <h2 class="text-4xl font-semibold ">
                    Why Students in Germany Choose <span class="span-header">Our University Assignment Help
                    </span>
                </h2>
                <p class=" mt-3">
                    With us, your work is in capable hands, so you don't have to worry about a thing. You will receive your
                    work on time, done with care and expertise.
                </p>
            </div>
            <div class="university mt-8">
                <!-- Process 1 - Bootstrap Brain Component -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-center py-5">
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">
                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/quality-work.gif')); ?>" alt="Quality Work" width="100"
                                    height="100" title="Quality Work" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Superior Assignment Quality </h3>
                        <p class="text-sm">
                            You get the best structured papers completed with in-depth research, proper formatting, and
                            custom-crafted according to your specifications.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class=" flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/academic-writer.gif')); ?>" alt="Qualified Writers" width="100"
                                    height="100" title="Qualified Writers" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Experienced Academic Experts</h3>
                        <p class="text-sm">
                            We select writers after a rigorous hiring process who are highly trained and experienced,
                            familiar with the grading criteria and academic standards.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/countless-edits.gif')); ?>" alt="Multiple Edits" width="100"
                                    height="100" title="Multiple Edits" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Multiple Revisions</h3>
                        <p class="text-sm">
                            We don't just stop after delivering the assignment, but offer support until you are fully
                            satisfied, so reach out for revisions.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/affordable-prices.gif')); ?>" alt="Economical Pricing" width="100"
                                    height="100" title="Economical Pricing" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Budget-Friendly Solutions</h3>
                        <p class="text-sm">
                            We offer a fair pricing structure, ensuring you receive the best value for your money. No hidden
                            or surprise charges.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-10 px-8">
        <div class="container mx-auto">
            <div class="my-5">
                <!-- Process 1 - Bootstrap Brain Component -->
                <div class="grid grid-cols-1 lg:grid-cols-2 lg:gap-6 gap-0 items-center">
                    <div class="lg:px-8">
                        <img src="<?php echo e(asset('imgs/content.webp')); ?>" width="500" height="500" alt="Expert University Assignment Writing"
                            title="Expert University Assignment Writing" />
                    </div>
                    <div class="lg:mt-0 mt-4">
                        <h3 class="text-4xl font-semibold pb-2">
                            <span class="span-header">Expert University Assignment Writing
                            </span> Support Covering Every Discipline
                        </h3>
                        <p class="py-2">
                            Our university assignment help in Germany is driven by a group of very knowledgeable writers
                            with a diverse range of academic backgrounds. Every writer on our platform is carefully selected
                            through a rigorous hiring process. Our specialists hold degrees in computer science, literature,
                            social sciences, business, engineering, and other fields. This allows us to connect you with
                            someone who is thoroughly knowledgeable about your subject. They are aware of precisely how to
                            customise assignments to meet university standards.
                        </p>
                        <div class="mt-5">
                            <a href="<?php echo e(route('order')); ?>" class="order-link">
                                Get Help Today!
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <!-- Writers Start -->
    <section class="professional-experts bg-theme container-fluid py-8">
        <div class="container mx-auto px-5 lg:px-0">
            <div class="text-center mx-auto pb-3">
                <h3 class="text-4xl font-semibold py-5">
                    Meet Our Pro <span class="span-header">Assignment Writers in Germany</span>

                </h3>
            </div>
            <?php echo $__env->make('partials.frontend.writers-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <!-- Writers End -->

    <!-- Counter -->
    <section class="counter px-4 md:px-10 lg:px-20 mx-auto py-5 lg:mb-8">
        <div class="container py-5 mx-auto">
            <h3 class="text-3xl md:text-4xl text-center lg:mt-5 font-bold">
                Your Assignment Success in 4 Easy Steps
            </h3>
            <p class="py-3 text-center">
                Get your thesis ready on time without any hassles.
            </p>
            <?php echo $__env->make('partials.frontend.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <!-- End counter -->

    <!-- CTA Section -->
    <section class="cta-section my-10">
        <div class="container mx-auto py-10 lg:px-0 px-5">
            <div class="grid lg:grid-cols-12 items-center">
                <div class="lg:col-span-7 w-full">
                    <h2 class="lg:text-4xl text-3xl text-white">
                        Urgent Assignment Delivery in Just a Few Hours
                    </h2>
                    <p class="py-5 text-white ">
                        No need to panic if you have a paper due in a few hours; we will help you complete it right on time
                        with quality intact.
                    </p>
                    <div class="lg:flex md:flex grid gap-4 pt-3">
                        <a href="<?php echo e(route('order')); ?>" class="order-link">
                            Place An Order Now
                        </a>
                        <a href="javascript:void(Tawk_API.toggle())" class="click-btn btn-chat">
                            Chat Now
                        </a>
                    </div>
                </div>
                <div class="relative lg:col-span-5 lg:block hidden">
                    <div class="cta-image">
                        <img src="<?php echo e(asset('imgs/cta-fold.webp')); ?>" class="image" width="400" height="416"
                            title="CTA" alt="CTA">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Section -->

    <!-- Four paragrapgh -->
    <section class="four-sec overflow-hidden px-5 py-10">
        <div class="lg:px-10 px-2">
            <div class="con-main">

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 ">
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Top University Assignment Writing Help For Every Subject and Stream
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                Stuck on some topic? Experiencing sleepless nights or writer’s block? We understand all the
                                struggles that university students face. That’s why we are here with a comprehensive
                                solution to help you with all your assignment problems. Through our expert university
                                assignment writing help in Germany, we provide the support you need to excel academically.
                                Our team of knowledgeable writers has mastered all subjects and is committed to simplifying
                                complex topics so you can learn and understand concepts more effectively. This approach not
                                only ensures high-quality assignments but also equips you with skills that will benefit your
                                future academic work.
                            </p>
                            <p class="text-base py-3">
                                Moreover, we don’t just fill pages but research on the topic thoroughly, brainstorm and
                                organise ideas and then start writing following a proper structure. This ensures that the
                                work is done with diligence, creativity, and a personal touch that will ultimately help you
                                score the best marks. Additionally, if you have any specific requirements, such as a
                                preferred writing style or tone, just let us know, and we will adjust accordingly. If you
                                want us to review your work, we will do that as well.
                            </p>
                        </div>
                    </div>
                    <div class=" ">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Reliable University Assignment Writing Service Helping You Ace Your Studies
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                When you work with Assignment Helper Deutsch, you won't just get assignments completed on
                                time, but you will also be able to grasp complicated theories and ideas, which will, in
                                turn, improve your comprehension. This way, you are really acquiring knowledge that you can
                                use in class discussions and exams. Our University assignment writers incorporate real-world
                                context and present solid arguments in the assignments, which makes your work even more
                                credible and interesting.
                            </p>
                            <p class="text-base py-3">
                                Furthermore, every institution has a distinct tone and level of writing; therefore, we
                                deliberately design assignments to meet these requirements. Your work will appear
                                academically sound, authentic, and clear, which academics will value. Our service not only
                                focuses on delivering your assignments, but we also prioritise your learning and growth.
                                Apart from that, we offer editing, proofreading, formatting, and plagiarism checks to
                                enhance your assignments and ensure the submission of high-quality work. If you want to
                                engage in discussions with your writer, we also offer online consultations, whether you
                                reside in Munich, Leipzig or Nuremberg. So, place your order today and let us handle your
                                task.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Skilled University Assignment Writers Who Combine Research with Quality
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                At AssignmentHelperDeutsch, we help you build your self-confidence in your skills. Many
                                students understand the ideas and concepts, but struggle to express or write them down into
                                a compelling argument. Our service emphasises an organised structure and logical flow to
                                your work, which showcases creativity and critical thinking. Every student has a unique
                                approach and writing style, and it should be reflected in their work through examples and
                                their understanding of the topic. For this reason, we go beyond generic writing and give a
                                personal touch to your assignments by working closely with you, listening to and
                                understanding your perspective and requirements.
                            </p>
                            <p class="text-base py-3">
                                By working with us, you also get to sharpen your skills by reviewing the draft. Students
                                pick up the way we write, research, structure the ideas, simplify theories and concepts and
                                also reference properly. In addition to that, our writers also offer services for
                                <a class="sparkle-awd" href="<?php echo e(route('thesis')); ?>">thesis writing</a> and
                                <a class="sparkle-awd" href="<?php echo e(route('dissertation')); ?>">dissertation writing</a>, so
                                connect with us if you need support. Our university
                                assignment help transforms every submission from something to fret about into an opportunity
                                to exhibit your academic development proudly.
                            </p>
                        </div>
                    </div>
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Score Higher with Our Cheap University Assignment Help in Germany
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                There are already a lot of expenditures during university life, so we believe that getting
                                professional assignment writing assistance should not add financial strain on students. This
                                is the reason we have created a budget-friendly service meant to provide students access to
                                premium work without costing them too much. Our service offers professional assistance at a
                                reasonable price, even for those on a limited budget. It doesnt matter whether you need help
                                with a particular chapter or just want someone to proofread and edit your work, our writers
                                will be glad to assist. We offer tailored packages, enabling you to choose one that best
                                suits your needs and budget.
                            </p>
                            <p class="text-base py-3">
                                Moreover, our team guarantees every project is thoroughly researched, organised, and
                                meticulously written. Even at low prices, you get quality work, which makes it easier for
                                students to manage their workload without any financial worry. Other than that, you can
                                contact our experts if you want assistance with <a class="sparkle-awd"
                                    href="<?php echo e(route('essay')); ?>">essay writing</a>
                                and <a class="sparkle-awd" href="<?php echo e(route('cipd')); ?>">CIPD assignments</a> at the
                                cheapest costs. You get trustworthy academic help from us at reasonable, practical prices
                                tailored for students.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="mt-8 flex justify-center lg:gap-8 gap-6 mt-5 py-5">
                    <a href="<?php echo e(route('order')); ?>" class="order-link">
                        Place An Order
                    </a>
                </div>
            </div>
        </div>
    </section><!-- Four paragrapgh -->

    <!-- Testimonial Start -->
    <section class="relative bg-theme container-fluid py-8">
        <div class="container mx-auto pb-3">
            <div class="text-center mx-auto">
                <h3 class="text-4xl font-semibold py-5">
                    <span class="span-header">Testimonial</span>

                </h3>
            </div>
            <?php echo $__env->make('partials.frontend.testimonial-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </section>
    <!-- Testimonial End -->

    <!-- FAQ -->
    <section class="faqs px-2 md:px-12 lg:px-20 mx-auto py-8">
        <div class="container mx-auto px-3">
            <h2 class="lg:text-4xl text-3xl text-uppercase text-center py-5">
                Student FAQs <span class="span-header"> – Quick Help Hub</span>
            </h2>
            <div class="grid lg:grid-cols-2 md:grid-cols-1 grid-cols-1 items-center">
                <div class="text-center">
                    <img src="<?php echo e(asset('imgs/faq.webp')); ?>" class="img-fluid mx-auto" alt="Frequently Asked Questions"
                        title="Frequently Asked Questions" width="450" height="560">
                </div>
                <div class="space-y-2 py-5">

                    <div class="content border-b faq-internal-styling" data-no="0">
                        <div class="questions cursor-pointer flex p-3 font-bold active" data-no="0">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">1-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you assist with both undergraduate and postgraduate assignments?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-minus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide0">
                            Yes, we assist with both undergraduate and postgraduate assignments. Our experienced writers
                            offer comprehensive services that encompass a wide range of tasks, coursework, and research
                            projects. Your work will be assigned to a writer according to the academic level and
                            requirements.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="1">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="1">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">2-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Can you meet urgent deadlines for university assignments?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide1">
                            Yes, we can meet urgent deadlines for university assignments. Our fast-paced writers will do
                            your assignment within a short deadline without sacrificing the quality of your work.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="2">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="2">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">3-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you offer plagiarism-free university assignments?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide2">
                            Our expert assignment helpers in Germany produce all work from scratch and do not copy from
                            other sources, ensuring your work is 100% original and plagiarism-free.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="3">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="3">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">4-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    How do I place an order for university assignment help in Germany?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide3">
                            You simply need to visit our website and complete the order form with your project requirements
                            and details. Our team will be in touch with you shortly and assign an expert to your task.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="4">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="4">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">5-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you offer assistance for international students in Germany?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide4">
                            Yes, we offer assistance for international students in Germany, making their academic life
                            easier to manage. Our team is well aware of the German university guidelines and expectations,
                            so they make sure your papers are original, clear, and well-structured.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="5">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="5">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">6-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Is my personal and academic information kept confidential?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide5">
                            Yes, we have a stringent privacy policy, ensuring that your personal information and academic
                            details are safe with us, as we do not share them with any third party.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="6">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="6">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">7-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you offer affordable university assignment help packages?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide6">
                            Yes, we offer student-friendly packages to fit your budget and needs. There are no hidden
                            charges, and we never compromise on quality, even at reasonable prices.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="7">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="7">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">8-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Can you handle technical and non-technical assignments?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide7">
                            Yes, we can handle both technical and non-technical assignments. We cater to a wide range of
                            disciplines, including business, psychology, humanities, social sciences, engineering, IT, and
                            more. We match you with a writer who has deep knowledge of your subject.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="8">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="8">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">9-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    How do you ensure the quality of university assignments in Germany?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide8">
                            We have skilled writers who create plagiarism-free university assignments backed by deep
                            research. They strictly adhere to the academic guidelines of German universities and are
                            familiar with the formatting, structures, and citation styles used in these institutions. They
                            also offer multiple revisions for your complete satisfaction.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="9">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="9">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">10-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Can I track the progress of my assignment?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide9">
                            Yes, of course, you can track the progress of your assignment. Our proactive team is available
                            around the clock through chat to answer your queries, update you on your assignment, and listen
                            to your feedback.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- FAQ -->

    <!-- CTA Section -->
    <section class="cta-form lg:p-5 p-3">
        <div class="rounded-lg lg:py-0 py-8 ">
            <div class="grid lg:grid-cols-12 items-center">
                <div class="lg:col-span-4 lg:block hidden">
                    <img src="<?php echo e(asset('imgs/form-girls.png')); ?>" class="image mx-auto" width="388" height="349"
                        title="CTA" alt="CTA" loading="lazy">
                </div>
                <div class="lg:col-span-8 lg:px-10">
                    <h2 class="lg:text-4xl text-3xl text-white lg:text-left text-center">
                        Let Us Help You Reach the Finish Line with Top Marks
                    </h2>
                    <div class="mt-5">
                        <?php echo $__env->make('partials.frontend.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/services/university-assignment.blade.php ENDPATH**/ ?>