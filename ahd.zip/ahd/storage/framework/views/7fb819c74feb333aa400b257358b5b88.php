
<?php $__env->startSection('title', 'About Us – Assignment Helper Deutsch'); ?>
<?php $__env->startSection('description', 'Learn about Assignment Helper Deutsch, a trusted academic partner. We provide expert support to students across Germany with quality assignment assistance.'); ?>
<?php $__env->startSection('canonical', config('app.app_url') . Request::path()); ?>
<?php $__env->startSection('schema-script'); ?>

    <script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "<?php echo $__env->yieldContent('title', ''); ?>",
    "url": "<?php echo $__env->yieldContent('canonical'); ?>",
    "logo": "https://assignmenthelperdeutsch.de/public/imgs/logo-header.webp",
    "sameAs": [
        "https://www.facebook.com/assignmenthelperdeutsch/",
        "https://www.instagram.com/assignmenthelperdeutsch.de/"
    ]
    }
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="container mx-auto">
        <div class="mx-4 my-4">
            <div class="mx-auto  max-w-2xl lg:max-w-4xl  xl:max-w-6xl pb-6">
                <h1 class="text-4xl py-5 text-center">About Us
                </h1>
                <p class="my-4">
                    Here at Assignment Helper Deutsch we will likely assist students with their composition ventures. Regardless
                    of whether you are an undergrad, Master’s or PhD student, our perfect group of master scholarly authors
                    can expertly make your paper regardless of what field or claim to fame you require. After some time we
                    have gathered an extraordinary and expert group of scholars and editors who are accessible and upbeat to
                    help you nonstop. It doesn’t make a difference what time zone you live in or whether it’s day or night.
                </p>

                <p class="my-4 ">
                    Our writers can help you with any or the majority of the theory or exposition composing steps or with an
                    article or paper. Scholarly life surely has its difficulties, including extreme due dates, heaps of
                    homework and composing ventures, just as restricted time to destroy them. The composed pieces we make
                    will astound both you and your educators.
                </p>

            </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/about.blade.php ENDPATH**/ ?>