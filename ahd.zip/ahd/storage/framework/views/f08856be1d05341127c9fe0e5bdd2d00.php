
<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('partials.backend.admin-breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">

            <div class="invoice p-3 mb-3">
                <div class="row mb-2">
                    <div class="col-12">
                        <h4>
                            <?php echo e($invoice->ref_no); ?>

                            <small class="float-right">Date: <?php echo e(showDate($invoice->created_at)); ?></small>
                        </h4>
                    </div>
                </div>

                <div class="row invoice-info">
                    <div class="col-sm-12 invoice-col">
                        To
                        <address>
                            <strong><?php echo e($invoice->user->name); ?></strong><br>
                            Phone: <i> <?php echo e($invoice->order->phone); ?> </i><br>
                            Email: <i> <?php echo e($invoice->user->email); ?> </i>
                        </address>
                    </div>
                </div>
                <!-- /.row -->

                <!-- Table row -->
                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>Paper Type</th>
                                    <th>Academic Level</th>
                                    <th>Deadline</th>
                                    <th>Subtotal</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($invoice->order->paper_type ?? '-'); ?></td>
                                    <td><?php echo e($invoice->order->academic_level ?? '-'); ?></td>
                                    <td><?php echo e($invoice->order->deadline ?? '-'); ?></td>
                                    <td><?php echo e(addCurrency($invoice->amount)); ?></td>
                                    <td>
                                        <?php switch($invoice->status_id):
                                            case (4): ?>
                                                <span class="badge <?php echo e($invoice->status->css_class); ?>"><?php echo e($invoice->status->name); ?></span>
                                                <?php break; ?>
                                            <?php case (5): ?>
                                                <span class="badge <?php echo e($invoice->status->css_class); ?>"><?php echo e($invoice->status->name); ?></span>
                                                <?php break; ?>
                                            <?php default: ?>
                                                <span class="badge badge-default"> Default </span>
                                        <?php endswitch; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6 offset-sm-6">
                        <p class="lead">Total</p>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <tr>
                                    <th style="width:50%">Subtotal:</th>
                                    <td><?php echo e(addCurrency($invoice->amount)); ?></td>
                                </tr>
                                <tr>
                                    <th>Total:</th>
                                    <td><?php echo e(addCurrency($invoice->amount)); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/admin/invoices/show.blade.php ENDPATH**/ ?>