

<?php $__env->startSection('content'); ?>
    <p> Hello!</p>
    <p style="font-weight:bold ;font-size:20px"><?php echo e($data['user']->name); ?></p>
    <p>Greetings From <?php echo e(config('app.app_name')); ?></p>

    <?php if($data['flag'] == true): ?>
        <div style="margin-bottom: 15px;" class="">

            <div style="font-size: 17px; line-height: 140%; word-wrap: break-word;">
                <div>Your Account has been created successfully the
                    following are your login credentials.</div>
            </div>
            <p style="font-size: 14px; line-height: 130%; text-align: center;">
                <span style="font-size: 36px; line-height: 46.8px; font-family: 'Playfair Display', serif;"><span
                        style="line-height: 46.8px; font-size: 36px;">Account's Information</span></span>
            </p>
            <table>

                <tbody>
                    <tr>
                        <th
                            style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                            Email:</th>
                        <td
                            style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                            <strong> <?php echo e($order->email ?? '-'); ?>

                            </strong>
                        </td>
                    </tr>

                    <tr>
                        <th
                            style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                            Password:</th>
                        <td
                            style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                            <strong> <?php echo e($data['password'] ?? '-'); ?>

                            </strong>
                        </td>
                    </tr>
                    <tr>
                    </tr>

                </tbody>

            </table>
            <table cellspacing="0" cellpadding="0" border="0" align="center" style="margin:20px auto;">
                <tr>
                    <td bgcolor="#c8102e" style="border-radius:8px;">
                        <table cellspacing="0" cellpadding="0" border="0">
                            <tr>
                                <td align="center"
                                    style="font-size:16px; font-family:Arial, sans-serif; color:#ffffff; font-weight:bold; border: 4px solid ##0c1f4c;
                                 padding:12px 24px; display:block;">
                                    <a href="<?php echo e(route('login')); ?>" target="_blank"
                                        style="color:#ffffff; text-decoration:none; display:block;">
                                        Login
                                    </a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>
    <?php endif; ?>

    <p>Following are the details recieved for the order uploaded by you</p>

    <p style="font-size:25px ;font-bold ;margin-bottom:20px;text-align:center; color:black">Order Details</p>
    <table>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Name</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->name); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Email</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->email); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Phone</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->phone); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Country</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->country); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Paper Topic</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->paper_topic ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Paper Topic</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->paper_type ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Academic Level </th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong> <?php echo e($order->academic_level ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                No Of Pages </th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong> <?php echo e($order->number_of_pages ?? '-'); ?></strong>
            </td>

        </tr>
        <?php if(!empty($order->no_of_posters)): ?>
            <tr>
                <th
                    style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                    No Of Pages </th>
                <td
                    style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                    <strong> <?php echo e($order->no_of_posters ?? '-'); ?></strong>
                </td>

            </tr>
        <?php endif; ?>
        <?php if(!empty($order->no_of_slides)): ?>
            <tr>
                <th
                    style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                    No Of Pages </th>
                <td
                    style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                    <strong> <?php echo e($order->no_of_slides ?? '-'); ?></strong>
                </td>
            </tr>
        <?php endif; ?>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Reference Style </th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong> <?php echo e($order->reference_style ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                References </th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong> <?php echo e($order->no_of_references ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Deadline </th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong> <?php echo e($order->deadline ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Detail</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                <strong><?php echo e($order->detail ?? '-'); ?></strong>
            </td>
        </tr>
        <tr>
            <th
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #2e2f3b; font-size: 17px;">
                Total Cost</th>
            <td
                style="border: 2px solid #2e2f3b; text-align: left;padding: 8px;width: 14rem;color: #c8102e; font-size: 17px;">
                <strong><?php echo e(addCurrency($data['invoice']->amount)); ?></strong>
            </td>
        </tr>
    </table>

    <table cellspacing="0" cellpadding="0" border="0" align="center" style="margin:20px auto;">
        <tr>
            <td bgcolor="#c8102e" style="border-radius:8px;">
                <table cellspacing="0" cellpadding="0" border="0">
                    <tr>
                        <td align="center"
                            style="font-size:16px; font-family:Arial, sans-serif; color:#ffffff; font-weight:bold;
                             padding:12px 24px; display:block;">
                            <a href="<?php echo e(config('app.tawk_to')); ?>"
                                style="color:#ffffff; text-decoration:none; display:block;">
                                Live Chat
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <p>Kindly make the payment for the confirmation of your order</p>
    <table cellspacing="0" cellpadding="0" border="0" align="center" style="margin:20px auto;">
        <tr>
            <td bgcolor="#c8102e" style="border-radius:8px;">
                <table cellspacing="0" cellpadding="0" border="0">
                    <tr>
                        <td align="center"
                            style="font-size:16px; font-family:Arial, sans-serif; color:#ffffff; font-weight:bold; border: 4px solid ##0c1f4c;
                                 padding:12px 24px; display:block;">
                            <a style="color: white"
                                href="<?php echo e(route('invoice', ['reference' => $data['invoice']->ref_no])); ?>">
                                Pay <?php echo e(addCurrency($data['invoice']->amount)); ?>

                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <p>if you want to share more information or files related to your order , you can simply email us at
        <?php echo e(config('app.app_email')); ?></p>
    <p>For any further queries, feel free to contact us via email or Online Chat,</p>
    <p>Best Regards</p>
    <p>Customer Support,</p>
    <div style="text-align: left;margin-left:8px; margin-right: 8px;color:black"><?php echo e(config('app.app_name')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('email.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/email/order.blade.php ENDPATH**/ ?>