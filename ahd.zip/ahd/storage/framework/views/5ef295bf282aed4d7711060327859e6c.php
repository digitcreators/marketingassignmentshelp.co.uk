<?php $__env->startSection('title', 'Password Reset'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url') . Request::path()); ?>
<?php $__env->startSection('noindex'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('links'); ?>
    <script async src="https://www.google.com/recaptcha/api.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-theme">
    <div class="container mx-auto px-4 py-6">
        <div class="flex flex-col space-y-4   my-2 md:my-0 lg:flex-row lg:mx-4">
          
            <div class="panel w-full sm:w-[70%] lg:w-[35%] mx-auto py-5 ">
               <div class="my-auto ">
                <?php if(session('status')): ?>
                    <div class="bg-green-500 text-white py-2 text-center my-4 font-bold rounded-lg" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="rounded py-2 bg-red-100 text-red-600 padding-12 text-center my-4" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('password.email')); ?>" method="POST" class="bg-white shadow-md rounded-lg px-4 pt-2 pb-6 flex flex-col w-full space-y-2">
                    <?php echo csrf_field(); ?>
                       <div class="bg-gradient2 py-2 rounded-t-lg text-white">
                        <p class="text-3xl text-center font-semibold">
                            Send Reset Link
                        </p>
                    </div>
                    <div class="mb-1">
                        <input id="email" type="email"
                            class="form-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                            autocomplete="email" autofocus placeholder="<?php echo e(trans('global.login_email')); ?>" name="email"
                            value="<?php echo e(old('email', null)); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong class="text-red-400"><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Google Recaptcha -->
                    <div class="w-full">
                        <div class="g-recaptcha my-2" data-sitekey=<?php echo e(config('services.recaptcha.key')); ?>></div>
                    </div>

                    <button type="submit" class="btn btn-primary ">
                        <?php echo e(trans('Send Password Reset Link')); ?>

                    </button>


                </form>
               </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>