
<?php $__env->startSection('keyword', 'CIPD Assignment Help in Germany'); ?>
<?php $__env->startSection('title', 'High-Quality CIPD Assignment Help in Germany for All Levels '); ?>
<?php $__env->startSection('description',
    'Our CIPD assignment help in Germany gives you the confidence to submit work that can satisfy
    professional standards, whether it is Level 3, Level 5 or Level 7.'); ?>
<?php $__env->startSection('canonical', config('app.app_url') . Request::path()); ?>
<?php $__env->startSection('heroImage', ''); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="homepage-background bg-gray-800 py-12">
        <div class="container mx-auto">
            <div class="grid lg:grid-cols-12 lg:px-0 px-5 py-10 lg:gap-4 items-center">
                <!-- Left Column -->
                <div class="lg:col-span-7">
                    <h1 class="text-4xl font-bold">Step Into the HR World with Reliable
                        <span class="text-primary">CIPD Assignment Help in Germany</span>
                    </h1>
                    <p class="py-5">
                        For more than 15 years, Assignmenthelperdeutsch.de have been supporting students in achieving
                        outstanding performance in their CIPD qualifications, therefore simplifying the route to HR success.
                        400+ assignment helpers, 200+ thesis helpers and 100+ essay writers make up our committed team.
                    </p>
                    <?php echo $__env->make('partials.frontend.calculator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-span-12 lg:col-span-5 mt-4 lg:mt-0">
                    <img class="ml-auto" src="<?php echo e(asset('imgs/hero-girl.webp')); ?>" width="412" height="412" alt="Hero Girl"
                        title="Hero Girl" />
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <?php echo $__env->make('partials.frontend.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Feature End -->

    <section class="relative z-0 bg-theme procedure-sec py-10 px-5">
        <div class="container mx-auto">
            <!-- text div -->
            <div class="space-y-5 text-center">
                <h2 class="text-4xl font-semibold ">
                    Why Students Choose <span class="span-header"> Our CIPD Assignment Help Germany?</span>
                </h2>
                <p class=" mt-3">
                    With us, your work is in capable hands, so you don't have to worry about a thing. You will receive your
                    work on time, done with care and expertise.
                </p>
            </div>
            <div class="mt-8">
                <!-- Process 1 - Bootstrap Brain Component -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-center py-5">
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">
                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/quality-work.gif')); ?>" alt="Quality Work" width="100"
                                    height="100" title="Quality Work" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Top-Quality Work</h3>
                        <p class="text-sm">
                            You get the best structured papers completed with in-depth research, proper formatting, and
                            custom-crafted according to your specifications.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class=" flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/academic-writer.gif')); ?>" alt="Qualified Writers" width="100"
                                    height="100" title="Qualified Writers" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Pro Academic Writers </h3>
                        <p class="text-sm">
                            We select writers after a rigorous hiring process who are highly trained and experienced,
                            familiar with the grading criteria and academic standards.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/countless-edits.gif')); ?>" alt="Multiple Edits" width="100"
                                    height="100" title="Multiple Edits" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Countless Edits</h3>
                        <p class="text-sm">
                            We don't just stop after delivering the assignment, but offer support until you are fully
                            satisfied, so reach out for revisions.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/affordable-prices.gif')); ?>" alt="Economical Pricing" width="100"
                                    height="100" title="Economical Pricing" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Student-Friendly Pricing</h3>
                        <p class="text-sm">
                            We offer a fair pricing structure, ensuring you receive the best value for your money. No hidden
                            or surprise charges.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-10 px-8">
        <div class="container mx-auto">
            <div class="my-5">
                <div class="grid grid-cols-1 lg:grid-cols-2 lg:gap-6 gap-0 items-center">
                    <div class="lg:px-8">
                        <img class="hide-on-mobile" src="<?php echo e(asset('imgs/content.webp')); ?>" width="500" height="500" alt="CIPD Levels"
                            title="CIPD Levels" />
                    </div>
                    <div class="tabs lg:mt-0 mt-4">
                        <div class="flex flex-row flex-wrap gap-2">
                            <input id="tab-one" type="radio" name="tabs" class="peer/tab-one opacity-0 absolute"
                                checked />
                            <label for="tab-one"
                                class="bg-primary-one text-white peer-checked/tab-one:text-black peer-checked/tab-one:bg-amber-200 cursor-default lg:p-4 p-2 rounded-lg block">
                                CIPD Level 3
                            </label>

                            <input id="tab-two" type="radio" name="tabs" class="peer/tab-two opacity-0 absolute" />
                            <label for="tab-two"
                                class="bg-primary-one text-white peer-checked/tab-two:text-black peer-checked/tab-two:bg-amber-200 cursor-default lg:p-4 p-2 rounded-lg block">
                                CIPD Level 5
                            </label>

                            <input id="tab-three" type="radio" name="tabs" class="peer/tab-three opacity-0 absolute" />
                            <label for="tab-three"
                                class="bg-primary-one text-white peer-checked/tab-three:text-black peer-checked/tab-three:bg-amber-200 cursor-default lg:p-4 p-2 rounded-lg block">
                                CIPD Level 7
                            </label>
                            <div class="basis-full h-0"></div>

                            <div class="hidden peer-checked/tab-one:block py-4 w-full">
                                <h2 class="text-4xl font-semibold pb-2">
                                    Easy Guidance for Beginners Taking <span class="span-header">
                                        On CIPD Level 3
                                    </span>
                                </h2>
                                <p class="py-2">
                                    We understand that starting your CIPD journey at Level 3 could feel rather daunting but
                                    with us, you don't have to worry about anything. Our writers make sure your project
                                    satisfies both CIPD standards and your own learning objectives by meticulously following
                                    your directions. Plus, our online system gives you complete peace of mind, while every
                                    submission is designed to match your demands perfectly. With our assistance, you don’t
                                    just meet deadlines, but it's also about preparing for success in your HR career.

                                </p>
                            </div>
                            <div class="hidden peer-checked/tab-two:block py-4 w-full">
                                <h2 class="text-4xl font-semibold pb-2">
                                    Friendly Support for Every Step of <span class="span-header"> Your CIPD Level 5 Journey
                                    </span>
                                </h2>
                                <p class="py-2">
                                    Every project is carefully crafted to help you meet CIPD Level 5 requirements while also
                                    making concepts and theories easy to understand. Our professional CIPD assignment
                                    writers stand out thanks to their personalised approach, focusing on your specific needs
                                    rather than providing the same material to everyone. In addition, our team is friendly
                                    and accessible whenever you need support. If you feel stuck at any point or are unsure
                                    where to begin, reach out to us and we will guide you every step of the way.
                                </p>
                            </div>
                            <div class="hidden peer-checked/tab-three:block py-4 w-full">
                                <h2 class="text-4xl font-semibold pb-2">
                                    Practical, Clear and Reliable Help for <span class="span-header">CIPD Level 7
                                        Assignments
                                    </span>
                                </h2>
                                <p class="py-2">
                                    Your CIPD Level 7 projects become more insightful with our support, as we connect you
                                    with experienced CIPD assignment writers in Germany who have in-depth knowledge of HR
                                    and strictly follow academic requirements. They incorporate real-world HR examples to
                                    make your work even more credible and relevant. We offer personalised assistance
                                    designed to help you learn effectively while achieving high grades in your CIPD studies.
                                    With your tasks in the hands of reliable professionals, you can progress through Level 7
                                    without unnecessary stress.
                                </p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="<?php echo e(route('order')); ?>" class="order-link">
                                Order CIPD Assignment Now!
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <!-- Writers Start -->
    <section class="professional-experts bg-theme container-fluid py-8">
        <div class="container mx-auto px-5 lg:px-0">
            <div class="text-center mx-auto pb-3">
                <h2 class="text-4xl font-semibold py-5">
                    Connect with Our Skilled <span class="span-header"> Assignment Writers in Germany</span>
                </h2>
            </div>
            <?php echo $__env->make('partials.frontend.writers-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <!-- Writers End -->

    <!-- Counter -->
    <section class="counter px-4 md:px-10 lg:px-20 mx-auto py-5 lg:mb-8">
        <div class="container py-5 mx-auto">
            <h3 class="text-3xl md:text-4xl text-center lg:mt-5 font-bold">
                Your Assignment Success in 4 Easy Steps
            </h3>
            <p class="py-3 text-center">
                Get your assignment ready on time without any hassles.
            </p>
            <?php echo $__env->make('partials.frontend.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <!-- End counter -->

    <!-- CTA Section -->
    <section class="cta-section my-10">
        <div class="container mx-auto py-7 lg:px-0 px-5">
            <div class="grid lg:grid-cols-12 items-center">
                <div class="lg:col-span-7 w-full">
                    <h2 class="lg:text-4xl text-3xl text-white">
                        Get High Marks with Authentic CIPD Assignments Delivered Right on Time!
                    </h2>
                    <p class="py-5 text-white ">
                        Why worry about deadlines when you may depend on us? Our experienced CIPD writers produce
                        assignments suited to your level that are well-structured and custom-written.
                    </p>
                    <div class="lg:flex md:flex grid gap-4 pt-3">
                        <a href="<?php echo e(route('order')); ?>" class="order-link">
                            Place An Order Now
                        </a>
                        <a href="javascript:void(Tawk_API.toggle())" class="click-btn btn-chat">
                            Chat Now
                        </a>
                    </div>
                </div>
                <div class="relative lg:col-span-5 lg:block hidden">
                    <div class="cta-image">
                        <img src="<?php echo e(asset('imgs/cta-fold.webp')); ?>" class="cipd image" width="400" height="416"
                            title="CTA" alt="CTA">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Section -->

    <!-- Four paragrapgh -->
    <section class="four-sec overflow-hidden px-5 py-10">
        <div class="lg:px-10 px-2">
            <div class="con-main">

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 ">
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Advance in Your HR Career with Professional CIPD Assignment Writers in Germany
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                CIPD assignments can be demanding, particularly if you have to juggle between your classes,
                                personal life and sometimes work. This is why Assignment Helper Deutsch is here to lighten
                                your workload a bit so that you can focus on other important stuff as well. Our competent
                                writers take the time to produce engaging CIPD assignments that incorporate real-life HR
                                examples. This helps you not only submit your work but also understand theories and
                                concepts. Every project is created from the ground up and adjusted to fit your course
                                specifications. Our specialists guarantee that the work adheres to the specifications and
                                CIPD guidelines, regardless of the subject.
                            </p>
                            <p class="text-base py-3">
                                Moreover, personalised assistance is one of the aspects of our service that clients really
                                appreciate. You may talk to your assigned writer, seek modifications, or even receive advice
                                on how to improve writing and researching skills. We don't just focus on completing your
                                tasks, but also aim to help you learn and grow in the process. Our subject-specific writers
                                craft first-rate assignments on any topic, whether it is employee relations, talent
                                management, organisational learning or any other.
                            </p>
                        </div>
                    </div>
                    <div class=" ">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Dependable German CIPD Assignment Assistance That Enhances Your Confidence
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                We understand that students have to manage personal commitments, job and studies at the same
                                time. Our CIPD assignment writing service frees you from the never-ending pressure of
                                deadlines. We adjust to your CIPD level, whether it is Level 3, Level 5, or Level 7 and
                                develop assignments suited to your specific needs. Our meticulousness sets our CIPD
                                assistance apart. Every aspect is carefully managed so you won't lose marks on minor
                                blunders.
                            </p>
                            <p class="text-base py-3">
                                We believe that assignments help you understand how actual HR operations are conducted in
                                companies. Your project will include real-world examples directly relevant to workplace
                                situations, enabling you to better comprehend the concepts. These ideas enhance the
                                relevance of your work to the modern workplace and strengthen it. This helps you acquire
                                abilities that will be applicable in your HR profession. Furthermore, our expert writers
                                understand the demands of all CIPD levels and ensure that everything is done in accordance
                                with the requirements. In addition to that, you can contact us for 
                                <a class="sparkle-awd" href="<?php echo e(route('thesis')); ?>">thesis writing</a> and
                                <a class="sparkle-awd" href="<?php echo e(route('dissertation')); ?>">dissertation writing</a>, 
                                too, if you want us to help you with that.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Custom Online CIPD Assignment Writing Services for Stress-Free Learning
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                Our CIPD Assignment Help is based on customisation. Every project we work on is done from
                                scratch and is moulded to meet your specific demands, learning objectives, and university
                                criteria. You get an original piece of work rather than a standard paper, which is done
                                according to your specific requirements. The best part? All of our help is online. You are
                                only a few clicks away from getting your assignment completed. There is no necessity to
                                travel and waste any of your precious time. The process is fast, easy, and available from
                                anywhere in Germany, whether you are located in Frankfurt, Berlin or Düsseldorf. So, reach
                                out to us whenever you feel stuck.
                            </p>
                            <p class="text-base py-3">
                                Our online platform also helps to streamline communication. Revisions are possible, you can
                                track the progress of your work, and also converse with our team. We offer countless edits
                                for your complete satisfaction. Our writers will adapt to your request, whether you want
                                your work formatted in a particular manner or a certain writing style that you want us to
                                follow. This guarantees you get exactly what you have expected.
                            </p>
                        </div>
                    </div>
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Get Better Grades With Our Affordable CIPD Assignment Writing Help
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                CIPD assignments call for thorough HR knowledge. That's why our CIPD assignment writing
                                service is driven by a group of committed writers who specialise in human resources and
                                people management. Every writer is chosen for their capacity to define challenging HR ideas
                                and theories in a simple manner, making your assignments easy to understand and also
                                allowing you to grasp concepts well, which is going to aid you in further CIPD tasks as
                                well.
                            </p>
                            <p class="text-base py-3">
                                Knowing that students typically struggle with expenses and end up not receiving academic
                                assistance even when they need it most. For this reason, to make things easier for them, we
                                have kept our services cost-effective. We want to help every student without adding
                                financial stress. Our pricing is reasonable, honest, and customised to meet your budget.
                                Everything is crystal clear, and there are no hidden charges on our platform that would
                                disappoint you. Selecting our personalised CIPD assignment assistance not only saves time
                                but also lets you rest easier. Besides, you can get help with other tasks as well on our
                                platform, such as <a class="sparkle-awd" href="<?php echo e(route('mba')); ?>">MBA assignments</a> 
                                and <a class="sparkle-awd" href="<?php echo e(route('university')); ?>">university assignments</a>.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="mt-8 flex justify-center lg:gap-8 gap-6 mt-5 py-5">
                    <a href="<?php echo e(route('order')); ?>" class="order-link">
                        Place An Order
                    </a>
                </div>
            </div>
        </div>
    </section><!-- Four paragrapgh -->

    <!-- Testimonial Start -->
    <section class="relative bg-theme container-fluid py-8">
        <div class="container mx-auto pb-3">
            <div class="text-center mx-auto">
                <h3 class="text-4xl font-semibold py-5">
                    <span class="span-header">See Honest Feedback </span> from Real Clients

                </h3>
            </div>
            <?php echo $__env->make('partials.frontend.testimonial-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </section>
    <!-- Testimonial End -->

    <!-- FAQ -->
    <section class="faqs px-2 md:px-12 lg:px-20 mx-auto py-8">
        <div class="container mx-auto px-3">
                        <h3 class="lg:text-4xl text-3xl text-uppercase text-center py-5">
                Student FAQs –  <span class="span-header"> Fast and Clear Solutions</span>
            </h3>
            <div class="grid lg:grid-cols-2 md:grid-cols-1 grid-cols-1 items-center">
                <div class="text-center">
                    <img src="<?php echo e(asset('imgs/faq.webp')); ?>" class="img-fluid mx-auto hide-on-mobile" alt="Frequently Asked Questions"
                        title="Frequently Asked Questions" width="450" height="560">
                </div>
                <div class="space-y-2 py-5">
                    <div class="content border-b faq-internal-styling" data-no="0">
                        <div class="questions cursor-pointer flex p-3 font-bold active" data-no="0">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">1-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    What is included in your CIPD assignment help in Germany?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-minus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide0">
                            Everything is included in our CIPD assignment help in Germany, including prompt customer
                            support, countless revisions, high-quality plagiarism-free work, online consultations and fast
                            delivery.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="1">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="1">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">2-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Do you cover all CIPD levels, including Level 3, Level 5, and Level 7?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide1" style="display: none;">
                            Yes, we cover all CIPD levels, including Level 3, Level 5 and Level 7. Our CIPD assignment
                            writers Germany customise every assignment according to your level and its requirements.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="2">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="2">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">3-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Do you follow CIPD guidelines and assessment criteria?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide2" style="display: none;">
                            Yes, we strictly follow CIPD guidelines and assessment criteria in every task. You will never
                            have to concern yourself about referencing, structure or anything else. Every CIPD project is
                            created with accuracy, creativity, and attention to detail, enabling you to satisfy academic
                            criteria.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="3">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="3">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">4-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    How do you ensure plagiarism-free CIPD assignments?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide3" style="display: none;">
                            Our expert assignment helpers in Germany produce all work from scratch after conducting thorough
                            research on the topic and do not copy from other sources, ensuring your work is 100% original
                            and plagiarism-free.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="4">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="4">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">5-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Can you meet urgent deadlines for CIPD tasks?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide4" style="display: none;">
                            Yes, we can meet urgent deadlines for CIPD tasks. Our fast-paced writers will do your assignment
                            within a short deadline without sacrificing the quality of your work.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="5">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="5">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">6-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Do your writers have experience in HR and people management?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide5" style="display: none;">
                            Yes, our writers have extensive experience in people management and HR. To improve your
                            projects, they blend practical examples with academic knowledge. You receive work that is
                            relevant and completely in line with CIPD standards with their help.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="6">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="6">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">7-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Can you help with CIPD case studies and reports?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide6" style="display: none;">
                            Sure! We specialise in both CIPD case studies and reports, creating them with great focus on
                            academic demands and actual HR situations. Our writers have a great capacity to carefully
                            prepare, organise, and provide well-written solutions that comply with CIPD requirements.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="7">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="7">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">8-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Do you assist with CIPD reflective journals?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide7" style="display: none;">
                            Yes, our team guides you to express your learning and experiences in CIPD reflective journals.
                            You may turn in reflective journals that reflect critical thinking, connect theory with HR
                            practices and are consistent with CIPD assessment criteria with our assistance.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="8">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="8">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">9-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Do you provide referencing in Harvard style for CIPD work?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide8" style="display: none;">
                            Yes, we provide referencing in Harvard style for all CIPD work. Every source used in your work
                            is painstakingly cited by our writers. The in-text citations and reference list are created
                            according to CIPD and academic standards.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="9">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="9">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">10-</p>
                            </div>
                            <div class="heading w-[85%] ">
                                <h4 class="text-lg md:font-semibold">
                                    Are your CIPD assignment services affordable for students in Germany?
                                </h4>
                            </div>
                            <div class="icons w-[10%] text-right">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base" id="openSlide9" style="display: none;">
                            Yes, our CIPD assignment services are affordable for students in Germany. We offer
                            student-friendly packages to fit your budget and needs. There are no hidden charges, and we
                            never compromise on quality, even at reasonable prices.
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- FAQ -->

    <!-- CTA Section -->
    <section class="cta-form lg:p-5 p-3">
        <div class="rounded-lg lg:py-0 py-8 ">
            <div class="grid lg:grid-cols-12 items-center">
                <div class="lg:col-span-4 lg:block hidden">
                    <img src="<?php echo e(asset('imgs/form-girls.png')); ?>" class="image mx-auto" width="388" height="349"
                        title="CTA" alt="CTA" loading="lazy">
                </div>
                <div class="lg:col-span-8 lg:px-10">
                    <h2 class="lg:text-4xl text-3xl text-white lg:text-left text-center pb-3">
                        Want Perfect Grades? Our Experts Make It Possible
                    </h2>
                    <div class="mt-5">
                        <?php echo $__env->make('partials.frontend.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Section -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabPanels = document.querySelectorAll('.tab-panel');

        tabButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                // reset all
                tabButtons.forEach(b => {
                    b.classList.remove('bg-white', 'text-gray-700', 'dark:bg-gray-800',
                        'dark:text-white', 'shadow');
                    b.setAttribute('aria-selected', 'false');
                });
                tabPanels.forEach(panel => panel.classList.add('hidden'));

                // activate clicked
                btn.classList.add('bg-white', 'text-gray-700', 'dark:bg-gray-800', 'dark:text-white',
                    'shadow');
                btn.setAttribute('aria-selected', 'true');
                document.getElementById(btn.dataset.tab).classList.remove('hidden');
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/services/cipd-assignment.blade.php ENDPATH**/ ?>