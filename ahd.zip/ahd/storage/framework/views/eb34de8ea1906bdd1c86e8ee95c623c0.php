
<?php $__env->startSection('title', 'MBA Assignments Help UK Sitemap - Navigate Our Services'); ?>
<?php $__env->startSection('description', 'Browse our full site layout for MBA Assignments Help UK. Easily find key pages like services, samples, reviews, and ordering information.'); ?>
<?php $__env->startSection('canonical', config('app.app_url') . Request::path()); ?>

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto py-5">
        <h1 class="text-4xl pt-5">Sitemap</h1>
    </section>
    <section class="container mx-auto py-5">
        <div class="bg-gradient-flip dark:bg-gradient-flip-one rounded">
            <h2 class="text-white text-2xl font-semibold p-4 text-center sm:text-left">
                Our Company
            </h2>
        </div>

        <div class="mx-2 my-4">
            <ul class="my-6 grid grid-cols-1 lg:grid-cols-4 text-center sm:text-left gap-3 sitemap-ul">
                <li>
                    <a href="<?php echo e(route('home')); ?>">
                        Home
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('about')); ?>">
                        About
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('contact')); ?>">
                        Contact
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('reviews')); ?>">
                        Reviews
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('order')); ?>">
                        Order Now
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('sitemap')); ?>">
                        Sitemap
                    </a>
                </li>
            </ul>
        </div>

        <div class="bg-gradient-flip dark:bg-gradient-flip-one rounded">
            <h2 class="text-white text-2xl font-semibold p-4 text-center sm:text-left">
                Our Legal Policies
            </h2>
        </div>

        <div class="mx-2 my-4">
            <ul class="my-6 grid grid-cols-1 lg:grid-cols-4 text-center sm:text-left gap-3 sitemap-ul">
                <li>
                    <a href="<?php echo e(route('privacy')); ?>">
                        Revision Policy
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('terms')); ?>">
                        Terms & Conditions
                    </a>
                </li>
            </ul>
        </div>

        <div class="bg-gradient-flip dark:bg-gradient-flip-one rounded">
            <h2 class="text-white text-2xl font-semibold p-4 text-center sm:text-left">
                Our Services
            </h2>
        </div>
        <div class="mx-2 my-4">
            <ul class="my-6 grid grid-cols-1 lg:grid-cols-4 text-center sm:text-left gap-3 sitemap-ul">
                <li class="">
                    <a href="<?php echo e(route('mba-dissertation')); ?>" class="btn btn-link">
                        MBA Dissertation
                    </a>
                </li>
                <li class="">
                    <a href="<?php echo e(route('mba-essay')); ?>" class="btn btn-link">
                        MBA Essay
                    </a>
                </li>
                <li class="">
                    <a href="<?php echo e(route('mba-personal')); ?>" class="btn btn-link">
                        MBA Personal Statement
                    </a>
                </li>
                <li class="">
                    <a href="<?php echo e(route('write-my-assignment')); ?>" class="btn btn-link">
                        Write My MBA Assignment
                    </a>
                </li>
            </ul>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/legal/sitemap.blade.php ENDPATH**/ ?>