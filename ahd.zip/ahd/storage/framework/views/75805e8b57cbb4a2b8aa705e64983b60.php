
<?php $__env->startSection('keyword', 'Thesis Writing Services in Germany'); ?>
<?php $__env->startSection('title', 'Thesis Writing Services in Germany – Submit with Confidence!'); ?>
<?php $__env->startSection('description',
    'Struggling with your thesis? Our Thesis Writing Services in Germany support you with research,
    writing, editing, and proofreading for a confident submission.'); ?>
<?php $__env->startSection('canonical', config('app.app_url') . Request::path()); ?>
<?php $__env->startSection('heroImage', ''); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="homepage-background bg-gray-800 py-12">
        <div class="container mx-auto">
            <div class="grid lg:grid-cols-12 lg:px-0 px-5 py-10 lg:gap-4 items-center">
                <!-- Left Column -->
                <div class="lg:col-span-7">
                    <h1 class="text-4xl font-bold">Turn Your Research into a Powerful Paper with <span
                            class="text-primary">Our Certified Thesis Writing Services in Germany

                        </span>
                    </h1>
                    <p class="py-5">
                        For over 15 years, Assignmenthelperdeutsch.de has been helping German students achieve academic
                        success through dependable german thesis writing services. Committed to providing quality, our
                        robust team comprises 200+ thesis experts, 400+ assignment helpers, and 100+ essay writers.
                    </p>
                    <?php echo $__env->make('partials.frontend.calculator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-span-12 lg:col-span-5 mt-4 lg:mt-0">
                    <img class="ml-auto" src="<?php echo e(asset('imgs/hero-girl.webp')); ?>" width="412" height="412" alt="Hero Girl"
                        title="Hero Girl" />
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <?php echo $__env->make('partials.frontend.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Feature End -->

    <section class="relative z-0 bg-theme procedure-sec py-10 px-5">
        <div class="container mx-auto">
            <!-- text div -->
            <div class="space-y-5 text-center">
                <h2 class="text-4xl font-semibold ">
                    Why Students in Germany Go For <span class="span-header">Our Thesis Writing Services DE?
                    </span>
                </h2>
                <p class=" mt-3">
                    With us, your work is in capable hands, so you don't have to worry about a thing. You will receive your
                    work on time, done with care and expertise.
                </p>
            </div>
            <div class="mt-8">
                <!-- Process 1 - Bootstrap Brain Component -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-center py-5">
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">
                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/quality-work.gif')); ?>" alt="Quality Work" width="100"
                                    height="100" title="Quality Work" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Exceptional Thesis Quality</h3>
                        <p class="text-sm">
                            You get the best structured papers completed with in-depth research, proper formatting, and
                            custom-crafted according to your specifications.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class=" flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/academic-writer.gif')); ?>" alt="Qualified Writers" width="100"
                                    height="100" title="Qualified Writers" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Highly Experienced Writers </h3>
                        <p class="text-sm">
                            We select thesis writers DE after a rigorous hiring process who are highly trained and
                            experienced, familiar with the grading criteria and academic standards.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/countless-edits.gif')); ?>" alt="Multiple Edits" width="100"
                                    height="100" title="Multiple Edits" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Multiple Edits</h3>
                        <p class="text-sm">
                            We don't just stop after delivering the assignment, but offer support until you are fully
                            satisfied, so reach out for revisions.
                        </p>
                    </div>
                    <div class="process-box bg-white p-4 rounded-lg flex flex-col items-center gap-y-4 text-center">
                        <div class="flex items-center justify-center">

                            <div class="image-box">
                                <img src="<?php echo e(asset('imgs/affordable-prices.gif')); ?>" alt="Economical Pricing" width="100"
                                    height="100" title="Economical Pricing" class="" />
                            </div>
                        </div>
                        <h3 class="font-bold text-lg">Affordable Solutions</h3>
                        <p class="text-sm">
                            We offer a fair pricing structure, ensuring you receive the best value for your money. No hidden
                            or surprise charges.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-10 px-8">
        <div class="container mx-auto">
            <div class="my-5">
                <!-- Process 1 - Bootstrap Brain Component -->
                <div class="grid grid-cols-1 lg:grid-cols-2 lg:gap-6 gap-0 items-center">
                    <div class="lg:px-8">
                        <img class="hide-on-mobile" src="<?php echo e(asset('imgs/content.webp')); ?>" width="500" height="500" alt="Thesis Writing Services"
                            title="Thesis Writing Services" />
                    </div>
                    <div class="lg:mt-0 mt-4">
                        <h2 class="text-4xl font-semibold pb-2">
                            Achieve Top Results with
                            <span class="span-header">Our Thesis Writing Services Help Germany</span>
                        </h2>
                        <p class="py-2">
                            Many students consider writing a thesis among the most difficult obstacles in their academic
                            careers. However, it also presents a great opportunity to develop and hone vital skills that you
                            will need in the near future. By choosing us, you will have professionals by your side, leading
                            you at every step. You acquire knowledge of how to properly structure ideas, examine sources,
                            and clearly convey results. With our thesis writing help Germany, we aim to make you excel in
                            both writing and research.
                        </p>
                        <div class="mt-5">
                            <a href="<?php echo e(route('order')); ?>" class="order-link">
                                Start Your Thesis Today!
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <!-- Writers Start -->
    <section class="professional-experts bg-theme container-fluid py-8">
        <div class="container mx-auto px-5 lg:px-0">
            <div class="text-center mx-auto pb-3">
                <h2 class="text-4xl font-semibold py-5">
                    Connect with Our Skilled <span class="span-header"> Thesis Writers in Germany</span>
                </h2>
            </div>
            <?php echo $__env->make('partials.frontend.writers-3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <!-- Writers End -->

    <!-- Counter -->
    <section class="counter px-4 md:px-10 lg:px-20 mx-auto py-5 lg:mb-8">
        <div class="container py-5 mx-auto">
            <h3 class="text-3xl md:text-4xl text-center lg:mt-5 font-bold">
                Your Thesis Success in 4 Simple Steps
            </h3>
            <p class="py-3 text-center">
                Get your thesis ready on time without any hassles.
            </p>
            <?php echo $__env->make('partials.frontend.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <!-- End counter -->

    <!-- CTA Section -->
    <section class="cta-section my-10">
        <div class="container mx-auto py-7 lg:px-0 px-5">
            <div class="grid lg:grid-cols-12 items-center">
                <div class="lg:col-span-7 w-full">
                    <h2 class="lg:text-4xl text-3xl text-white">
                        Get Excellent Grades in Germany with Professional Thesis Writing Assistance
                    </h2>
                    <p class="py-5 text-white ">
                        Why stress yourself when our DE Thesis Specialists are here to lead you? We produce exemplary theses
                        that astound professors and satisfy your university's requirements.
                    </p>
                    <div class="lg:flex md:flex grid gap-4 pt-3">
                        <a href="<?php echo e(route('order')); ?>" class="order-link">
                            Place An Order Now
                        </a>
                        <a href="javascript:void(Tawk_API.toggle())" class="click-btn btn-chat">
                            Chat Now
                        </a>
                    </div>
                </div>
                <div class="relative lg:col-span-5 lg:block hidden">
                    <div class="cta-image">
                        <img src="<?php echo e(asset('imgs/cta-fold.webp')); ?>" class="thesis image" width="400" height="416"
                            title="CTA" alt="CTA">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Section -->

    <!-- Four paragrapgh -->
    <section class="four-sec overflow-hidden px-5 py-10">
        <div class="lg:px-10 px-2">
            <div class="con-main">

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 ">
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Amaze Your Professor with Our High Standard German Thesis Writing Services
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                At Assignment Helper Deutsch, we provide guidance and support to help you transform your
                                ideas into a well-organised, high-quality thesis. Our team of thesis writers in Germany is
                                aware of the difficulties students have. They ensure your thesis meets your university’s
                                standards and grading requirements by carefully following the directions. Every thesis we
                                write is unique, properly formatted, and suited to your particular needs. We also ensure
                                that you remain informed throughout the process. Receive updates about your thesis, engage
                                in discussions with your writer, and request modifications until you are completely
                                satisfied. Your thesis will appropriately represent your thoughts and knowledge.
                            </p>
                            <p class="text-base py-3">
                                Whatever your academic level and research area, we have subject matter experts who offer top
                                quality thesis writing service in Germany. They have strong academic backgrounds, holding
                                advanced degrees such as MS, MPhil, and PhD from leading institutions. By choosing our
                                thesis writing services, you can relax a bit and save time, allowing you to focus on other
                                important things. Let us help you achieve your academic objectives and move boldly toward
                                your success.
                            </p>
                        </div>
                    </div>
                    <div class=" ">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Make Your Graduation Dreams Real With Our Masters Thesis Writing Help in Germany
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                Don't know how to present your ideas clearly and develop solid arguments? Worry no more.
                                AssignmentHelperDeutsch helps you overcome the difficulties that you usually face while
                                composing your paper and guarantees that your work satisfies the academic criteria. We match
                                you with thesis writers DE who are experts in research as well as knowledgeable about
                                academic writing. Every thesis we write is unique, thoroughly researched, and tailored to
                                your university's specific criteria.
                            </p>
                            <p class="text-base py-3">
                                Additionally, we offer editing, proofreading, plagiarism checks, formatting, referencing,
                                and online consultations. You can request countless edits till you get the work that is up
                                to your expectations. We don't charge any money for that. Our writers provide Master Thesis
                                Writing Service in Germany whether you are stuck on a chapter or don’t know where to begin.
                                Our aim is to help you have a more efficient and less stressful process, whether you live in
                                Stuttgart, Berlin, or Frankfurt. Students also come to us for other services, such as
                                <a class="sparkle-awd" href="<?php echo e(route('dissertation')); ?>">dissertation writing</a> and
                                <a class="sparkle-awd" href="<?php echo e(route('essay')); ?>">essay writing</a>. Through
                                expert advice and individual attention, we support you in developing a thesis that wows your
                                professors and helps you score the highest marks.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Top Quality Thesis Writing Service in Germany for Brilliant Academic Performance
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                Writing a thesis for students is among the most difficult tasks, as they need to conduct
                                extensive research, organise chapters, etc. Our thesis writing service DE is here to remove
                                that stress and simplify the procedure for you. Our writers carefully create every thesis to
                                suit your academic level, topic, and university rules. We keep you in control of your
                                thesis. You receive updates regularly, can have direct discussions with your assigned
                                writer, and request modifications as many times as needed. This guarantees that your thesis
                                benefits from professional assistance while still seeming to be your own effort.
                            </p>
                            <p class="text-base py-3">
                                Moreover, we assist you every step of the way, not just deliver your work and leave. We are
                                here to provide appropriate advice and also Master Thesis Writing Service in Germany if you
                                are experiencing difficulties with any part of your thesis. Whether you are stuck on the
                                literature review, methodology or analysis, our writers will guide you through every section
                                and make your work polished and professional. Besides, we are not limited to thesis writing
                                and offer a range of services, such as <a class="sparkle-awd"
                                    href="<?php echo e(route('mba')); ?>">MBA assignments</a>
                                and <a class="sparkle-awd" href="<?php echo e(route('university')); ?>">University assignments</a>.
                            </p>
                        </div>
                    </div>
                    <div class="">
                        <h2 class="font-bold lg:px-5 md:text-2xl text-2xl">
                            Make Your Ideas Shine With Our PhD Thesis Writing Services in Germany
                        </h2>
                        <div class="py-3">
                            <p class="text-base py-3">
                                The standard and quality of your thesis will help influence how professors perceive your
                                research acumen and knowledge. This is the reason our thesis writing service in Germany aims
                                to produce work that not only satisfies academic criteria but also enhances your
                                professional profile. Our writers help you create a project that captures your abilities and
                                potential. We help your thesis convey uniqueness and depth. Your thesis turns into a tool
                                that emphasises your analytical thinking, writing ability, and research skills.
                            </p>
                            <p class="text-base py-3">
                                Every paper is uniquely created to match your research field and academic background,
                                whether it is social sciences, engineering, business or any other field. Selecting us means
                                you are not only getting your work done but are also investing in a paper that enhances your
                                career. We think your thesis should inspire interest and support your chosen discipline.
                                That's why we concentrate on creating research that is original, relevant, and effective. If
                                you are feeling lost in research or struggling with referencing, consider hiring our thesis
                                writers in Germany and see the difference they can make in your thesis journey.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="mt-8 flex justify-center lg:gap-8 gap-6 mt-5 py-5">
                    <a href="<?php echo e(route('order')); ?>" class="order-link">
                        Place An Order
                    </a>
                </div>
            </div>
        </div>
    </section><!-- Four paragrapgh -->

    <!-- Testimonial Start -->
    <section class="relative bg-theme container-fluid py-8">
        <div class="container mx-auto pb-3">
            <div class="text-center mx-auto">
                <h3 class="text-4xl font-semibold py-5">
                    <span class="span-header">See Honest Feedback </span> from Real Clients

                </h3>
            </div>
            <?php echo $__env->make('partials.frontend.testimonial-3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </section>
    <!-- Testimonial End -->

    <!-- FAQ -->
    <section class="faqs px-2 md:px-12 lg:px-20 mx-auto py-8">
        <div class="container mx-auto px-3">
                        <h3 class="lg:text-4xl text-3xl text-uppercase text-center py-5">
                Student FAQs –  <span class="span-header"> Fast and Clear Solutions</span>
            </h3>
            <div class="grid lg:grid-cols-2 md:grid-cols-1 grid-cols-1 items-center">
                <div class="text-center">
                    <img src="<?php echo e(asset('imgs/faq.webp')); ?>" class="img-fluid mx-auto hide-on-mobile" alt="Frequently Asked Questions"
                        title="Frequently Asked Questions" width="450" height="560">
                </div>
                <div class="space-y-2 py-5">
                    <div class="content border-b faq-internal-styling" data-no="0">
                        <div class="questions cursor-pointer flex p-3 font-bold active" data-no="0">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">1-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Are your thesis writers experienced in German academic standards?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-minus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base " id="openSlide0">
                            Our thesis writers strictly adhere to the academic guidelines of German universities and are
                            familiar with the formatting, structures, and citation styles used in these institutions. They
                            also offer multiple revisions for your complete satisfaction.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="1">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="1">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">2-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you provide both master’s and PhD thesis writing services in Germany?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide1">
                            Yes, we provide both master’s and PhD thesis writing services in Germany. Our experienced
                            writers possess expertise in handling all academic levels, with a strong focus on research,
                            writing, formatting, and referencing.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="2">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="2">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">3-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    How do you ensure plagiarism-free thesis content?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide2">
                            We have skilled writers who create plagiarism-free theses backed by deep research. They produce
                            everything from scratch and do not copy from other sources, making your work 100% original and
                            plagiarism-free.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="3">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="3">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">4-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    What is the average cost of thesis writing services in Germany?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide3">
                            Well, it depends on the length, complexity, deadline, and your academic level. However, we offer
                            student-friendly packages to fit your budget and needs.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="4">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="4">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">5-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    How long does it take to complete a thesis?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide4">
                            It depends on factors like the level, length, and complexity. However, we have fast-paced
                            writers who will complete your thesis within a short deadline without sacrificing the quality of
                            your work.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="5">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="5">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">6-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you offer thesis editing and proofreading services?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide5">
                            Yes, we offer thesis editing and proofreading services. To ensure your thesis is polished and
                            professional, our team meticulously examines grammar, structure, format, and referencing to
                            ensure it meets the highest standards.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="6">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="6">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">7-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Can you assist with thesis data analysis and interpretation?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide6">
                            Yes, we can assist with thesis data analysis and interpretation. Using SPSS, STATA, and NVivo,
                            among other tools, our professionals are proficient in both qualitative and quantitative
                            techniques. They ensure that your thesis is insightful and academically sound.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="7">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="7">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">8-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Are your thesis writing services available in Germany in both English and German?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide7">
                            Our thesis writing services in Germany are available in English only. Our writers ensure
                            flawless work with no grammatical mistakes, a professional academic tone and good vocabulary.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="8">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="8">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">9-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    Do you offer instalment payment plans for students?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide8">
                            Yes, we offer students flexible payment plans in instalments. Managing money while studying can
                            be difficult, so our plans are meant to lighten the load. This way, you receive excellent work
                            without financial worry.
                        </p>
                    </div>

                    <div class="content border-b faq-internal-styling" data-no="9">
                        <div class="questions cursor-pointer flex p-3 font-bold" data-no="9">
                            <div class="ml-2 mr-4 w-[5%]">
                                <p class="text-lg font-bold">10-</p>
                            </div>
                            <div class="heading w-[85%]">
                                <h4 class="text-lg md:font-semibold">
                                    What happens if I need revisions after submission?
                                </h4>
                            </div>
                            <div class="icons text-right w-[10%]">
                                <i class="fa fa-plus text-xl"></i>
                            </div>
                        </div>
                        <p class="openSlide text-base hidden" id="openSlide9">
                            You can request unlimited revisions after submission, free of charge, until you're happy with
                            your work. Our writers are always happy to revise your work if there's anything that needs
                            improvement.
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- FAQ -->

    <!-- CTA Section -->
    <section class="cta-form lg:p-5 p-3">
        <div class="rounded-lg lg:py-0 py-8 ">
            <div class="grid lg:grid-cols-12 items-center">
                <div class="lg:col-span-4 lg:block hidden">
                    <img src="<?php echo e(asset('imgs/form-girls.png')); ?>" class="image mx-auto" width="388" height="349"
                        title="CTA" alt="CTA" loading="lazy">
                </div>
                <div class="lg:col-span-8 lg:px-10">
                    <h2 class="lg:text-4xl text-3xl text-white lg:text-left text-center pb-3">
                        Aiming for Distinction? Our Team Knows the Way
                    </h2>
                    <div class="mt-5">
                        <?php echo $__env->make('partials.frontend.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ahd\resources\views/pages/services/thesis-writing.blade.php ENDPATH**/ ?>