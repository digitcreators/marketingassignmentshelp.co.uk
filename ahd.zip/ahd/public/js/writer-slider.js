(() => {
    "use strict";

    function e(e) {
        return null !== e && "object" == typeof e && "constructor" in e && e.constructor === Object
    }

    function t(s = {}, i = {}) {
        Object.keys(i).forEach((a => {
            void 0 === s[a] ? s[a] = i[a] : e(i[a]) && e(s[a]) && Object.keys(i[a]).length > 0 && t(s[a], i[a])
        }))
    }
    const s = {
        body: {},
        addEventListener() { },
        removeEventListener() { },
        activeElement: {
            blur() { },
            nodeName: ""
        },
        querySelector: () => null,
        querySelectorAll: () => [],
        getElementById: () => null,
        createEvent: () => ({
            initEvent() { }
        }),
        createElement: () => ({
            children: [],
            childNodes: [],
            style: {},
            setAttribute() { },
            getElementsByTagName: () => []
        }),
        createElementNS: () => ({}),
        importNode: () => null,
        location: {
            hash: "",
            host: "",
            hostname: "",
            href: "",
            origin: "",
            pathname: "",
            protocol: "",
            search: ""
        }
    };

    function i() {
        const e = "undefined" != typeof document ? document : {};
        return t(e, s), e
    }
    const a = {
        document: s,
        navigator: {
            userAgent: ""
        },
        location: {
            hash: "",
            host: "",
            hostname: "",
            href: "",
            origin: "",
            pathname: "",
            protocol: "",
            search: ""
        },
        history: {
            replaceState() { },
            pushState() { },
            go() { },
            back() { }
        },
        CustomEvent: function () {
            return this
        },
        addEventListener() { },
        removeEventListener() { },
        getComputedStyle: () => ({
            getPropertyValue: () => ""
        }),
        Image() { },
        Date() { },
        screen: {},
        setTimeout() { },
        clearTimeout() { },
        matchMedia: () => ({}),
        requestAnimationFrame: e => "undefined" == typeof setTimeout ? (e(), null) : setTimeout(e, 0),
        cancelAnimationFrame(e) {
            "undefined" != typeof setTimeout && clearTimeout(e)
        }
    };

    function r() {
        const e = "undefined" != typeof window ? window : {};
        return t(e, a), e
    }

    function n(e, t = 0) {
        return setTimeout(e, t)
    }

    function l() {
        return Date.now()
    }

    function o(e, t = "x") {
        const s = r();
        let i, a, n;
        const l = function (e) {
            const t = r();
            let s;
            return t.getComputedStyle && (s = t.getComputedStyle(e, null)), !s && e.currentStyle && (s = e.currentStyle), s || (s = e.style), s
        }(e);
        return s.WebKitCSSMatrix ? (a = l.transform || l.webkitTransform, a.split(",").length > 6 && (a = a.split(", ").map((e => e.replace(",", "."))).join(", ")), n = new s.WebKitCSSMatrix("none" === a ? "" : a)) : (n = l.MozTransform || l.OTransform || l.MsTransform || l.msTransform || l.transform || l.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), i = n.toString().split(",")), "x" === t && (a = s.WebKitCSSMatrix ? n.m41 : 16 === i.length ? parseFloat(i[12]) : parseFloat(i[4])), "y" === t && (a = s.WebKitCSSMatrix ? n.m42 : 16 === i.length ? parseFloat(i[13]) : parseFloat(i[5])), a || 0
    }

    function d(e) {
        return "object" == typeof e && null !== e && e.constructor && "Object" === Object.prototype.toString.call(e).slice(8, -1)
    }

    function c(...e) {
        const t = Object(e[0]),
            s = ["__proto__", "constructor", "prototype"];
        for (let a = 1; a < e.length; a += 1) {
            const r = e[a];
            if (null != r && (i = r, !("undefined" != typeof window && void 0 !== window.HTMLElement ? i instanceof HTMLElement : i && (1 === i.nodeType || 11 === i.nodeType)))) {
                const e = Object.keys(Object(r)).filter((e => s.indexOf(e) < 0));
                for (let s = 0, i = e.length; s < i; s += 1) {
                    const i = e[s],
                        a = Object.getOwnPropertyDescriptor(r, i);
                    void 0 !== a && a.enumerable && (d(t[i]) && d(r[i]) ? r[i].__swiper__ ? t[i] = r[i] : c(t[i], r[i]) : !d(t[i]) && d(r[i]) ? (t[i] = {}, r[i].__swiper__ ? t[i] = r[i] : c(t[i], r[i])) : t[i] = r[i])
                }
            }
        }
        var i;
        return t
    }

    function p(e, t, s) {
        e.style.setProperty(t, s)
    }

    function u({
        swiper: e,
        targetPosition: t,
        side: s
    }) {
        const i = r(),
            a = -e.translate;
        let n, l = null;
        const o = e.params.speed;
        e.wrapperEl.style.scrollSnapType = "none", i.cancelAnimationFrame(e.cssModeFrameID);
        const d = t > a ? "next" : "prev",
            c = (e, t) => "next" === d && e >= t || "prev" === d && e <= t,
            p = () => {
                n = (new Date).getTime(), null === l && (l = n);
                const r = Math.max(Math.min((n - l) / o, 1), 0),
                    d = .5 - Math.cos(r * Math.PI) / 2;
                let u = a + d * (t - a);
                if (c(u, t) && (u = t), e.wrapperEl.scrollTo({
                    [s]: u
                }), c(u, t)) return e.wrapperEl.style.overflow = "hidden", e.wrapperEl.style.scrollSnapType = "", setTimeout((() => {
                    e.wrapperEl.style.overflow = "", e.wrapperEl.scrollTo({
                        [s]: u
                    })
                })), void i.cancelAnimationFrame(e.cssModeFrameID);
                e.cssModeFrameID = i.requestAnimationFrame(p)
            };
        p()
    }

    function m(e, t = "") {
        return [...e.children].filter((e => e.matches(t)))
    }

    function f(e, t = []) {
        const s = document.createElement(e);
        return s.classList.add(...Array.isArray(t) ? t : [t]), s
    }

    function h(e, t) {
        return r().getComputedStyle(e, null).getPropertyValue(t)
    }

    function g(e) {
        let t, s = e;
        if (s) {
            for (t = 0; null !== (s = s.previousSibling);) 1 === s.nodeType && (t += 1);
            return t
        }
    }

    function v(e, t) {
        const s = [];
        let i = e.parentElement;
        for (; i;) t ? i.matches(t) && s.push(i) : s.push(i), i = i.parentElement;
        return s
    }

    function w(e, t, s) {
        const i = r();
        return s ? e["width" === t ? "offsetWidth" : "offsetHeight"] + parseFloat(i.getComputedStyle(e, null).getPropertyValue("width" === t ? "margin-right" : "margin-top")) + parseFloat(i.getComputedStyle(e, null).getPropertyValue("width" === t ? "margin-left" : "margin-bottom")) : e.offsetWidth
    }
    let b, y, S;

    function T() {
        return b || (b = function () {
            const e = r(),
                t = i();
            return {
                smoothScroll: t.documentElement && t.documentElement.style && "scrollBehavior" in t.documentElement.style,
                touch: !!("ontouchstart" in e || e.DocumentTouch && t instanceof e.DocumentTouch)
            }
        }()), b
    }

    function x(e = {}) {
        return y || (y = function ({
            userAgent: e
        } = {}) {
            const t = T(),
                s = r(),
                i = s.navigator.platform,
                a = e || s.navigator.userAgent,
                n = {
                    ios: !1,
                    android: !1
                },
                l = s.screen.width,
                o = s.screen.height,
                d = a.match(/(Android);?[\s\/]+([\d.]+)?/);
            let c = a.match(/(iPad).*OS\s([\d_]+)/);
            const p = a.match(/(iPod)(.*OS\s([\d_]+))?/),
                u = !c && a.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
                m = "Win32" === i;
            let f = "MacIntel" === i;
            return !c && f && t.touch && ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"].indexOf(`${l}x${o}`) >= 0 && (c = a.match(/(Version)\/([\d.]+)/), c || (c = [0, 1, "13_0_0"]), f = !1), d && !m && (n.os = "android", n.android = !0), (c || u || p) && (n.os = "ios", n.ios = !0), n
        }(e)), y
    }

    function E() {
        return S || (S = function () {
            const e = r();
            let t = !1;

            function s() {
                const t = e.navigator.userAgent.toLowerCase();
                return t.indexOf("safari") >= 0 && t.indexOf("chrome") < 0 && t.indexOf("android") < 0
            }
            if (s()) {
                const s = String(e.navigator.userAgent);
                if (s.includes("Version/")) {
                    const [e, i] = s.split("Version/")[1].split(" ")[0].split(".").map((e => Number(e)));
                    t = e < 16 || 16 === e && i < 2
                }
            }
            return {
                isSafari: t || s(),
                needPerspectiveFix: t,
                isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent)
            }
        }()), S
    }
    const C = {
        on(e, t, s) {
            const i = this;
            if (!i.eventsListeners || i.destroyed) return i;
            if ("function" != typeof t) return i;
            const a = s ? "unshift" : "push";
            return e.split(" ").forEach((e => {
                i.eventsListeners[e] || (i.eventsListeners[e] = []), i.eventsListeners[e][a](t)
            })), i
        },
        once(e, t, s) {
            const i = this;
            if (!i.eventsListeners || i.destroyed) return i;
            if ("function" != typeof t) return i;

            function a(...s) {
                i.off(e, a), a.__emitterProxy && delete a.__emitterProxy, t.apply(i, s)
            }
            return a.__emitterProxy = t, i.on(e, a, s)
        },
        onAny(e, t) {
            const s = this;
            if (!s.eventsListeners || s.destroyed) return s;
            if ("function" != typeof e) return s;
            const i = t ? "unshift" : "push";
            return s.eventsAnyListeners.indexOf(e) < 0 && s.eventsAnyListeners[i](e), s
        },
        offAny(e) {
            const t = this;
            if (!t.eventsListeners || t.destroyed) return t;
            if (!t.eventsAnyListeners) return t;
            const s = t.eventsAnyListeners.indexOf(e);
            return s >= 0 && t.eventsAnyListeners.splice(s, 1), t
        },
        off(e, t) {
            const s = this;
            return !s.eventsListeners || s.destroyed ? s : s.eventsListeners ? (e.split(" ").forEach((e => {
                void 0 === t ? s.eventsListeners[e] = [] : s.eventsListeners[e] && s.eventsListeners[e].forEach(((i, a) => {
                    (i === t || i.__emitterProxy && i.__emitterProxy === t) && s.eventsListeners[e].splice(a, 1)
                }))
            })), s) : s
        },
        emit(...e) {
            const t = this;
            if (!t.eventsListeners || t.destroyed) return t;
            if (!t.eventsListeners) return t;
            let s, i, a;
            "string" == typeof e[0] || Array.isArray(e[0]) ? (s = e[0], i = e.slice(1, e.length), a = t) : (s = e[0].events, i = e[0].data, a = e[0].context || t), i.unshift(a);
            return (Array.isArray(s) ? s : s.split(" ")).forEach((e => {
                t.eventsAnyListeners && t.eventsAnyListeners.length && t.eventsAnyListeners.forEach((t => {
                    t.apply(a, [e, ...i])
                })), t.eventsListeners && t.eventsListeners[e] && t.eventsListeners[e].forEach((e => {
                    e.apply(a, i)
                }))
            })), t
        }
    };
    const M = (e, t) => {
        if (!e || e.destroyed || !e.params) return;
        const s = t.closest(e.isElement ? "swiper-slide" : `.${e.params.slideClass}`);
        if (s) {
            const t = s.querySelector(`.${e.params.lazyPreloaderClass}`);
            t && t.remove()
        }
    },
        P = (e, t) => {
            if (!e.slides[t]) return;
            const s = e.slides[t].querySelector('[loading="lazy"]');
            s && s.removeAttribute("loading")
        },
        L = e => {
            if (!e || e.destroyed || !e.params) return;
            let t = e.params.lazyPreloadPrevNext;
            const s = e.slides.length;
            if (!s || !t || t < 0) return;
            t = Math.min(t, s);
            const i = "auto" === e.params.slidesPerView ? e.slidesPerViewDynamic() : Math.ceil(e.params.slidesPerView),
                a = e.activeIndex;
            if (e.params.grid && e.params.grid.rows > 1) {
                const s = a,
                    r = [s - t];
                return r.push(...Array.from({
                    length: t
                }).map(((e, t) => s + i + t))), void e.slides.forEach(((t, s) => {
                    r.includes(t.column) && P(e, s)
                }))
            }
            const r = a + i - 1;
            if (e.params.rewind || e.params.loop)
                for (let i = a - t; i <= r + t; i += 1) {
                    const t = (i % s + s) % s;
                    (t < a || t > r) && P(e, t)
                } else
                for (let i = Math.max(a - t, 0); i <= Math.min(r + t, s - 1); i += 1) i !== a && (i > r || i < a) && P(e, i)
        };
    const k = {
        updateSize: function () {
            const e = this;
            let t, s;
            const i = e.el;
            t = void 0 !== e.params.width && null !== e.params.width ? e.params.width : i.clientWidth, s = void 0 !== e.params.height && null !== e.params.height ? e.params.height : i.clientHeight, 0 === t && e.isHorizontal() || 0 === s && e.isVertical() || (t = t - parseInt(h(i, "padding-left") || 0, 10) - parseInt(h(i, "padding-right") || 0, 10), s = s - parseInt(h(i, "padding-top") || 0, 10) - parseInt(h(i, "padding-bottom") || 0, 10), Number.isNaN(t) && (t = 0), Number.isNaN(s) && (s = 0), Object.assign(e, {
                width: t,
                height: s,
                size: e.isHorizontal() ? t : s
            }))
        },
        updateSlides: function () {
            const e = this;

            function t(t) {
                return e.isHorizontal() ? t : {
                    width: "height",
                    "margin-top": "margin-left",
                    "margin-bottom ": "margin-right",
                    "margin-left": "margin-top",
                    "margin-right": "margin-bottom",
                    "padding-left": "padding-top",
                    "padding-right": "padding-bottom",
                    marginRight: "marginBottom"
                }[t]
            }

            function s(e, s) {
                return parseFloat(e.getPropertyValue(t(s)) || 0)
            }
            const i = e.params,
                {
                    wrapperEl: a,
                    slidesEl: r,
                    size: n,
                    rtlTranslate: l,
                    wrongRTL: o
                } = e,
                d = e.virtual && i.virtual.enabled,
                c = d ? e.virtual.slides.length : e.slides.length,
                u = m(r, `.${e.params.slideClass}, swiper-slide`),
                f = d ? e.virtual.slides.length : u.length;
            let g = [];
            const v = [],
                b = [];
            let y = i.slidesOffsetBefore;
            "function" == typeof y && (y = i.slidesOffsetBefore.call(e));
            let S = i.slidesOffsetAfter;
            "function" == typeof S && (S = i.slidesOffsetAfter.call(e));
            const T = e.snapGrid.length,
                x = e.slidesGrid.length;
            let E = i.spaceBetween,
                C = -y,
                M = 0,
                P = 0;
            if (void 0 === n) return;
            "string" == typeof E && E.indexOf("%") >= 0 ? E = parseFloat(E.replace("%", "")) / 100 * n : "string" == typeof E && (E = parseFloat(E)), e.virtualSize = -E, u.forEach((e => {
                l ? e.style.marginLeft = "" : e.style.marginRight = "", e.style.marginBottom = "", e.style.marginTop = ""
            })), i.centeredSlides && i.cssMode && (p(a, "--swiper-centered-offset-before", ""), p(a, "--swiper-centered-offset-after", ""));
            const L = i.grid && i.grid.rows > 1 && e.grid;
            let k;
            L && e.grid.initSlides(f);
            const O = "auto" === i.slidesPerView && i.breakpoints && Object.keys(i.breakpoints).filter((e => void 0 !== i.breakpoints[e].slidesPerView)).length > 0;
            for (let a = 0; a < f; a += 1) {
                let r;
                if (k = 0, u[a] && (r = u[a]), L && e.grid.updateSlide(a, r, f, t), !u[a] || "none" !== h(r, "display")) {
                    if ("auto" === i.slidesPerView) {
                        O && (u[a].style[t("width")] = "");
                        const n = getComputedStyle(r),
                            l = r.style.transform,
                            o = r.style.webkitTransform;
                        if (l && (r.style.transform = "none"), o && (r.style.webkitTransform = "none"), i.roundLengths) k = e.isHorizontal() ? w(r, "width", !0) : w(r, "height", !0);
                        else {
                            const e = s(n, "width"),
                                t = s(n, "padding-left"),
                                i = s(n, "padding-right"),
                                a = s(n, "margin-left"),
                                l = s(n, "margin-right"),
                                o = n.getPropertyValue("box-sizing");
                            if (o && "border-box" === o) k = e + a + l;
                            else {
                                const {
                                    clientWidth: s,
                                    offsetWidth: n
                                } = r;
                                k = e + t + i + a + l + (n - s)
                            }
                        }
                        l && (r.style.transform = l), o && (r.style.webkitTransform = o), i.roundLengths && (k = Math.floor(k))
                    } else k = (n - (i.slidesPerView - 1) * E) / i.slidesPerView, i.roundLengths && (k = Math.floor(k)), u[a] && (u[a].style[t("width")] = `${k}px`);
                    u[a] && (u[a].swiperSlideSize = k), b.push(k), i.centeredSlides ? (C = C + k / 2 + M / 2 + E, 0 === M && 0 !== a && (C = C - n / 2 - E), 0 === a && (C = C - n / 2 - E), Math.abs(C) < .001 && (C = 0), i.roundLengths && (C = Math.floor(C)), P % i.slidesPerGroup == 0 && g.push(C), v.push(C)) : (i.roundLengths && (C = Math.floor(C)), (P - Math.min(e.params.slidesPerGroupSkip, P)) % e.params.slidesPerGroup == 0 && g.push(C), v.push(C), C = C + k + E), e.virtualSize += k + E, M = k, P += 1
                }
            }
            if (e.virtualSize = Math.max(e.virtualSize, n) + S, l && o && ("slide" === i.effect || "coverflow" === i.effect) && (a.style.width = `${e.virtualSize + E}px`), i.setWrapperSize && (a.style[t("width")] = `${e.virtualSize + E}px`), L && e.grid.updateWrapperSize(k, g, t), !i.centeredSlides) {
                const t = [];
                for (let s = 0; s < g.length; s += 1) {
                    let a = g[s];
                    i.roundLengths && (a = Math.floor(a)), g[s] <= e.virtualSize - n && t.push(a)
                }
                g = t, Math.floor(e.virtualSize - n) - Math.floor(g[g.length - 1]) > 1 && g.push(e.virtualSize - n)
            }
            if (d && i.loop) {
                const t = b[0] + E;
                if (i.slidesPerGroup > 1) {
                    const s = Math.ceil((e.virtual.slidesBefore + e.virtual.slidesAfter) / i.slidesPerGroup),
                        a = t * i.slidesPerGroup;
                    for (let e = 0; e < s; e += 1) g.push(g[g.length - 1] + a)
                }
                for (let s = 0; s < e.virtual.slidesBefore + e.virtual.slidesAfter; s += 1) 1 === i.slidesPerGroup && g.push(g[g.length - 1] + t), v.push(v[v.length - 1] + t), e.virtualSize += t
            }
            if (0 === g.length && (g = [0]), 0 !== E) {
                const s = e.isHorizontal() && l ? "marginLeft" : t("marginRight");
                u.filter(((e, t) => !(i.cssMode && !i.loop) || t !== u.length - 1)).forEach((e => {
                    e.style[s] = `${E}px`
                }))
            }
            if (i.centeredSlides && i.centeredSlidesBounds) {
                let e = 0;
                b.forEach((t => {
                    e += t + (E || 0)
                })), e -= E;
                const t = e - n;
                g = g.map((e => e <= 0 ? -y : e > t ? t + S : e))
            }
            if (i.centerInsufficientSlides) {
                let e = 0;
                if (b.forEach((t => {
                    e += t + (E || 0)
                })), e -= E, e < n) {
                    const t = (n - e) / 2;
                    g.forEach(((e, s) => {
                        g[s] = e - t
                    })), v.forEach(((e, s) => {
                        v[s] = e + t
                    }))
                }
            }
            if (Object.assign(e, {
                slides: u,
                snapGrid: g,
                slidesGrid: v,
                slidesSizesGrid: b
            }), i.centeredSlides && i.cssMode && !i.centeredSlidesBounds) {
                p(a, "--swiper-centered-offset-before", -g[0] + "px"), p(a, "--swiper-centered-offset-after", e.size / 2 - b[b.length - 1] / 2 + "px");
                const t = -e.snapGrid[0],
                    s = -e.slidesGrid[0];
                e.snapGrid = e.snapGrid.map((e => e + t)), e.slidesGrid = e.slidesGrid.map((e => e + s))
            }
            if (f !== c && e.emit("slidesLengthChange"), g.length !== T && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), v.length !== x && e.emit("slidesGridLengthChange"), i.watchSlidesProgress && e.updateSlidesOffset(), !(d || i.cssMode || "slide" !== i.effect && "fade" !== i.effect)) {
                const t = `${i.containerModifierClass}backface-hidden`,
                    s = e.el.classList.contains(t);
                f <= i.maxBackfaceHiddenSlides ? s || e.el.classList.add(t) : s && e.el.classList.remove(t)
            }
        },
        updateAutoHeight: function (e) {
            const t = this,
                s = [],
                i = t.virtual && t.params.virtual.enabled;
            let a, r = 0;
            "number" == typeof e ? t.setTransition(e) : !0 === e && t.setTransition(t.params.speed);
            const n = e => i ? t.slides[t.getSlideIndexByData(e)] : t.slides[e];
            if ("auto" !== t.params.slidesPerView && t.params.slidesPerView > 1)
                if (t.params.centeredSlides) (t.visibleSlides || []).forEach((e => {
                    s.push(e)
                }));
                else
                    for (a = 0; a < Math.ceil(t.params.slidesPerView); a += 1) {
                        const e = t.activeIndex + a;
                        if (e > t.slides.length && !i) break;
                        s.push(n(e))
                    } else s.push(n(t.activeIndex));
            for (a = 0; a < s.length; a += 1)
                if (void 0 !== s[a]) {
                    const e = s[a].offsetHeight;
                    r = e > r ? e : r
                } (r || 0 === r) && (t.wrapperEl.style.height = `${r}px`)
        },
        updateSlidesOffset: function () {
            const e = this,
                t = e.slides,
                s = e.isElement ? e.isHorizontal() ? e.wrapperEl.offsetLeft : e.wrapperEl.offsetTop : 0;
            for (let i = 0; i < t.length; i += 1) t[i].swiperSlideOffset = (e.isHorizontal() ? t[i].offsetLeft : t[i].offsetTop) - s - e.cssOverflowAdjustment()
        },
        updateSlidesProgress: function (e = this && this.translate || 0) {
            const t = this,
                s = t.params,
                {
                    slides: i,
                    rtlTranslate: a,
                    snapGrid: r
                } = t;
            if (0 === i.length) return;
            void 0 === i[0].swiperSlideOffset && t.updateSlidesOffset();
            let n = -e;
            a && (n = e), i.forEach((e => {
                e.classList.remove(s.slideVisibleClass)
            })), t.visibleSlidesIndexes = [], t.visibleSlides = [];
            let l = s.spaceBetween;
            "string" == typeof l && l.indexOf("%") >= 0 ? l = parseFloat(l.replace("%", "")) / 100 * t.size : "string" == typeof l && (l = parseFloat(l));
            for (let e = 0; e < i.length; e += 1) {
                const o = i[e];
                let d = o.swiperSlideOffset;
                s.cssMode && s.centeredSlides && (d -= i[0].swiperSlideOffset);
                const c = (n + (s.centeredSlides ? t.minTranslate() : 0) - d) / (o.swiperSlideSize + l),
                    p = (n - r[0] + (s.centeredSlides ? t.minTranslate() : 0) - d) / (o.swiperSlideSize + l),
                    u = -(n - d),
                    m = u + t.slidesSizesGrid[e];
                (u >= 0 && u < t.size - 1 || m > 1 && m <= t.size || u <= 0 && m >= t.size) && (t.visibleSlides.push(o), t.visibleSlidesIndexes.push(e), i[e].classList.add(s.slideVisibleClass)), o.progress = a ? -c : c, o.originalProgress = a ? -p : p
            }
        },
        updateProgress: function (e) {
            const t = this;
            if (void 0 === e) {
                const s = t.rtlTranslate ? -1 : 1;
                e = t && t.translate && t.translate * s || 0
            }
            const s = t.params,
                i = t.maxTranslate() - t.minTranslate();
            let {
                progress: a,
                isBeginning: r,
                isEnd: n,
                progressLoop: l
            } = t;
            const o = r,
                d = n;
            if (0 === i) a = 0, r = !0, n = !0;
            else {
                a = (e - t.minTranslate()) / i;
                const s = Math.abs(e - t.minTranslate()) < 1,
                    l = Math.abs(e - t.maxTranslate()) < 1;
                r = s || a <= 0, n = l || a >= 1, s && (a = 0), l && (a = 1)
            }
            if (s.loop) {
                const s = t.getSlideIndexByData(0),
                    i = t.getSlideIndexByData(t.slides.length - 1),
                    a = t.slidesGrid[s],
                    r = t.slidesGrid[i],
                    n = t.slidesGrid[t.slidesGrid.length - 1],
                    o = Math.abs(e);
                l = o >= a ? (o - a) / n : (o + n - r) / n, l > 1 && (l -= 1)
            }
            Object.assign(t, {
                progress: a,
                progressLoop: l,
                isBeginning: r,
                isEnd: n
            }), (s.watchSlidesProgress || s.centeredSlides && s.autoHeight) && t.updateSlidesProgress(e), r && !o && t.emit("reachBeginning toEdge"), n && !d && t.emit("reachEnd toEdge"), (o && !r || d && !n) && t.emit("fromEdge"), t.emit("progress", a)
        },
        updateSlidesClasses: function () {
            const e = this,
                {
                    slides: t,
                    params: s,
                    slidesEl: i,
                    activeIndex: a
                } = e,
                r = e.virtual && s.virtual.enabled,
                n = e => m(i, `.${s.slideClass}${e}, swiper-slide${e}`)[0];
            let l;
            if (t.forEach((e => {
                e.classList.remove(s.slideActiveClass, s.slideNextClass, s.slidePrevClass)
            })), r)
                if (s.loop) {
                    let t = a - e.virtual.slidesBefore;
                    t < 0 && (t = e.virtual.slides.length + t), t >= e.virtual.slides.length && (t -= e.virtual.slides.length), l = n(`[data-swiper-slide-index="${t}"]`)
                } else l = n(`[data-swiper-slide-index="${a}"]`);
            else l = t[a];
            if (l) {
                l.classList.add(s.slideActiveClass);
                let e = function (e, t) {
                    const s = [];
                    for (; e.nextElementSibling;) {
                        const i = e.nextElementSibling;
                        t ? i.matches(t) && s.push(i) : s.push(i), e = i
                    }
                    return s
                }(l, `.${s.slideClass}, swiper-slide`)[0];
                s.loop && !e && (e = t[0]), e && e.classList.add(s.slideNextClass);
                let i = function (e, t) {
                    const s = [];
                    for (; e.previousElementSibling;) {
                        const i = e.previousElementSibling;
                        t ? i.matches(t) && s.push(i) : s.push(i), e = i
                    }
                    return s
                }(l, `.${s.slideClass}, swiper-slide`)[0];
                s.loop && 0 === !i && (i = t[t.length - 1]), i && i.classList.add(s.slidePrevClass)
            }
            e.emitSlidesClasses()
        },
        updateActiveIndex: function (e) {
            const t = this,
                s = t.rtlTranslate ? t.translate : -t.translate,
                {
                    snapGrid: i,
                    params: a,
                    activeIndex: r,
                    realIndex: n,
                    snapIndex: l
                } = t;
            let o, d = e;
            const c = e => {
                let s = e - t.virtual.slidesBefore;
                return s < 0 && (s = t.virtual.slides.length + s), s >= t.virtual.slides.length && (s -= t.virtual.slides.length), s
            };
            if (void 0 === d && (d = function (e) {
                const {
                    slidesGrid: t,
                    params: s
                } = e, i = e.rtlTranslate ? e.translate : -e.translate;
                let a;
                for (let e = 0; e < t.length; e += 1) void 0 !== t[e + 1] ? i >= t[e] && i < t[e + 1] - (t[e + 1] - t[e]) / 2 ? a = e : i >= t[e] && i < t[e + 1] && (a = e + 1) : i >= t[e] && (a = e);
                return s.normalizeSlideIndex && (a < 0 || void 0 === a) && (a = 0), a
            }(t)), i.indexOf(s) >= 0) o = i.indexOf(s);
            else {
                const e = Math.min(a.slidesPerGroupSkip, d);
                o = e + Math.floor((d - e) / a.slidesPerGroup)
            }
            if (o >= i.length && (o = i.length - 1), d === r) return o !== l && (t.snapIndex = o, t.emit("snapIndexChange")), void (t.params.loop && t.virtual && t.params.virtual.enabled && (t.realIndex = c(d)));
            let p;
            p = t.virtual && a.virtual.enabled && a.loop ? c(d) : t.slides[d] ? parseInt(t.slides[d].getAttribute("data-swiper-slide-index") || d, 10) : d, Object.assign(t, {
                previousSnapIndex: l,
                snapIndex: o,
                previousRealIndex: n,
                realIndex: p,
                previousIndex: r,
                activeIndex: d
            }), t.initialized && L(t), t.emit("activeIndexChange"), t.emit("snapIndexChange"), n !== p && t.emit("realIndexChange"), (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange")
        },
        updateClickedSlide: function (e) {
            const t = this,
                s = t.params,
                i = e.closest(`.${s.slideClass}, swiper-slide`);
            let a, r = !1;
            if (i)
                for (let e = 0; e < t.slides.length; e += 1)
                    if (t.slides[e] === i) {
                        r = !0, a = e;
                        break
                    } if (!i || !r) return t.clickedSlide = void 0, void (t.clickedIndex = void 0);
            t.clickedSlide = i, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(i.getAttribute("data-swiper-slide-index"), 10) : t.clickedIndex = a, s.slideToClickedSlide && void 0 !== t.clickedIndex && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
        }
    };
    const O = {
        getTranslate: function (e = (this.isHorizontal() ? "x" : "y")) {
            const {
                params: t,
                rtlTranslate: s,
                translate: i,
                wrapperEl: a
            } = this;
            if (t.virtualTranslate) return s ? -i : i;
            if (t.cssMode) return i;
            let r = o(a, e);
            return r += this.cssOverflowAdjustment(), s && (r = -r), r || 0
        },
        setTranslate: function (e, t) {
            const s = this,
                {
                    rtlTranslate: i,
                    params: a,
                    wrapperEl: r,
                    progress: n
                } = s;
            let l, o = 0,
                d = 0;
            s.isHorizontal() ? o = i ? -e : e : d = e, a.roundLengths && (o = Math.floor(o), d = Math.floor(d)), s.previousTranslate = s.translate, s.translate = s.isHorizontal() ? o : d, a.cssMode ? r[s.isHorizontal() ? "scrollLeft" : "scrollTop"] = s.isHorizontal() ? -o : -d : a.virtualTranslate || (s.isHorizontal() ? o -= s.cssOverflowAdjustment() : d -= s.cssOverflowAdjustment(), r.style.transform = `translate3d(${o}px, ${d}px, 0px)`);
            const c = s.maxTranslate() - s.minTranslate();
            l = 0 === c ? 0 : (e - s.minTranslate()) / c, l !== n && s.updateProgress(e), s.emit("setTranslate", s.translate, t)
        },
        minTranslate: function () {
            return -this.snapGrid[0]
        },
        maxTranslate: function () {
            return -this.snapGrid[this.snapGrid.length - 1]
        },
        translateTo: function (e = 0, t = this.params.speed, s = !0, i = !0, a) {
            const r = this,
                {
                    params: n,
                    wrapperEl: l
                } = r;
            if (r.animating && n.preventInteractionOnTransition) return !1;
            const o = r.minTranslate(),
                d = r.maxTranslate();
            let c;
            if (c = i && e > o ? o : i && e < d ? d : e, r.updateProgress(c), n.cssMode) {
                const e = r.isHorizontal();
                if (0 === t) l[e ? "scrollLeft" : "scrollTop"] = -c;
                else {
                    if (!r.support.smoothScroll) return u({
                        swiper: r,
                        targetPosition: -c,
                        side: e ? "left" : "top"
                    }), !0;
                    l.scrollTo({
                        [e ? "left" : "top"]: -c,
                        behavior: "smooth"
                    })
                }
                return !0
            }
            return 0 === t ? (r.setTransition(0), r.setTranslate(c), s && (r.emit("beforeTransitionStart", t, a), r.emit("transitionEnd"))) : (r.setTransition(t), r.setTranslate(c), s && (r.emit("beforeTransitionStart", t, a), r.emit("transitionStart")), r.animating || (r.animating = !0, r.onTranslateToWrapperTransitionEnd || (r.onTranslateToWrapperTransitionEnd = function (e) {
                r && !r.destroyed && e.target === this && (r.wrapperEl.removeEventListener("transitionend", r.onTranslateToWrapperTransitionEnd), r.onTranslateToWrapperTransitionEnd = null, delete r.onTranslateToWrapperTransitionEnd, s && r.emit("transitionEnd"))
            }), r.wrapperEl.addEventListener("transitionend", r.onTranslateToWrapperTransitionEnd))), !0
        }
    };

    function I({
        swiper: e,
        runCallbacks: t,
        direction: s,
        step: i
    }) {
        const {
            activeIndex: a,
            previousIndex: r
        } = e;
        let n = s;
        if (n || (n = a > r ? "next" : a < r ? "prev" : "reset"), e.emit(`transition${i}`), t && a !== r) {
            if ("reset" === n) return void e.emit(`slideResetTransition${i}`);
            e.emit(`slideChangeTransition${i}`), "next" === n ? e.emit(`slideNextTransition${i}`) : e.emit(`slidePrevTransition${i}`)
        }
    }
    const A = {
        slideTo: function (e = 0, t = this.params.speed, s = !0, i, a) {
            "string" == typeof e && (e = parseInt(e, 10));
            const r = this;
            let n = e;
            n < 0 && (n = 0);
            const {
                params: l,
                snapGrid: o,
                slidesGrid: d,
                previousIndex: c,
                activeIndex: p,
                rtlTranslate: m,
                wrapperEl: f,
                enabled: h
            } = r;
            if (r.animating && l.preventInteractionOnTransition || !h && !i && !a) return !1;
            const g = Math.min(r.params.slidesPerGroupSkip, n);
            let v = g + Math.floor((n - g) / r.params.slidesPerGroup);
            v >= o.length && (v = o.length - 1);
            const w = -o[v];
            if (l.normalizeSlideIndex)
                for (let e = 0; e < d.length; e += 1) {
                    const t = -Math.floor(100 * w),
                        s = Math.floor(100 * d[e]),
                        i = Math.floor(100 * d[e + 1]);
                    void 0 !== d[e + 1] ? t >= s && t < i - (i - s) / 2 ? n = e : t >= s && t < i && (n = e + 1) : t >= s && (n = e)
                }
            if (r.initialized && n !== p) {
                if (!r.allowSlideNext && (m ? w > r.translate && w > r.minTranslate() : w < r.translate && w < r.minTranslate())) return !1;
                if (!r.allowSlidePrev && w > r.translate && w > r.maxTranslate() && (p || 0) !== n) return !1
            }
            let b;
            if (n !== (c || 0) && s && r.emit("beforeSlideChangeStart"), r.updateProgress(w), b = n > p ? "next" : n < p ? "prev" : "reset", m && -w === r.translate || !m && w === r.translate) return r.updateActiveIndex(n), l.autoHeight && r.updateAutoHeight(), r.updateSlidesClasses(), "slide" !== l.effect && r.setTranslate(w), "reset" !== b && (r.transitionStart(s, b), r.transitionEnd(s, b)), !1;
            if (l.cssMode) {
                const e = r.isHorizontal(),
                    s = m ? w : -w;
                if (0 === t) {
                    const t = r.virtual && r.params.virtual.enabled;
                    t && (r.wrapperEl.style.scrollSnapType = "none", r._immediateVirtual = !0), t && !r._cssModeVirtualInitialSet && r.params.initialSlide > 0 ? (r._cssModeVirtualInitialSet = !0, requestAnimationFrame((() => {
                        f[e ? "scrollLeft" : "scrollTop"] = s
                    }))) : f[e ? "scrollLeft" : "scrollTop"] = s, t && requestAnimationFrame((() => {
                        r.wrapperEl.style.scrollSnapType = "", r._immediateVirtual = !1
                    }))
                } else {
                    if (!r.support.smoothScroll) return u({
                        swiper: r,
                        targetPosition: s,
                        side: e ? "left" : "top"
                    }), !0;
                    f.scrollTo({
                        [e ? "left" : "top"]: s,
                        behavior: "smooth"
                    })
                }
                return !0
            }
            return r.setTransition(t), r.setTranslate(w), r.updateActiveIndex(n), r.updateSlidesClasses(), r.emit("beforeTransitionStart", t, i), r.transitionStart(s, b), 0 === t ? r.transitionEnd(s, b) : r.animating || (r.animating = !0, r.onSlideToWrapperTransitionEnd || (r.onSlideToWrapperTransitionEnd = function (e) {
                r && !r.destroyed && e.target === this && (r.wrapperEl.removeEventListener("transitionend", r.onSlideToWrapperTransitionEnd), r.onSlideToWrapperTransitionEnd = null, delete r.onSlideToWrapperTransitionEnd, r.transitionEnd(s, b))
            }), r.wrapperEl.addEventListener("transitionend", r.onSlideToWrapperTransitionEnd)), !0
        },
        slideToLoop: function (e = 0, t = this.params.speed, s = !0, i) {
            if ("string" == typeof e) {
                e = parseInt(e, 10)
            }
            const a = this;
            let r = e;
            return a.params.loop && (a.virtual && a.params.virtual.enabled ? r += a.virtual.slidesBefore : r = a.getSlideIndexByData(r)), a.slideTo(r, t, s, i)
        },
        slideNext: function (e = this.params.speed, t = !0, s) {
            const i = this,
                {
                    enabled: a,
                    params: r,
                    animating: n
                } = i;
            if (!a) return i;
            let l = r.slidesPerGroup;
            "auto" === r.slidesPerView && 1 === r.slidesPerGroup && r.slidesPerGroupAuto && (l = Math.max(i.slidesPerViewDynamic("current", !0), 1));
            const o = i.activeIndex < r.slidesPerGroupSkip ? 1 : l,
                d = i.virtual && r.virtual.enabled;
            if (r.loop) {
                if (n && !d && r.loopPreventsSliding) return !1;
                i.loopFix({
                    direction: "next"
                }), i._clientLeft = i.wrapperEl.clientLeft
            }
            return r.rewind && i.isEnd ? i.slideTo(0, e, t, s) : i.slideTo(i.activeIndex + o, e, t, s)
        },
        slidePrev: function (e = this.params.speed, t = !0, s) {
            const i = this,
                {
                    params: a,
                    snapGrid: r,
                    slidesGrid: n,
                    rtlTranslate: l,
                    enabled: o,
                    animating: d
                } = i;
            if (!o) return i;
            const c = i.virtual && a.virtual.enabled;
            if (a.loop) {
                if (d && !c && a.loopPreventsSliding) return !1;
                i.loopFix({
                    direction: "prev"
                }), i._clientLeft = i.wrapperEl.clientLeft
            }

            function p(e) {
                return e < 0 ? -Math.floor(Math.abs(e)) : Math.floor(e)
            }
            const u = p(l ? i.translate : -i.translate),
                m = r.map((e => p(e)));
            let f = r[m.indexOf(u) - 1];
            if (void 0 === f && a.cssMode) {
                let e;
                r.forEach(((t, s) => {
                    u >= t && (e = s)
                })), void 0 !== e && (f = r[e > 0 ? e - 1 : e])
            }
            let h = 0;
            if (void 0 !== f && (h = n.indexOf(f), h < 0 && (h = i.activeIndex - 1), "auto" === a.slidesPerView && 1 === a.slidesPerGroup && a.slidesPerGroupAuto && (h = h - i.slidesPerViewDynamic("previous", !0) + 1, h = Math.max(h, 0))), a.rewind && i.isBeginning) {
                const a = i.params.virtual && i.params.virtual.enabled && i.virtual ? i.virtual.slides.length - 1 : i.slides.length - 1;
                return i.slideTo(a, e, t, s)
            }
            return i.slideTo(h, e, t, s)
        },
        slideReset: function (e = this.params.speed, t = !0, s) {
            return this.slideTo(this.activeIndex, e, t, s)
        },
        slideToClosest: function (e = this.params.speed, t = !0, s, i = .5) {
            const a = this;
            let r = a.activeIndex;
            const n = Math.min(a.params.slidesPerGroupSkip, r),
                l = n + Math.floor((r - n) / a.params.slidesPerGroup),
                o = a.rtlTranslate ? a.translate : -a.translate;
            if (o >= a.snapGrid[l]) {
                const e = a.snapGrid[l];
                o - e > (a.snapGrid[l + 1] - e) * i && (r += a.params.slidesPerGroup)
            } else {
                const e = a.snapGrid[l - 1];
                o - e <= (a.snapGrid[l] - e) * i && (r -= a.params.slidesPerGroup)
            }
            return r = Math.max(r, 0), r = Math.min(r, a.slidesGrid.length - 1), a.slideTo(r, e, t, s)
        },
        slideToClickedSlide: function () {
            const e = this,
                {
                    params: t,
                    slidesEl: s
                } = e,
                i = "auto" === t.slidesPerView ? e.slidesPerViewDynamic() : t.slidesPerView;
            let a, r = e.clickedIndex;
            const l = e.isElement ? "swiper-slide" : `.${t.slideClass}`;
            if (t.loop) {
                if (e.animating) return;
                a = parseInt(e.clickedSlide.getAttribute("data-swiper-slide-index"), 10), t.centeredSlides ? r < e.loopedSlides - i / 2 || r > e.slides.length - e.loopedSlides + i / 2 ? (e.loopFix(), r = e.getSlideIndex(m(s, `${l}[data-swiper-slide-index="${a}"]`)[0]), n((() => {
                    e.slideTo(r)
                }))) : e.slideTo(r) : r > e.slides.length - i ? (e.loopFix(), r = e.getSlideIndex(m(s, `${l}[data-swiper-slide-index="${a}"]`)[0]), n((() => {
                    e.slideTo(r)
                }))) : e.slideTo(r)
            } else e.slideTo(r)
        }
    };
    const z = {
        loopCreate: function (e) {
            const t = this,
                {
                    params: s,
                    slidesEl: i
                } = t;
            if (!s.loop || t.virtual && t.params.virtual.enabled) return;
            m(i, `.${s.slideClass}, swiper-slide`).forEach(((e, t) => {
                e.setAttribute("data-swiper-slide-index", t)
            })), t.loopFix({
                slideRealIndex: e,
                direction: s.centeredSlides ? void 0 : "next"
            })
        },
        loopFix: function ({
            slideRealIndex: e,
            slideTo: t = !0,
            direction: s,
            setTranslate: i,
            activeSlideIndex: a,
            byController: r,
            byMousewheel: n
        } = {}) {
            const l = this;
            if (!l.params.loop) return;
            l.emit("beforeLoopFix");
            const {
                slides: o,
                allowSlidePrev: d,
                allowSlideNext: c,
                slidesEl: p,
                params: u
            } = l;
            if (l.allowSlidePrev = !0, l.allowSlideNext = !0, l.virtual && u.virtual.enabled) return t && (u.centeredSlides || 0 !== l.snapIndex ? u.centeredSlides && l.snapIndex < u.slidesPerView ? l.slideTo(l.virtual.slides.length + l.snapIndex, 0, !1, !0) : l.snapIndex === l.snapGrid.length - 1 && l.slideTo(l.virtual.slidesBefore, 0, !1, !0) : l.slideTo(l.virtual.slides.length, 0, !1, !0)), l.allowSlidePrev = d, l.allowSlideNext = c, void l.emit("loopFix");
            const m = "auto" === u.slidesPerView ? l.slidesPerViewDynamic() : Math.ceil(parseFloat(u.slidesPerView, 10));
            let f = u.loopedSlides || m;
            f % u.slidesPerGroup != 0 && (f += u.slidesPerGroup - f % u.slidesPerGroup), l.loopedSlides = f;
            const h = [],
                g = [];
            let v = l.activeIndex;
            void 0 === a ? a = l.getSlideIndex(l.slides.filter((e => e.classList.contains(u.slideActiveClass)))[0]) : v = a;
            const w = "next" === s || !s,
                b = "prev" === s || !s;
            let y = 0,
                S = 0;
            if (a < f) {
                y = Math.max(f - a, u.slidesPerGroup);
                for (let e = 0; e < f - a; e += 1) {
                    const t = e - Math.floor(e / o.length) * o.length;
                    h.push(o.length - t - 1)
                }
            } else if (a > l.slides.length - 2 * f) {
                S = Math.max(a - (l.slides.length - 2 * f), u.slidesPerGroup);
                for (let e = 0; e < S; e += 1) {
                    const t = e - Math.floor(e / o.length) * o.length;
                    g.push(t)
                }
            }
            if (b && h.forEach((e => {
                l.slides[e].swiperLoopMoveDOM = !0, p.prepend(l.slides[e]), l.slides[e].swiperLoopMoveDOM = !1
            })), w && g.forEach((e => {
                l.slides[e].swiperLoopMoveDOM = !0, p.append(l.slides[e]), l.slides[e].swiperLoopMoveDOM = !1
            })), l.recalcSlides(), "auto" === u.slidesPerView && l.updateSlides(), u.watchSlidesProgress && l.updateSlidesOffset(), t)
                if (h.length > 0 && b)
                    if (void 0 === e) {
                        const e = l.slidesGrid[v],
                            t = l.slidesGrid[v + y] - e;
                        n ? l.setTranslate(l.translate - t) : (l.slideTo(v + y, 0, !1, !0), i && (l.touches[l.isHorizontal() ? "startX" : "startY"] += t))
                    } else i && l.slideToLoop(e, 0, !1, !0);
                else if (g.length > 0 && w)
                    if (void 0 === e) {
                        const e = l.slidesGrid[v],
                            t = l.slidesGrid[v - S] - e;
                        n ? l.setTranslate(l.translate - t) : (l.slideTo(v - S, 0, !1, !0), i && (l.touches[l.isHorizontal() ? "startX" : "startY"] += t))
                    } else l.slideToLoop(e, 0, !1, !0);
            if (l.allowSlidePrev = d, l.allowSlideNext = c, l.controller && l.controller.control && !r) {
                const t = {
                    slideRealIndex: e,
                    slideTo: !1,
                    direction: s,
                    setTranslate: i,
                    activeSlideIndex: a,
                    byController: !0
                };
                Array.isArray(l.controller.control) ? l.controller.control.forEach((e => {
                    !e.destroyed && e.params.loop && e.loopFix(t)
                })) : l.controller.control instanceof l.constructor && l.controller.control.params.loop && l.controller.control.loopFix(t)
            }
            l.emit("loopFix")
        },
        loopDestroy: function () {
            const e = this,
                {
                    params: t,
                    slidesEl: s
                } = e;
            if (!t.loop || e.virtual && e.params.virtual.enabled) return;
            e.recalcSlides();
            const i = [];
            e.slides.forEach((e => {
                const t = void 0 === e.swiperSlideIndex ? 1 * e.getAttribute("data-swiper-slide-index") : e.swiperSlideIndex;
                i[t] = e
            })), e.slides.forEach((e => {
                e.removeAttribute("data-swiper-slide-index")
            })), i.forEach((e => {
                s.append(e)
            })), e.recalcSlides(), e.slideTo(e.realIndex, 0)
        }
    };

    function G(e) {
        const t = this,
            s = i(),
            a = r(),
            n = t.touchEventsData;
        n.evCache.push(e);
        const {
            params: o,
            touches: d,
            enabled: c
        } = t;
        if (!c) return;
        if (!o.simulateTouch && "mouse" === e.pointerType) return;
        if (t.animating && o.preventInteractionOnTransition) return;
        !t.animating && o.cssMode && o.loop && t.loopFix();
        let p = e;
        p.originalEvent && (p = p.originalEvent);
        let u = p.target;
        if ("wrapper" === o.touchEventsTarget && !t.wrapperEl.contains(u)) return;
        if ("which" in p && 3 === p.which) return;
        if ("button" in p && p.button > 0) return;
        if (n.isTouched && n.isMoved) return;
        const m = !!o.noSwipingClass && "" !== o.noSwipingClass,
            f = e.composedPath ? e.composedPath() : e.path;
        m && p.target && p.target.shadowRoot && f && (u = f[0]);
        const h = o.noSwipingSelector ? o.noSwipingSelector : `.${o.noSwipingClass}`,
            g = !(!p.target || !p.target.shadowRoot);
        if (o.noSwiping && (g ? function (e, t = this) {
            return function t(s) {
                if (!s || s === i() || s === r()) return null;
                s.assignedSlot && (s = s.assignedSlot);
                const a = s.closest(e);
                return a || s.getRootNode ? a || t(s.getRootNode().host) : null
            }(t)
        }(h, u) : u.closest(h))) return void (t.allowClick = !0);
        if (o.swipeHandler && !u.closest(o.swipeHandler)) return;
        d.currentX = p.pageX, d.currentY = p.pageY;
        const v = d.currentX,
            w = d.currentY,
            b = o.edgeSwipeDetection || o.iOSEdgeSwipeDetection,
            y = o.edgeSwipeThreshold || o.iOSEdgeSwipeThreshold;
        if (b && (v <= y || v >= a.innerWidth - y)) {
            if ("prevent" !== b) return;
            e.preventDefault()
        }
        Object.assign(n, {
            isTouched: !0,
            isMoved: !1,
            allowTouchCallbacks: !0,
            isScrolling: void 0,
            startMoving: void 0
        }), d.startX = v, d.startY = w, n.touchStartTime = l(), t.allowClick = !0, t.updateSize(), t.swipeDirection = void 0, o.threshold > 0 && (n.allowThresholdMove = !1);
        let S = !0;
        u.matches(n.focusableElements) && (S = !1, "SELECT" === u.nodeName && (n.isTouched = !1)), s.activeElement && s.activeElement.matches(n.focusableElements) && s.activeElement !== u && s.activeElement.blur();
        const T = S && t.allowTouchMove && o.touchStartPreventDefault;
        !o.touchStartForcePreventDefault && !T || u.isContentEditable || p.preventDefault(), o.freeMode && o.freeMode.enabled && t.freeMode && t.animating && !o.cssMode && t.freeMode.onTouchStart(), t.emit("touchStart", p)
    }

    function D(e) {
        const t = i(),
            s = this,
            a = s.touchEventsData,
            {
                params: r,
                touches: n,
                rtlTranslate: o,
                enabled: d
            } = s;
        if (!d) return;
        if (!r.simulateTouch && "mouse" === e.pointerType) return;
        let c = e;
        if (c.originalEvent && (c = c.originalEvent), !a.isTouched) return void (a.startMoving && a.isScrolling && s.emit("touchMoveOpposite", c));
        const p = a.evCache.findIndex((e => e.pointerId === c.pointerId));
        p >= 0 && (a.evCache[p] = c);
        const u = a.evCache.length > 1 ? a.evCache[0] : c,
            m = u.pageX,
            f = u.pageY;
        if (c.preventedByNestedSwiper) return n.startX = m, void (n.startY = f);
        if (!s.allowTouchMove) return c.target.matches(a.focusableElements) || (s.allowClick = !1), void (a.isTouched && (Object.assign(n, {
            startX: m,
            startY: f,
            prevX: s.touches.currentX,
            prevY: s.touches.currentY,
            currentX: m,
            currentY: f
        }), a.touchStartTime = l()));
        if (r.touchReleaseOnEdges && !r.loop)
            if (s.isVertical()) {
                if (f < n.startY && s.translate <= s.maxTranslate() || f > n.startY && s.translate >= s.minTranslate()) return a.isTouched = !1, void (a.isMoved = !1)
            } else if (m < n.startX && s.translate <= s.maxTranslate() || m > n.startX && s.translate >= s.minTranslate()) return;
        if (t.activeElement && c.target === t.activeElement && c.target.matches(a.focusableElements)) return a.isMoved = !0, void (s.allowClick = !1);
        if (a.allowTouchCallbacks && s.emit("touchMove", c), c.targetTouches && c.targetTouches.length > 1) return;
        n.currentX = m, n.currentY = f;
        const h = n.currentX - n.startX,
            g = n.currentY - n.startY;
        if (s.params.threshold && Math.sqrt(h ** 2 + g ** 2) < s.params.threshold) return;
        if (void 0 === a.isScrolling) {
            let e;
            s.isHorizontal() && n.currentY === n.startY || s.isVertical() && n.currentX === n.startX ? a.isScrolling = !1 : h * h + g * g >= 25 && (e = 180 * Math.atan2(Math.abs(g), Math.abs(h)) / Math.PI, a.isScrolling = s.isHorizontal() ? e > r.touchAngle : 90 - e > r.touchAngle)
        }
        if (a.isScrolling && s.emit("touchMoveOpposite", c), void 0 === a.startMoving && (n.currentX === n.startX && n.currentY === n.startY || (a.startMoving = !0)), a.isScrolling || s.zoom && s.params.zoom && s.params.zoom.enabled && a.evCache.length > 1) return void (a.isTouched = !1);
        if (!a.startMoving) return;
        s.allowClick = !1, !r.cssMode && c.cancelable && c.preventDefault(), r.touchMoveStopPropagation && !r.nested && c.stopPropagation();
        let v = s.isHorizontal() ? h : g,
            w = s.isHorizontal() ? n.currentX - n.previousX : n.currentY - n.previousY;
        r.oneWayMovement && (v = Math.abs(v) * (o ? 1 : -1), w = Math.abs(w) * (o ? 1 : -1)), n.diff = v, v *= r.touchRatio, o && (v = -v, w = -w);
        const b = s.touchesDirection;
        s.swipeDirection = v > 0 ? "prev" : "next", s.touchesDirection = w > 0 ? "prev" : "next";
        const y = s.params.loop && !r.cssMode;
        if (!a.isMoved) {
            if (y && s.loopFix({
                direction: s.swipeDirection
            }), a.startTranslate = s.getTranslate(), s.setTransition(0), s.animating) {
                const e = new window.CustomEvent("transitionend", {
                    bubbles: !0,
                    cancelable: !0
                });
                s.wrapperEl.dispatchEvent(e)
            }
            a.allowMomentumBounce = !1, !r.grabCursor || !0 !== s.allowSlideNext && !0 !== s.allowSlidePrev || s.setGrabCursor(!0), s.emit("sliderFirstMove", c)
        }
        let S;
        a.isMoved && b !== s.touchesDirection && y && Math.abs(v) >= 1 && (s.loopFix({
            direction: s.swipeDirection,
            setTranslate: !0
        }), S = !0), s.emit("sliderMove", c), a.isMoved = !0, a.currentTranslate = v + a.startTranslate;
        let T = !0,
            x = r.resistanceRatio;
        if (r.touchReleaseOnEdges && (x = 0), v > 0 ? (y && !S && a.currentTranslate > (r.centeredSlides ? s.minTranslate() - s.size / 2 : s.minTranslate()) && s.loopFix({
            direction: "prev",
            setTranslate: !0,
            activeSlideIndex: 0
        }), a.currentTranslate > s.minTranslate() && (T = !1, r.resistance && (a.currentTranslate = s.minTranslate() - 1 + (-s.minTranslate() + a.startTranslate + v) ** x))) : v < 0 && (y && !S && a.currentTranslate < (r.centeredSlides ? s.maxTranslate() + s.size / 2 : s.maxTranslate()) && s.loopFix({
            direction: "next",
            setTranslate: !0,
            activeSlideIndex: s.slides.length - ("auto" === r.slidesPerView ? s.slidesPerViewDynamic() : Math.ceil(parseFloat(r.slidesPerView, 10)))
        }), a.currentTranslate < s.maxTranslate() && (T = !1, r.resistance && (a.currentTranslate = s.maxTranslate() + 1 - (s.maxTranslate() - a.startTranslate - v) ** x))), T && (c.preventedByNestedSwiper = !0), !s.allowSlideNext && "next" === s.swipeDirection && a.currentTranslate < a.startTranslate && (a.currentTranslate = a.startTranslate), !s.allowSlidePrev && "prev" === s.swipeDirection && a.currentTranslate > a.startTranslate && (a.currentTranslate = a.startTranslate), s.allowSlidePrev || s.allowSlideNext || (a.currentTranslate = a.startTranslate), r.threshold > 0) {
            if (!(Math.abs(v) > r.threshold || a.allowThresholdMove)) return void (a.currentTranslate = a.startTranslate);
            if (!a.allowThresholdMove) return a.allowThresholdMove = !0, n.startX = n.currentX, n.startY = n.currentY, a.currentTranslate = a.startTranslate, void (n.diff = s.isHorizontal() ? n.currentX - n.startX : n.currentY - n.startY)
        }
        r.followFinger && !r.cssMode && ((r.freeMode && r.freeMode.enabled && s.freeMode || r.watchSlidesProgress) && (s.updateActiveIndex(), s.updateSlidesClasses()), r.freeMode && r.freeMode.enabled && s.freeMode && s.freeMode.onTouchMove(), s.updateProgress(a.currentTranslate), s.setTranslate(a.currentTranslate))
    }

    function $(e) {
        const t = this,
            s = t.touchEventsData,
            i = s.evCache.findIndex((t => t.pointerId === e.pointerId));
        if (i >= 0 && s.evCache.splice(i, 1), ["pointercancel", "pointerout", "pointerleave"].includes(e.type)) {
            if (!("pointercancel" === e.type && (t.browser.isSafari || t.browser.isWebView))) return
        }
        const {
            params: a,
            touches: r,
            rtlTranslate: o,
            slidesGrid: d,
            enabled: c
        } = t;
        if (!c) return;
        if (!a.simulateTouch && "mouse" === e.pointerType) return;
        let p = e;
        if (p.originalEvent && (p = p.originalEvent), s.allowTouchCallbacks && t.emit("touchEnd", p), s.allowTouchCallbacks = !1, !s.isTouched) return s.isMoved && a.grabCursor && t.setGrabCursor(!1), s.isMoved = !1, void (s.startMoving = !1);
        a.grabCursor && s.isMoved && s.isTouched && (!0 === t.allowSlideNext || !0 === t.allowSlidePrev) && t.setGrabCursor(!1);
        const u = l(),
            m = u - s.touchStartTime;
        if (t.allowClick) {
            const e = p.path || p.composedPath && p.composedPath();
            t.updateClickedSlide(e && e[0] || p.target), t.emit("tap click", p), m < 300 && u - s.lastClickTime < 300 && t.emit("doubleTap doubleClick", p)
        }
        if (s.lastClickTime = l(), n((() => {
            t.destroyed || (t.allowClick = !0)
        })), !s.isTouched || !s.isMoved || !t.swipeDirection || 0 === r.diff || s.currentTranslate === s.startTranslate) return s.isTouched = !1, s.isMoved = !1, void (s.startMoving = !1);
        let f;
        if (s.isTouched = !1, s.isMoved = !1, s.startMoving = !1, f = a.followFinger ? o ? t.translate : -t.translate : -s.currentTranslate, a.cssMode) return;
        if (a.freeMode && a.freeMode.enabled) return void t.freeMode.onTouchEnd({
            currentPos: f
        });
        let h = 0,
            g = t.slidesSizesGrid[0];
        for (let e = 0; e < d.length; e += e < a.slidesPerGroupSkip ? 1 : a.slidesPerGroup) {
            const t = e < a.slidesPerGroupSkip - 1 ? 1 : a.slidesPerGroup;
            void 0 !== d[e + t] ? f >= d[e] && f < d[e + t] && (h = e, g = d[e + t] - d[e]) : f >= d[e] && (h = e, g = d[d.length - 1] - d[d.length - 2])
        }
        let v = null,
            w = null;
        a.rewind && (t.isBeginning ? w = a.virtual && a.virtual.enabled && t.virtual ? t.virtual.slides.length - 1 : t.slides.length - 1 : t.isEnd && (v = 0));
        const b = (f - d[h]) / g,
            y = h < a.slidesPerGroupSkip - 1 ? 1 : a.slidesPerGroup;
        if (m > a.longSwipesMs) {
            if (!a.longSwipes) return void t.slideTo(t.activeIndex);
            "next" === t.swipeDirection && (b >= a.longSwipesRatio ? t.slideTo(a.rewind && t.isEnd ? v : h + y) : t.slideTo(h)), "prev" === t.swipeDirection && (b > 1 - a.longSwipesRatio ? t.slideTo(h + y) : null !== w && b < 0 && Math.abs(b) > a.longSwipesRatio ? t.slideTo(w) : t.slideTo(h))
        } else {
            if (!a.shortSwipes) return void t.slideTo(t.activeIndex);
            t.navigation && (p.target === t.navigation.nextEl || p.target === t.navigation.prevEl) ? p.target === t.navigation.nextEl ? t.slideTo(h + y) : t.slideTo(h) : ("next" === t.swipeDirection && t.slideTo(null !== v ? v : h + y), "prev" === t.swipeDirection && t.slideTo(null !== w ? w : h))
        }
    }

    function B() {
        const e = this,
            {
                params: t,
                el: s
            } = e;
        if (s && 0 === s.offsetWidth) return;
        t.breakpoints && e.setBreakpoint();
        const {
            allowSlideNext: i,
            allowSlidePrev: a,
            snapGrid: r
        } = e, n = e.virtual && e.params.virtual.enabled;
        e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), e.updateSlidesClasses();
        const l = n && t.loop;
        !("auto" === t.slidesPerView || t.slidesPerView > 1) || !e.isEnd || e.isBeginning || e.params.centeredSlides || l ? e.params.loop && !n ? e.slideToLoop(e.realIndex, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0) : e.slideTo(e.slides.length - 1, 0, !1, !0), e.autoplay && e.autoplay.running && e.autoplay.paused && (clearTimeout(e.autoplay.resizeTimeout), e.autoplay.resizeTimeout = setTimeout((() => {
            e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.resume()
        }), 500)), e.allowSlidePrev = a, e.allowSlideNext = i, e.params.watchOverflow && r !== e.snapGrid && e.checkOverflow()
    }

    function _(e) {
        const t = this;
        t.enabled && (t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation())))
    }

    function F() {
        const e = this,
            {
                wrapperEl: t,
                rtlTranslate: s,
                enabled: i
            } = e;
        if (!i) return;
        let a;
        e.previousTranslate = e.translate, e.isHorizontal() ? e.translate = -t.scrollLeft : e.translate = -t.scrollTop, 0 === e.translate && (e.translate = 0), e.updateActiveIndex(), e.updateSlidesClasses();
        const r = e.maxTranslate() - e.minTranslate();
        a = 0 === r ? 0 : (e.translate - e.minTranslate()) / r, a !== e.progress && e.updateProgress(s ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1)
    }

    function V(e) {
        const t = this;
        M(t, e.target), t.params.cssMode || "auto" !== t.params.slidesPerView && !t.params.autoHeight || t.update()
    }
    let N = !1;

    function H() { }
    const j = (e, t) => {
        const s = i(),
            {
                params: a,
                el: r,
                wrapperEl: n,
                device: l
            } = e,
            o = !!a.nested,
            d = "on" === t ? "addEventListener" : "removeEventListener",
            c = t;
        r[d]("pointerdown", e.onTouchStart, {
            passive: !1
        }), s[d]("pointermove", e.onTouchMove, {
            passive: !1,
            capture: o
        }), s[d]("pointerup", e.onTouchEnd, {
            passive: !0
        }), s[d]("pointercancel", e.onTouchEnd, {
            passive: !0
        }), s[d]("pointerout", e.onTouchEnd, {
            passive: !0
        }), s[d]("pointerleave", e.onTouchEnd, {
            passive: !0
        }), (a.preventClicks || a.preventClicksPropagation) && r[d]("click", e.onClick, !0), a.cssMode && n[d]("scroll", e.onScroll), a.updateOnWindowResize ? e[c](l.ios || l.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", B, !0) : e[c]("observerUpdate", B, !0), r[d]("load", e.onLoad, {
            capture: !0
        })
    };
    const R = (e, t) => e.grid && t.grid && t.grid.rows > 1;
    const q = {
        init: !0,
        direction: "horizontal",
        oneWayMovement: !1,
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 5,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        loop: !1,
        loopedSlides: null,
        loopPreventsSliding: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideActiveClass: "swiper-slide-active",
        slideVisibleClass: "swiper-slide-visible",
        slideNextClass: "swiper-slide-next",
        slidePrevClass: "swiper-slide-prev",
        wrapperClass: "swiper-wrapper",
        lazyPreloaderClass: "swiper-lazy-preloader",
        lazyPreloadPrevNext: 0,
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

    function W(e, t) {
        return function (s = {}) {
            const i = Object.keys(s)[0],
                a = s[i];
            "object" == typeof a && null !== a ? (["navigation", "pagination", "scrollbar"].indexOf(i) >= 0 && !0 === e[i] && (e[i] = {
                auto: !0
            }), i in e && "enabled" in a ? (!0 === e[i] && (e[i] = {
                enabled: !0
            }), "object" != typeof e[i] || "enabled" in e[i] || (e[i].enabled = !0), e[i] || (e[i] = {
                enabled: !1
            }), c(t, s)) : c(t, s)) : c(t, s)
        }
    }
    const X = {
        eventsEmitter: C,
        update: k,
        translate: O,
        transition: {
            setTransition: function (e, t) {
                const s = this;
                s.params.cssMode || (s.wrapperEl.style.transitionDuration = `${e}ms`), s.emit("setTransition", e, t)
            },
            transitionStart: function (e = !0, t) {
                const s = this,
                    {
                        params: i
                    } = s;
                i.cssMode || (i.autoHeight && s.updateAutoHeight(), I({
                    swiper: s,
                    runCallbacks: e,
                    direction: t,
                    step: "Start"
                }))
            },
            transitionEnd: function (e = !0, t) {
                const s = this,
                    {
                        params: i
                    } = s;
                s.animating = !1, i.cssMode || (s.setTransition(0), I({
                    swiper: s,
                    runCallbacks: e,
                    direction: t,
                    step: "End"
                }))
            }
        },
        slide: A,
        loop: z,
        grabCursor: {
            setGrabCursor: function (e) {
                const t = this;
                if (!t.params.simulateTouch || t.params.watchOverflow && t.isLocked || t.params.cssMode) return;
                const s = "container" === t.params.touchEventsTarget ? t.el : t.wrapperEl;
                t.isElement && (t.__preventObserver__ = !0), s.style.cursor = "move", s.style.cursor = e ? "grabbing" : "grab", t.isElement && requestAnimationFrame((() => {
                    t.__preventObserver__ = !1
                }))
            },
            unsetGrabCursor: function () {
                const e = this;
                e.params.watchOverflow && e.isLocked || e.params.cssMode || (e.isElement && (e.__preventObserver__ = !0), e["container" === e.params.touchEventsTarget ? "el" : "wrapperEl"].style.cursor = "", e.isElement && requestAnimationFrame((() => {
                    e.__preventObserver__ = !1
                })))
            }
        },
        events: {
            attachEvents: function () {
                const e = this,
                    t = i(),
                    {
                        params: s
                    } = e;
                e.onTouchStart = G.bind(e), e.onTouchMove = D.bind(e), e.onTouchEnd = $.bind(e), s.cssMode && (e.onScroll = F.bind(e)), e.onClick = _.bind(e), e.onLoad = V.bind(e), N || (t.addEventListener("touchstart", H), N = !0), j(e, "on")
            },
            detachEvents: function () {
                j(this, "off")
            }
        },
        breakpoints: {
            setBreakpoint: function () {
                const e = this,
                    {
                        realIndex: t,
                        initialized: s,
                        params: i,
                        el: a
                    } = e,
                    r = i.breakpoints;
                if (!r || r && 0 === Object.keys(r).length) return;
                const n = e.getBreakpoint(r, e.params.breakpointsBase, e.el);
                if (!n || e.currentBreakpoint === n) return;
                const l = (n in r ? r[n] : void 0) || e.originalParams,
                    o = R(e, i),
                    d = R(e, l),
                    p = i.enabled;
                o && !d ? (a.classList.remove(`${i.containerModifierClass}grid`, `${i.containerModifierClass}grid-column`), e.emitContainerClasses()) : !o && d && (a.classList.add(`${i.containerModifierClass}grid`), (l.grid.fill && "column" === l.grid.fill || !l.grid.fill && "column" === i.grid.fill) && a.classList.add(`${i.containerModifierClass}grid-column`), e.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach((t => {
                    if (void 0 === l[t]) return;
                    const s = i[t] && i[t].enabled,
                        a = l[t] && l[t].enabled;
                    s && !a && e[t].disable(), !s && a && e[t].enable()
                }));
                const u = l.direction && l.direction !== i.direction,
                    m = i.loop && (l.slidesPerView !== i.slidesPerView || u);
                u && s && e.changeDirection(), c(e.params, l);
                const f = e.params.enabled;
                Object.assign(e, {
                    allowTouchMove: e.params.allowTouchMove,
                    allowSlideNext: e.params.allowSlideNext,
                    allowSlidePrev: e.params.allowSlidePrev
                }), p && !f ? e.disable() : !p && f && e.enable(), e.currentBreakpoint = n, e.emit("_beforeBreakpoint", l), m && s && (e.loopDestroy(), e.loopCreate(t), e.updateSlides()), e.emit("breakpoint", l)
            },
            getBreakpoint: function (e, t = "window", s) {
                if (!e || "container" === t && !s) return;
                let i = !1;
                const a = r(),
                    n = "window" === t ? a.innerHeight : s.clientHeight,
                    l = Object.keys(e).map((e => {
                        if ("string" == typeof e && 0 === e.indexOf("@")) {
                            const t = parseFloat(e.substr(1));
                            return {
                                value: n * t,
                                point: e
                            }
                        }
                        return {
                            value: e,
                            point: e
                        }
                    }));
                l.sort(((e, t) => parseInt(e.value, 10) - parseInt(t.value, 10)));
                for (let e = 0; e < l.length; e += 1) {
                    const {
                        point: r,
                        value: n
                    } = l[e];
                    "window" === t ? a.matchMedia(`(min-width: ${n}px)`).matches && (i = r) : n <= s.clientWidth && (i = r)
                }
                return i || "max"
            }
        },
        checkOverflow: {
            checkOverflow: function () {
                const e = this,
                    {
                        isLocked: t,
                        params: s
                    } = e,
                    {
                        slidesOffsetBefore: i
                    } = s;
                if (i) {
                    const t = e.slides.length - 1,
                        s = e.slidesGrid[t] + e.slidesSizesGrid[t] + 2 * i;
                    e.isLocked = e.size > s
                } else e.isLocked = 1 === e.snapGrid.length;
                !0 === s.allowSlideNext && (e.allowSlideNext = !e.isLocked), !0 === s.allowSlidePrev && (e.allowSlidePrev = !e.isLocked), t && t !== e.isLocked && (e.isEnd = !1), t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock")
            }
        },
        classes: {
            addClasses: function () {
                const e = this,
                    {
                        classNames: t,
                        params: s,
                        rtl: i,
                        el: a,
                        device: r
                    } = e,
                    n = function (e, t) {
                        const s = [];
                        return e.forEach((e => {
                            "object" == typeof e ? Object.keys(e).forEach((i => {
                                e[i] && s.push(t + i)
                            })) : "string" == typeof e && s.push(t + e)
                        })), s
                    }(["initialized", s.direction, {
                        "free-mode": e.params.freeMode && s.freeMode.enabled
                    }, {
                            autoheight: s.autoHeight
                        }, {
                            rtl: i
                        }, {
                            grid: s.grid && s.grid.rows > 1
                        }, {
                            "grid-column": s.grid && s.grid.rows > 1 && "column" === s.grid.fill
                        }, {
                            android: r.android
                        }, {
                            ios: r.ios
                        }, {
                            "css-mode": s.cssMode
                        }, {
                            centered: s.cssMode && s.centeredSlides
                        }, {
                            "watch-progress": s.watchSlidesProgress
                        }], s.containerModifierClass);
                t.push(...n), a.classList.add(...t), e.emitContainerClasses()
            },
            removeClasses: function () {
                const {
                    el: e,
                    classNames: t
                } = this;
                e.classList.remove(...t), this.emitContainerClasses()
            }
        }
    },
        Y = {};
    class U {
        constructor(...e) {
            let t, s;
            1 === e.length && e[0].constructor && "Object" === Object.prototype.toString.call(e[0]).slice(8, -1) ? s = e[0] : [t, s] = e, s || (s = {}), s = c({}, s), t && !s.el && (s.el = t);
            const a = i();
            if (s.el && "string" == typeof s.el && a.querySelectorAll(s.el).length > 1) {
                const e = [];
                return a.querySelectorAll(s.el).forEach((t => {
                    const i = c({}, s, {
                        el: t
                    });
                    e.push(new U(i))
                })), e
            }
            const r = this;
            r.__swiper__ = !0, r.support = T(), r.device = x({
                userAgent: s.userAgent
            }), r.browser = E(), r.eventsListeners = {}, r.eventsAnyListeners = [], r.modules = [...r.__modules__], s.modules && Array.isArray(s.modules) && r.modules.push(...s.modules);
            const n = {};
            r.modules.forEach((e => {
                e({
                    params: s,
                    swiper: r,
                    extendParams: W(s, n),
                    on: r.on.bind(r),
                    once: r.once.bind(r),
                    off: r.off.bind(r),
                    emit: r.emit.bind(r)
                })
            }));
            const l = c({}, q, n);
            return r.params = c({}, l, Y, s), r.originalParams = c({}, r.params), r.passedParams = c({}, s), r.params && r.params.on && Object.keys(r.params.on).forEach((e => {
                r.on(e, r.params.on[e])
            })), r.params && r.params.onAny && r.onAny(r.params.onAny), Object.assign(r, {
                enabled: r.params.enabled,
                el: t,
                classNames: [],
                slides: [],
                slidesGrid: [],
                snapGrid: [],
                slidesSizesGrid: [],
                isHorizontal: () => "horizontal" === r.params.direction,
                isVertical: () => "vertical" === r.params.direction,
                activeIndex: 0,
                realIndex: 0,
                isBeginning: !0,
                isEnd: !1,
                translate: 0,
                previousTranslate: 0,
                progress: 0,
                velocity: 0,
                animating: !1,
                cssOverflowAdjustment() {
                    return Math.trunc(this.translate / 2 ** 23) * 2 ** 23
                },
                allowSlideNext: r.params.allowSlideNext,
                allowSlidePrev: r.params.allowSlidePrev,
                touchEventsData: {
                    isTouched: void 0,
                    isMoved: void 0,
                    allowTouchCallbacks: void 0,
                    touchStartTime: void 0,
                    isScrolling: void 0,
                    currentTranslate: void 0,
                    startTranslate: void 0,
                    allowThresholdMove: void 0,
                    focusableElements: r.params.focusableElements,
                    lastClickTime: 0,
                    clickTimeout: void 0,
                    velocities: [],
                    allowMomentumBounce: void 0,
                    startMoving: void 0,
                    evCache: []
                },
                allowClick: !0,
                allowTouchMove: r.params.allowTouchMove,
                touches: {
                    startX: 0,
                    startY: 0,
                    currentX: 0,
                    currentY: 0,
                    diff: 0
                },
                imagesToLoad: [],
                imagesLoaded: 0
            }), r.emit("_swiper"), r.params.init && r.init(), r
        }
        getSlideIndex(e) {
            const {
                slidesEl: t,
                params: s
            } = this, i = g(m(t, `.${s.slideClass}, swiper-slide`)[0]);
            return g(e) - i
        }
        getSlideIndexByData(e) {
            return this.getSlideIndex(this.slides.filter((t => 1 * t.getAttribute("data-swiper-slide-index") === e))[0])
        }
        recalcSlides() {
            const {
                slidesEl: e,
                params: t
            } = this;
            this.slides = m(e, `.${t.slideClass}, swiper-slide`)
        }
        enable() {
            const e = this;
            e.enabled || (e.enabled = !0, e.params.grabCursor && e.setGrabCursor(), e.emit("enable"))
        }
        disable() {
            const e = this;
            e.enabled && (e.enabled = !1, e.params.grabCursor && e.unsetGrabCursor(), e.emit("disable"))
        }
        setProgress(e, t) {
            const s = this;
            e = Math.min(Math.max(e, 0), 1);
            const i = s.minTranslate(),
                a = (s.maxTranslate() - i) * e + i;
            s.translateTo(a, void 0 === t ? 0 : t), s.updateActiveIndex(), s.updateSlidesClasses()
        }
        emitContainerClasses() {
            const e = this;
            if (!e.params._emitClasses || !e.el) return;
            const t = e.el.className.split(" ").filter((t => 0 === t.indexOf("swiper") || 0 === t.indexOf(e.params.containerModifierClass)));
            e.emit("_containerClasses", t.join(" "))
        }
        getSlideClasses(e) {
            const t = this;
            return t.destroyed ? "" : e.className.split(" ").filter((e => 0 === e.indexOf("swiper-slide") || 0 === e.indexOf(t.params.slideClass))).join(" ")
        }
        emitSlidesClasses() {
            const e = this;
            if (!e.params._emitClasses || !e.el) return;
            const t = [];
            e.slides.forEach((s => {
                const i = e.getSlideClasses(s);
                t.push({
                    slideEl: s,
                    classNames: i
                }), e.emit("_slideClass", s, i)
            })), e.emit("_slideClasses", t)
        }
        slidesPerViewDynamic(e = "current", t = !1) {
            const {
                params: s,
                slides: i,
                slidesGrid: a,
                slidesSizesGrid: r,
                size: n,
                activeIndex: l
            } = this;
            let o = 1;
            if (s.centeredSlides) {
                let e, t = i[l] ? i[l].swiperSlideSize : 0;
                for (let s = l + 1; s < i.length; s += 1) i[s] && !e && (t += i[s].swiperSlideSize, o += 1, t > n && (e = !0));
                for (let s = l - 1; s >= 0; s -= 1) i[s] && !e && (t += i[s].swiperSlideSize, o += 1, t > n && (e = !0))
            } else if ("current" === e)
                for (let e = l + 1; e < i.length; e += 1) {
                    (t ? a[e] + r[e] - a[l] < n : a[e] - a[l] < n) && (o += 1)
                } else
                for (let e = l - 1; e >= 0; e -= 1) {
                    a[l] - a[e] < n && (o += 1)
                }
            return o
        }
        update() {
            const e = this;
            if (!e || e.destroyed) return;
            const {
                snapGrid: t,
                params: s
            } = e;

            function i() {
                const t = e.rtlTranslate ? -1 * e.translate : e.translate,
                    s = Math.min(Math.max(t, e.maxTranslate()), e.minTranslate());
                e.setTranslate(s), e.updateActiveIndex(), e.updateSlidesClasses()
            }
            let a;
            if (s.breakpoints && e.setBreakpoint(), [...e.el.querySelectorAll('[loading="lazy"]')].forEach((t => {
                t.complete && M(e, t)
            })), e.updateSize(), e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), s.freeMode && s.freeMode.enabled && !s.cssMode) i(), s.autoHeight && e.updateAutoHeight();
            else {
                if (("auto" === s.slidesPerView || s.slidesPerView > 1) && e.isEnd && !s.centeredSlides) {
                    const t = e.virtual && s.virtual.enabled ? e.virtual.slides : e.slides;
                    a = e.slideTo(t.length - 1, 0, !1, !0)
                } else a = e.slideTo(e.activeIndex, 0, !1, !0);
                a || i()
            }
            s.watchOverflow && t !== e.snapGrid && e.checkOverflow(), e.emit("update")
        }
        changeDirection(e, t = !0) {
            const s = this,
                i = s.params.direction;
            return e || (e = "horizontal" === i ? "vertical" : "horizontal"), e === i || "horizontal" !== e && "vertical" !== e || (s.el.classList.remove(`${s.params.containerModifierClass}${i}`), s.el.classList.add(`${s.params.containerModifierClass}${e}`), s.emitContainerClasses(), s.params.direction = e, s.slides.forEach((t => {
                "vertical" === e ? t.style.width = "" : t.style.height = ""
            })), s.emit("changeDirection"), t && s.update()), s
        }
        changeLanguageDirection(e) {
            const t = this;
            t.rtl && "rtl" === e || !t.rtl && "ltr" === e || (t.rtl = "rtl" === e, t.rtlTranslate = "horizontal" === t.params.direction && t.rtl, t.rtl ? (t.el.classList.add(`${t.params.containerModifierClass}rtl`), t.el.dir = "rtl") : (t.el.classList.remove(`${t.params.containerModifierClass}rtl`), t.el.dir = "ltr"), t.update())
        }
        mount(e) {
            const t = this;
            if (t.mounted) return !0;
            let s = e || t.params.el;
            if ("string" == typeof s && (s = document.querySelector(s)), !s) return !1;
            s.swiper = t, s.shadowEl && (t.isElement = !0);
            const i = () => `.${(t.params.wrapperClass || "").trim().split(" ").join(".")}`;
            let a = (() => {
                if (s && s.shadowRoot && s.shadowRoot.querySelector) {
                    return s.shadowRoot.querySelector(i())
                }
                return m(s, i())[0]
            })();
            return !a && t.params.createElements && (a = f("div", t.params.wrapperClass), s.append(a), m(s, `.${t.params.slideClass}`).forEach((e => {
                a.append(e)
            }))), Object.assign(t, {
                el: s,
                wrapperEl: a,
                slidesEl: t.isElement ? s : a,
                mounted: !0,
                rtl: "rtl" === s.dir.toLowerCase() || "rtl" === h(s, "direction"),
                rtlTranslate: "horizontal" === t.params.direction && ("rtl" === s.dir.toLowerCase() || "rtl" === h(s, "direction")),
                wrongRTL: "-webkit-box" === h(a, "display")
            }), !0
        }
        init(e) {
            const t = this;
            if (t.initialized) return t;
            return !1 === t.mount(e) || (t.emit("beforeInit"), t.params.breakpoints && t.setBreakpoint(), t.addClasses(), t.updateSize(), t.updateSlides(), t.params.watchOverflow && t.checkOverflow(), t.params.grabCursor && t.enabled && t.setGrabCursor(), t.params.loop && t.virtual && t.params.virtual.enabled ? t.slideTo(t.params.initialSlide + t.virtual.slidesBefore, 0, t.params.runCallbacksOnInit, !1, !0) : t.slideTo(t.params.initialSlide, 0, t.params.runCallbacksOnInit, !1, !0), t.params.loop && t.loopCreate(), t.attachEvents(), [...t.el.querySelectorAll('[loading="lazy"]')].forEach((e => {
                e.complete ? M(t, e) : e.addEventListener("load", (e => {
                    M(t, e.target)
                }))
            })), L(t), t.initialized = !0, L(t), t.emit("init"), t.emit("afterInit")), t
        }
        destroy(e = !0, t = !0) {
            const s = this,
                {
                    params: i,
                    el: a,
                    wrapperEl: r,
                    slides: n
                } = s;
            return void 0 === s.params || s.destroyed || (s.emit("beforeDestroy"), s.initialized = !1, s.detachEvents(), i.loop && s.loopDestroy(), t && (s.removeClasses(), a.removeAttribute("style"), r.removeAttribute("style"), n && n.length && n.forEach((e => {
                e.classList.remove(i.slideVisibleClass, i.slideActiveClass, i.slideNextClass, i.slidePrevClass), e.removeAttribute("style"), e.removeAttribute("data-swiper-slide-index")
            }))), s.emit("destroy"), Object.keys(s.eventsListeners).forEach((e => {
                s.off(e)
            })), !1 !== e && (s.el.swiper = null, function (e) {
                const t = e;
                Object.keys(t).forEach((e => {
                    try {
                        t[e] = null
                    } catch (e) { }
                    try {
                        delete t[e]
                    } catch (e) { }
                }))
            }(s)), s.destroyed = !0), null
        }
        static extendDefaults(e) {
            c(Y, e)
        }
        static get extendedDefaults() {
            return Y
        }
        static get defaults() {
            return q
        }
        static installModule(e) {
            U.prototype.__modules__ || (U.prototype.__modules__ = []);
            const t = U.prototype.__modules__;
            "function" == typeof e && t.indexOf(e) < 0 && t.push(e)
        }
        static use(e) {
            return Array.isArray(e) ? (e.forEach((e => U.installModule(e))), U) : (U.installModule(e), U)
        }
    }
    Object.keys(X).forEach((e => {
        Object.keys(X[e]).forEach((t => {
            U.prototype[t] = X[e][t]
        }))
    })), U.use([function ({
        swiper: e,
        on: t,
        emit: s
    }) {
        const i = r();
        let a = null,
            n = null;
        const l = () => {
            e && !e.destroyed && e.initialized && (s("beforeResize"), s("resize"))
        },
            o = () => {
                e && !e.destroyed && e.initialized && s("orientationchange")
            };
        t("init", (() => {
            e.params.resizeObserver && void 0 !== i.ResizeObserver ? e && !e.destroyed && e.initialized && (a = new ResizeObserver((t => {
                n = i.requestAnimationFrame((() => {
                    const {
                        width: s,
                        height: i
                    } = e;
                    let a = s,
                        r = i;
                    t.forEach((({
                        contentBoxSize: t,
                        contentRect: s,
                        target: i
                    }) => {
                        i && i !== e.el || (a = s ? s.width : (t[0] || t).inlineSize, r = s ? s.height : (t[0] || t).blockSize)
                    })), a === s && r === i || l()
                }))
            })), a.observe(e.el)) : (i.addEventListener("resize", l), i.addEventListener("orientationchange", o))
        })), t("destroy", (() => {
            n && i.cancelAnimationFrame(n), a && a.unobserve && e.el && (a.unobserve(e.el), a = null), i.removeEventListener("resize", l), i.removeEventListener("orientationchange", o)
        }))
    }, function ({
        swiper: e,
        extendParams: t,
        on: s,
        emit: i
    }) {
        const a = [],
            n = r(),
            l = (t, s = {}) => {
                const r = new (n.MutationObserver || n.WebkitMutationObserver)((t => {
                    if (e.__preventObserver__) return;
                    if (1 === t.length) return void i("observerUpdate", t[0]);
                    const s = function () {
                        i("observerUpdate", t[0])
                    };
                    n.requestAnimationFrame ? n.requestAnimationFrame(s) : n.setTimeout(s, 0)
                }));
                r.observe(t, {
                    attributes: void 0 === s.attributes || s.attributes,
                    childList: void 0 === s.childList || s.childList,
                    characterData: void 0 === s.characterData || s.characterData
                }), a.push(r)
            };
        t({
            observer: !1,
            observeParents: !1,
            observeSlideChildren: !1
        }), s("init", (() => {
            if (e.params.observer) {
                if (e.params.observeParents) {
                    const t = v(e.el);
                    for (let e = 0; e < t.length; e += 1) l(t[e])
                }
                l(e.el, {
                    childList: e.params.observeSlideChildren
                }), l(e.wrapperEl, {
                    attributes: !1
                })
            }
        })), s("destroy", (() => {
            a.forEach((e => {
                e.disconnect()
            })), a.splice(0, a.length)
        }))
    }]);
    const K = U;

    function J(e, t, s, i) {
        return e.params.createElements && Object.keys(i).forEach((a => {
            if (!s[a] && !0 === s.auto) {
                let r = m(e.el, `.${i[a]}`)[0];
                r || (r = f("div", i[a]), r.className = i[a], e.el.append(r)), s[a] = r, t[a] = r
            }
        })), s
    }

    function Q(e = "") {
        return `.${e.trim().replace(/([\.:!+\/])/g, "\\$1").replace(/ /g, ".")}`
    }
    K.use([function ({
        swiper: e,
        extendParams: t,
        on: s,
        emit: a,
        params: r
    }) {
        let n, l;
        e.autoplay = {
            running: !1,
            paused: !1,
            timeLeft: 0
        }, t({
            autoplay: {
                enabled: !1,
                delay: 3e3,
                waitForTransition: !0,
                disableOnInteraction: !0,
                stopOnLastSlide: !1,
                reverseDirection: !1,
                pauseOnMouseEnter: !1
            }
        });
        let o, d, c, p, u, m, f, h = r && r.autoplay ? r.autoplay.delay : 3e3,
            g = r && r.autoplay ? r.autoplay.delay : 3e3,
            v = (new Date).getTime;

        function w(t) {
            e && !e.destroyed && e.wrapperEl && t.target === e.wrapperEl && (e.wrapperEl.removeEventListener("transitionend", w), E())
        }
        const b = () => {
            if (e.destroyed || !e.autoplay.running) return;
            e.autoplay.paused ? d = !0 : d && (g = o, d = !1);
            const t = e.autoplay.paused ? o : v + g - (new Date).getTime();
            e.autoplay.timeLeft = t, a("autoplayTimeLeft", t, t / h), l = requestAnimationFrame((() => {
                b()
            }))
        },
            y = t => {
                if (e.destroyed || !e.autoplay.running) return;
                cancelAnimationFrame(l), b();
                let s = void 0 === t ? e.params.autoplay.delay : t;
                h = e.params.autoplay.delay, g = e.params.autoplay.delay;
                const i = (() => {
                    let t;
                    if (t = e.virtual && e.params.virtual.enabled ? e.slides.filter((e => e.classList.contains("swiper-slide-active")))[0] : e.slides[e.activeIndex], !t) return;
                    return parseInt(t.getAttribute("data-swiper-autoplay"), 10)
                })();
                !Number.isNaN(i) && i > 0 && void 0 === t && (s = i, h = i, g = i), o = s;
                const r = e.params.speed,
                    d = () => {
                        e && !e.destroyed && (e.params.autoplay.reverseDirection ? !e.isBeginning || e.params.loop || e.params.rewind ? (e.slidePrev(r, !0, !0), a("autoplay")) : e.params.autoplay.stopOnLastSlide || (e.slideTo(e.slides.length - 1, r, !0, !0), a("autoplay")) : !e.isEnd || e.params.loop || e.params.rewind ? (e.slideNext(r, !0, !0), a("autoplay")) : e.params.autoplay.stopOnLastSlide || (e.slideTo(0, r, !0, !0), a("autoplay")), e.params.cssMode && (v = (new Date).getTime(), requestAnimationFrame((() => {
                            y()
                        }))))
                    };
                return s > 0 ? (clearTimeout(n), n = setTimeout((() => {
                    d()
                }), s)) : requestAnimationFrame((() => {
                    d()
                })), s
            },
            S = () => {
                e.autoplay.running = !0, y(), a("autoplayStart")
            },
            T = () => {
                e.autoplay.running = !1, clearTimeout(n), cancelAnimationFrame(l), a("autoplayStop")
            },
            x = (t, s) => {
                if (e.destroyed || !e.autoplay.running) return;
                clearTimeout(n), t || (f = !0);
                const i = () => {
                    a("autoplayPause"), e.params.autoplay.waitForTransition ? e.wrapperEl.addEventListener("transitionend", w) : E()
                };
                if (e.autoplay.paused = !0, s) return m && (o = e.params.autoplay.delay), m = !1, void i();
                const r = o || e.params.autoplay.delay;
                o = r - ((new Date).getTime() - v), e.isEnd && o < 0 && !e.params.loop || (o < 0 && (o = 0), i())
            },
            E = () => {
                e.isEnd && o < 0 && !e.params.loop || e.destroyed || !e.autoplay.running || (v = (new Date).getTime(), f ? (f = !1, y(o)) : y(), e.autoplay.paused = !1, a("autoplayResume"))
            },
            C = () => {
                if (e.destroyed || !e.autoplay.running) return;
                const t = i();
                "hidden" === t.visibilityState && (f = !0, x(!0)), "visible" === t.visibilityState && E()
            },
            M = e => {
                "mouse" === e.pointerType && (f = !0, x(!0))
            },
            P = t => {
                "mouse" === t.pointerType && e.autoplay.paused && E()
            };
        s("init", (() => {
            e.params.autoplay.enabled && (e.params.autoplay.pauseOnMouseEnter && (e.el.addEventListener("pointerenter", M), e.el.addEventListener("pointerleave", P)), i().addEventListener("visibilitychange", C), v = (new Date).getTime(), S())
        })), s("destroy", (() => {
            e.el.removeEventListener("pointerenter", M), e.el.removeEventListener("pointerleave", P), i().removeEventListener("visibilitychange", C), e.autoplay.running && T()
        })), s("beforeTransitionStart", ((t, s, i) => {
            !e.destroyed && e.autoplay.running && (i || !e.params.autoplay.disableOnInteraction ? x(!0, !0) : T())
        })), s("sliderFirstMove", (() => {
            !e.destroyed && e.autoplay.running && (e.params.autoplay.disableOnInteraction ? T() : (c = !0, p = !1, f = !1, u = setTimeout((() => {
                f = !0, p = !0, x(!0)
            }), 200)))
        })), s("touchEnd", (() => {
            if (!e.destroyed && e.autoplay.running && c) {
                if (clearTimeout(u), clearTimeout(n), e.params.autoplay.disableOnInteraction) return p = !1, void (c = !1);
                p && e.params.cssMode && E(), p = !1, c = !1
            }
        })), s("slideChange", (() => {
            !e.destroyed && e.autoplay.running && (m = !0)
        })), Object.assign(e.autoplay, {
            start: S,
            stop: T,
            pause: x,
            resume: E
        })
    }, function ({
        swiper: e,
        extendParams: t,
        on: s,
        emit: i
    }) {
        t({
            navigation: {
                nextEl: null,
                prevEl: null,
                hideOnClick: !1,
                disabledClass: "swiper-button-disabled",
                hiddenClass: "swiper-button-hidden",
                lockClass: "swiper-button-lock",
                navigationDisabledClass: "swiper-navigation-disabled"
            }
        }), e.navigation = {
            nextEl: null,
            prevEl: null
        };
        const a = e => (Array.isArray(e) || (e = [e].filter((e => !!e))), e);

        function r(t) {
            let s;
            return t && "string" == typeof t && e.isElement && (s = e.el.shadowRoot.querySelector(t), s) ? s : (t && ("string" == typeof t && (s = [...document.querySelectorAll(t)]), e.params.uniqueNavElements && "string" == typeof t && s.length > 1 && 1 === e.el.querySelectorAll(t).length && (s = e.el.querySelector(t))), t && !s ? t : s)
        }

        function n(t, s) {
            const i = e.params.navigation;
            (t = a(t)).forEach((t => {
                t && (t.classList[s ? "add" : "remove"](...i.disabledClass.split(" ")), "BUTTON" === t.tagName && (t.disabled = s), e.params.watchOverflow && e.enabled && t.classList[e.isLocked ? "add" : "remove"](i.lockClass))
            }))
        }

        function l() {
            const {
                nextEl: t,
                prevEl: s
            } = e.navigation;
            if (e.params.loop) return n(s, !1), void n(t, !1);
            n(s, e.isBeginning && !e.params.rewind), n(t, e.isEnd && !e.params.rewind)
        }

        function o(t) {
            t.preventDefault(), (!e.isBeginning || e.params.loop || e.params.rewind) && (e.slidePrev(), i("navigationPrev"))
        }

        function d(t) {
            t.preventDefault(), (!e.isEnd || e.params.loop || e.params.rewind) && (e.slideNext(), i("navigationNext"))
        }

        function c() {
            const t = e.params.navigation;
            if (e.params.navigation = J(e, e.originalParams.navigation, e.params.navigation, {
                nextEl: "swiper-button-next",
                prevEl: "swiper-button-prev"
            }), !t.nextEl && !t.prevEl) return;
            let s = r(t.nextEl),
                i = r(t.prevEl);
            Object.assign(e.navigation, {
                nextEl: s,
                prevEl: i
            }), s = a(s), i = a(i);
            const n = (s, i) => {
                s && s.addEventListener("click", "next" === i ? d : o), !e.enabled && s && s.classList.add(...t.lockClass.split(" "))
            };
            s.forEach((e => n(e, "next"))), i.forEach((e => n(e, "prev")))
        }

        function p() {
            let {
                nextEl: t,
                prevEl: s
            } = e.navigation;
            t = a(t), s = a(s);
            const i = (t, s) => {
                t.removeEventListener("click", "next" === s ? d : o), t.classList.remove(...e.params.navigation.disabledClass.split(" "))
            };
            t.forEach((e => i(e, "next"))), s.forEach((e => i(e, "prev")))
        }
        s("init", (() => {
            !1 === e.params.navigation.enabled ? u() : (c(), l())
        })), s("toEdge fromEdge lock unlock", (() => {
            l()
        })), s("destroy", (() => {
            p()
        })), s("enable disable", (() => {
            let {
                nextEl: t,
                prevEl: s
            } = e.navigation;
            t = a(t), s = a(s), [...t, ...s].filter((e => !!e)).forEach((t => t.classList[e.enabled ? "remove" : "add"](e.params.navigation.lockClass)))
        })), s("click", ((t, s) => {
            let {
                nextEl: r,
                prevEl: n
            } = e.navigation;
            r = a(r), n = a(n);
            const l = s.target;
            if (e.params.navigation.hideOnClick && !n.includes(l) && !r.includes(l)) {
                if (e.pagination && e.params.pagination && e.params.pagination.clickable && (e.pagination.el === l || e.pagination.el.contains(l))) return;
                let t;
                r.length ? t = r[0].classList.contains(e.params.navigation.hiddenClass) : n.length && (t = n[0].classList.contains(e.params.navigation.hiddenClass)), i(!0 === t ? "navigationShow" : "navigationHide"), [...r, ...n].filter((e => !!e)).forEach((t => t.classList.toggle(e.params.navigation.hiddenClass)))
            }
        }));
        const u = () => {
            e.el.classList.add(...e.params.navigation.navigationDisabledClass.split(" ")), p()
        };
        Object.assign(e.navigation, {
            enable: () => {
                e.el.classList.remove(...e.params.navigation.navigationDisabledClass.split(" ")), c(), l()
            },
            disable: u,
            update: l,
            init: c,
            destroy: p
        })
    }, function ({
        swiper: e,
        extendParams: t,
        on: s,
        emit: i
    }) {
        const a = "swiper-pagination";
        let r;
        t({
            pagination: {
                el: null,
                bulletElement: "span",
                clickable: !1,
                hideOnClick: !1,
                renderBullet: null,
                renderProgressbar: null,
                renderFraction: null,
                renderCustom: null,
                progressbarOpposite: !1,
                type: "bullets",
                dynamicBullets: !1,
                dynamicMainBullets: 1,
                formatFractionCurrent: e => e,
                formatFractionTotal: e => e,
                bulletClass: `${a}-bullet`,
                bulletActiveClass: `${a}-bullet-active`,
                modifierClass: `${a}-`,
                currentClass: `${a}-current`,
                totalClass: `${a}-total`,
                hiddenClass: `${a}-hidden`,
                progressbarFillClass: `${a}-progressbar-fill`,
                progressbarOppositeClass: `${a}-progressbar-opposite`,
                clickableClass: `${a}-clickable`,
                lockClass: `${a}-lock`,
                horizontalClass: `${a}-horizontal`,
                verticalClass: `${a}-vertical`,
                paginationDisabledClass: `${a}-disabled`
            }
        }), e.pagination = {
            el: null,
            bullets: []
        };
        let n = 0;
        const l = e => (Array.isArray(e) || (e = [e].filter((e => !!e))), e);

        function o() {
            return !e.params.pagination.el || !e.pagination.el || Array.isArray(e.pagination.el) && 0 === e.pagination.el.length
        }

        function d(t, s) {
            const {
                bulletActiveClass: i
            } = e.params.pagination;
            t && (t = t[("prev" === s ? "previous" : "next") + "ElementSibling"]) && (t.classList.add(`${i}-${s}`), (t = t[("prev" === s ? "previous" : "next") + "ElementSibling"]) && t.classList.add(`${i}-${s}-${s}`))
        }

        function c(t) {
            const s = t.target.closest(Q(e.params.pagination.bulletClass));
            if (!s) return;
            t.preventDefault();
            const i = g(s) * e.params.slidesPerGroup;
            if (e.params.loop) {
                if (e.realIndex === i) return;
                const t = e.getSlideIndexByData(i),
                    s = e.getSlideIndexByData(e.realIndex);
                t > e.slides.length - e.loopedSlides && e.loopFix({
                    direction: t > s ? "next" : "prev",
                    activeSlideIndex: t,
                    slideTo: !1
                }), e.slideToLoop(i)
            } else e.slideTo(i)
        }

        function p() {
            const t = e.rtl,
                s = e.params.pagination;
            if (o()) return;
            let a, c, p = e.pagination.el;
            p = l(p);
            const u = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
                m = e.params.loop ? Math.ceil(u / e.params.slidesPerGroup) : e.snapGrid.length;
            if (e.params.loop ? (c = e.previousRealIndex || 0, a = e.params.slidesPerGroup > 1 ? Math.floor(e.realIndex / e.params.slidesPerGroup) : e.realIndex) : void 0 !== e.snapIndex ? (a = e.snapIndex, c = e.previousSnapIndex) : (c = e.previousIndex || 0, a = e.activeIndex || 0), "bullets" === s.type && e.pagination.bullets && e.pagination.bullets.length > 0) {
                const i = e.pagination.bullets;
                let l, o, u;
                if (s.dynamicBullets && (r = w(i[0], e.isHorizontal() ? "width" : "height", !0), p.forEach((t => {
                    t.style[e.isHorizontal() ? "width" : "height"] = r * (s.dynamicMainBullets + 4) + "px"
                })), s.dynamicMainBullets > 1 && void 0 !== c && (n += a - (c || 0), n > s.dynamicMainBullets - 1 ? n = s.dynamicMainBullets - 1 : n < 0 && (n = 0)), l = Math.max(a - n, 0), o = l + (Math.min(i.length, s.dynamicMainBullets) - 1), u = (o + l) / 2), i.forEach((e => {
                    const t = [...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map((e => `${s.bulletActiveClass}${e}`))].map((e => "string" == typeof e && e.includes(" ") ? e.split(" ") : e)).flat();
                    e.classList.remove(...t)
                })), p.length > 1) i.forEach((t => {
                    const i = g(t);
                    i === a ? t.classList.add(...s.bulletActiveClass.split(" ")) : e.isElement && t.setAttribute("part", "bullet"), s.dynamicBullets && (i >= l && i <= o && t.classList.add(...`${s.bulletActiveClass}-main`.split(" ")), i === l && d(t, "prev"), i === o && d(t, "next"))
                }));
                else {
                    const t = i[a];
                    if (t && t.classList.add(...s.bulletActiveClass.split(" ")), e.isElement && i.forEach(((e, t) => {
                        e.setAttribute("part", t === a ? "bullet-active" : "bullet")
                    })), s.dynamicBullets) {
                        const e = i[l],
                            t = i[o];
                        for (let e = l; e <= o; e += 1) i[e] && i[e].classList.add(...`${s.bulletActiveClass}-main`.split(" "));
                        d(e, "prev"), d(t, "next")
                    }
                }
                if (s.dynamicBullets) {
                    const a = Math.min(i.length, s.dynamicMainBullets + 4),
                        n = (r * a - r) / 2 - u * r,
                        l = t ? "right" : "left";
                    i.forEach((t => {
                        t.style[e.isHorizontal() ? l : "top"] = `${n}px`
                    }))
                }
            }
            p.forEach(((t, r) => {
                if ("fraction" === s.type && (t.querySelectorAll(Q(s.currentClass)).forEach((e => {
                    e.textContent = s.formatFractionCurrent(a + 1)
                })), t.querySelectorAll(Q(s.totalClass)).forEach((e => {
                    e.textContent = s.formatFractionTotal(m)
                }))), "progressbar" === s.type) {
                    let i;
                    i = s.progressbarOpposite ? e.isHorizontal() ? "vertical" : "horizontal" : e.isHorizontal() ? "horizontal" : "vertical";
                    const r = (a + 1) / m;
                    let n = 1,
                        l = 1;
                    "horizontal" === i ? n = r : l = r, t.querySelectorAll(Q(s.progressbarFillClass)).forEach((t => {
                        t.style.transform = `translate3d(0,0,0) scaleX(${n}) scaleY(${l})`, t.style.transitionDuration = `${e.params.speed}ms`
                    }))
                }
                "custom" === s.type && s.renderCustom ? (t.innerHTML = s.renderCustom(e, a + 1, m), 0 === r && i("paginationRender", t)) : (0 === r && i("paginationRender", t), i("paginationUpdate", t)), e.params.watchOverflow && e.enabled && t.classList[e.isLocked ? "add" : "remove"](s.lockClass)
            }))
        }

        function u() {
            const t = e.params.pagination;
            if (o()) return;
            const s = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length;
            let a = e.pagination.el;
            a = l(a);
            let r = "";
            if ("bullets" === t.type) {
                let i = e.params.loop ? Math.ceil(s / e.params.slidesPerGroup) : e.snapGrid.length;
                e.params.freeMode && e.params.freeMode.enabled && i > s && (i = s);
                for (let s = 0; s < i; s += 1) t.renderBullet ? r += t.renderBullet.call(e, s, t.bulletClass) : r += `<${t.bulletElement} ${e.isElement ? 'part="bullet"' : ""} class="${t.bulletClass}"></${t.bulletElement}>`
            }
            "fraction" === t.type && (r = t.renderFraction ? t.renderFraction.call(e, t.currentClass, t.totalClass) : `<span class="${t.currentClass}"></span> / <span class="${t.totalClass}"></span>`), "progressbar" === t.type && (r = t.renderProgressbar ? t.renderProgressbar.call(e, t.progressbarFillClass) : `<span class="${t.progressbarFillClass}"></span>`), e.pagination.bullets = [], a.forEach((s => {
                "custom" !== t.type && (s.innerHTML = r || ""), "bullets" === t.type && e.pagination.bullets.push(...s.querySelectorAll(Q(t.bulletClass)))
            })), "custom" !== t.type && i("paginationRender", a[0])
        }

        function m() {
            e.params.pagination = J(e, e.originalParams.pagination, e.params.pagination, {
                el: "swiper-pagination"
            });
            const t = e.params.pagination;
            if (!t.el) return;
            let s;
            "string" == typeof t.el && e.isElement && (s = e.el.shadowRoot.querySelector(t.el)), s || "string" != typeof t.el || (s = [...document.querySelectorAll(t.el)]), s || (s = t.el), s && 0 !== s.length && (e.params.uniqueNavElements && "string" == typeof t.el && Array.isArray(s) && s.length > 1 && (s = [...e.el.querySelectorAll(t.el)], s.length > 1 && (s = s.filter((t => v(t, ".swiper")[0] === e.el))[0])), Array.isArray(s) && 1 === s.length && (s = s[0]), Object.assign(e.pagination, {
                el: s
            }), s = l(s), s.forEach((s => {
                "bullets" === t.type && t.clickable && s.classList.add(t.clickableClass), s.classList.add(t.modifierClass + t.type), s.classList.add(e.isHorizontal() ? t.horizontalClass : t.verticalClass), "bullets" === t.type && t.dynamicBullets && (s.classList.add(`${t.modifierClass}${t.type}-dynamic`), n = 0, t.dynamicMainBullets < 1 && (t.dynamicMainBullets = 1)), "progressbar" === t.type && t.progressbarOpposite && s.classList.add(t.progressbarOppositeClass), t.clickable && s.addEventListener("click", c), e.enabled || s.classList.add(t.lockClass)
            })))
        }

        function f() {
            const t = e.params.pagination;
            if (o()) return;
            let s = e.pagination.el;
            s && (s = l(s), s.forEach((s => {
                s.classList.remove(t.hiddenClass), s.classList.remove(t.modifierClass + t.type), s.classList.remove(e.isHorizontal() ? t.horizontalClass : t.verticalClass), t.clickable && s.removeEventListener("click", c)
            }))), e.pagination.bullets && e.pagination.bullets.forEach((e => e.classList.remove(...t.bulletActiveClass.split(" "))))
        }
        s("changeDirection", (() => {
            if (!e.pagination || !e.pagination.el) return;
            const t = e.params.pagination;
            let {
                el: s
            } = e.pagination;
            s = l(s), s.forEach((s => {
                s.classList.remove(t.horizontalClass, t.verticalClass), s.classList.add(e.isHorizontal() ? t.horizontalClass : t.verticalClass)
            }))
        })), s("init", (() => {
            !1 === e.params.pagination.enabled ? h() : (m(), u(), p())
        })), s("activeIndexChange", (() => {
            void 0 === e.snapIndex && p()
        })), s("snapIndexChange", (() => {
            p()
        })), s("snapGridLengthChange", (() => {
            u(), p()
        })), s("destroy", (() => {
            f()
        })), s("enable disable", (() => {
            let {
                el: t
            } = e.pagination;
            t && (t = l(t), t.forEach((t => t.classList[e.enabled ? "remove" : "add"](e.params.pagination.lockClass))))
        })), s("lock unlock", (() => {
            p()
        })), s("click", ((t, s) => {
            const a = s.target;
            let {
                el: r
            } = e.pagination;
            if (Array.isArray(r) || (r = [r].filter((e => !!e))), e.params.pagination.el && e.params.pagination.hideOnClick && r && r.length > 0 && !a.classList.contains(e.params.pagination.bulletClass)) {
                if (e.navigation && (e.navigation.nextEl && a === e.navigation.nextEl || e.navigation.prevEl && a === e.navigation.prevEl)) return;
                const t = r[0].classList.contains(e.params.pagination.hiddenClass);
                i(!0 === t ? "paginationShow" : "paginationHide"), r.forEach((t => t.classList.toggle(e.params.pagination.hiddenClass)))
            }
        }));
        const h = () => {
            e.el.classList.add(e.params.pagination.paginationDisabledClass);
            let {
                el: t
            } = e.pagination;
            t && (t = l(t), t.forEach((t => t.classList.add(e.params.pagination.paginationDisabledClass)))), f()
        };
        Object.assign(e.pagination, {
            enable: () => {
                e.el.classList.remove(e.params.pagination.paginationDisabledClass);
                let {
                    el: t
                } = e.pagination;
                t && (t = l(t), t.forEach((t => t.classList.remove(e.params.pagination.paginationDisabledClass)))), m(), u(), p()
            },
            disable: h,
            render: u,
            update: p,
            init: m,
            destroy: f
        })
    }]), 
    new K(".professional-writer-slider", {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: false,
        clickable: true,
        centeredSlides: !0,
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },
        // navigation: {
        //     nextEl: "#next-cv",
        //     prevEl: "#prev-cv"
        // },
        breakpoints: {
            640: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            1024: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            1200: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            1400: {
                slidesPerView: 1,
                spaceBetween: 20
            }
        },
        // autoplay: {
        //     delay: 2500,
        //     disableOnInteraction: !1
        // }
    }),
    new K(".process-slider", {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: false,
        clickable: true,
        pagination: {
            el: ".process-pagination",
            clickable: !0
        },
        // navigation: {
        //     nextEl: "#next-cv",
        //     prevEl: "#prev-cv"
        // },
        breakpoints: {
            640: {
                slidesPerView: 1,
                spaceBetween: 15
            },
            768: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            1024: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            1200: {
                slidesPerView: 4,
                spaceBetween: 15
            },
            1400: {
                slidesPerView: 4,
                spaceBetween: 20
            }
        },
        // autoplay: {
        //     delay: 2500,
        //     disableOnInteraction: !1
        // }
    }),
    new K(".subject-slider", {
        slidesPerView: 2,
        spaceBetween: 30,
        loop: true,
        clickable: true,
        pagination: {
            el: ".subject-pagination",
            clickable: true
        },
        navigation: {
            nextEl: "#next",
            prevEl: "#prev"
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 15
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 15
            },
            1024: {
                slidesPerView: 5,
                spaceBetween: 15
            },
            1200: {
                slidesPerView: 5,
                spaceBetween: 15
            },
            1400: {
                slidesPerView: 6,
                spaceBetween: 15
            }
        },
        // autoplay: {
        //     delay: 2500,
        //     disableOnInteraction: !1
        // }
    }),

    new K(".professional-testimonial-slider", {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        clickable: true,
        pagination: {
            el: ".testimonial-pagination",
            clickable: true
        },
        navigation: {
            nextEl: "#next-testimonial",
            prevEl: "#prev-testimonial"
        },
        breakpoints: {
            640: { slidesPerView: 1, spaceBetween: 20 },
            768: { slidesPerView: 1, spaceBetween: 20 },
            1024: { slidesPerView: 1, spaceBetween: 20 },
            1200: { slidesPerView: 1, spaceBetween: 20 },
            1400: { slidesPerView: 1, spaceBetween: 20 }
        },
        autoplay: {
            delay: 3500,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,   // 👈 avoids freeze on hover
        },
        speed: 800,                   // 👈 smooth slide speed
        touchEventsTarget: 'container', // 👈 ensures proper swipe detection
    });
})();